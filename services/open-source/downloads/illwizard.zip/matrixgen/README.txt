MATRIXGEN FOR ILL WIZARD

Written by Bryan Wilhelm
Version 1.0 for ILL Wizard 1.0-Beta 2
August 23, 1999

-------------------------------------------------------------------------------

INTRODUCTION

The MatrixGen Win32 applet was created in response to the need for a secure 
method of placing the authorization and password information in the Java applet
parameter list of a public HTML document. I was once told that we lock our 
doors, not to keep criminals out, but to keep honest people from becoming 
dishonest. That is the philosophy behind MatrixGen and the Access-Security-
Matrix parameter. The encryption algorithm is extremely simple, but it masks 
the authorization and password strings enough that the general user will not 
even attempt to discover their original forms.

-------------------------------------------------------------------------------

SYSTEM REQUIREMENTS

This program requires Windows NT 4.0 or later.

-------------------------------------------------------------------------------

OPERATION

When the MatrixGen program is started (by running matrixgen.exe), an input 
prompt appears in the text field for the authorization. You should enter the 
nine digit authorization code assigned by OCLC for interlibrary loan access 
that appears in the form of nnn-nnn-nnn. Note that the hyphens will not make a 
difference in the final output of the program. Next tab over to the password 
field and enter the password associated with the authorization.

No error checking is done on these fields. The password may be of any form and 
therefore is impractical to check. The authorization is not checked (although 
it easily could be) in anticipation that other ISO-10161-compliant interlibrary
loan service providers may be used with this program and may not use the same 
authorization format.

After the authorization and password have been entered there are essentially 
three options for generating the security matrix code. The first is the button 
labeled "Generate Matrix Code". This will generate the code and display it in 
the space immediately below the button. The second option is to simply copy 
the matrix code out to the system clipboard where it can be pasted into a text 
document such as an HTML file. This is likely going to be the preferred method 
of most users. The third option is also very useful. It copies the entire Java 
applet param tag along with the security matrix code out to the system 
clipboard, again allowing the user to paste it into a text document such as an 
HTML file. The last option, although very useful, may not be necessary since 
the "Access-Security-Matrix" param tag is already in the HTML file and only 
needs to be filled in.

NOTE: A new security matrix code should be generated and placed in the applet 
parameter list whenever the authorization or password changes. A new security 
matrix code should also be generated whenever a new version of ILL Expert is 
released (including new betas) since the encryption algorithm may change from 
time to time.

-------------------------------------------------------------------------------

KNOWN ISSUES

There are currently no known bugs. All bugs reports should be sent to Bryan 
Wilhelm (bwilhelm@carolina.rr.com).

-------------------------------------------------------------------------------

CREDITS AND CONTACTS

RESEARCH AND DEVELOPMENT
Bryan Wilhelm lives in Charlotte, North Carolina.

-------------------------------------------------------------------------------
Copyright � 1999 by Bryan Wilhelm. All rights reserved.
Last updated on August 23, 1999 at 1:33:54 p.m.
