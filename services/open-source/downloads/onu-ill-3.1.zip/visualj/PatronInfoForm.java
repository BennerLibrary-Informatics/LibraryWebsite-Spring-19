import com.ms.wfc.app.*;
import com.ms.wfc.core.*;
import com.ms.wfc.ui.*;
import com.ms.wfc.html.*;

/**
 * This class can take a variable number of parameters on the command
 * line. Program execution begins with the main() method. The class
 * constructor is not invoked unless an object of type 'PatronInfoForm'
 * created in the main() method.
 */
public class PatronInfoForm extends Form
{
	public PatronInfoForm()
	{
		super();

		// Required for Visual J++ Form Designer support
		initForm();		

		// TODO: Add any constructor code after initForm call
	}

	/**
	 * PatronInfoForm overrides dispose so it can clean up the
	 * component list.
	 */
	public void dispose()
	{
		super.dispose();
		components.dispose();
	}
    
    private void okButton_click(Object source, Event e)
    {
        if ( nameEdit.getText( ).equals( "" ) ||
             ( poboxEdit.getText( ).equals( "" ) && addrEdit.getText( ).equals( "" ) ) ||
             emailEdit.getText( ).equals( "" ) )
        {
            String msgString = new String( "You did not fill in the following required fields:\n\n" );
            if ( nameEdit.getText( ).equals( "" ) )
                msgString += "Your Name\n";
            if ( poboxEdit.getText( ).equals( "" ) && addrEdit.getText( ).equals( "" ) )
                msgString += "Your Box Number OR Mailing Address\n";
            if ( emailEdit.getText( ).equals( "" ) )
                msgString += "Your Email Address\n";
            MessageBox.show( msgString, "ONU Interlibrary Loan",
                             MessageBox.OK | MessageBox.ICONWARNING );
        }
        else
        {
            this.setDialogResult( DialogResult.OK );
            this.setVisible( false );
        }
    }

    /**
     * NOTE: The following code is required by the Visual J++ form
     * designer.  It can be modified using the form editor.  Do not
     * modify it using the code editor.
     */
    Container components = new Container();
    Label label1 = new Label();
    Label label2 = new Label();
    GroupBox requestorInfoGroupBox = new GroupBox();
    Label label3 = new Label();
    Button cancelButton = new Button();
    Button okButton = new Button();
    Label label5 = new Label();
    Edit nameEdit = new Edit();
    RadioButton facultyButton = new RadioButton();
    RadioButton staffButton = new RadioButton();
    RadioButton undergradButton = new RadioButton();
    RadioButton gradButton = new RadioButton();
    RadioButton otherButton = new RadioButton();
    Label label6 = new Label();
    Edit idEdit = new Edit();
    Label label4 = new Label();
    Label label7 = new Label();
    Edit poboxEdit = new Edit();
    Label label13 = new Label();
    Edit emailEdit = new Edit();
    Label label14 = new Label();
    Edit phoneEdit = new Edit();
    PictureBox pictureBox1 = new PictureBox();
    Label label9 = new Label();
    Edit addrEdit = new Edit();
    Label label8 = new Label();
    Label label10 = new Label();
    Edit cityEdit = new Edit();
    Label label11 = new Label();
    Edit stateEdit = new Edit();
    Label label12 = new Label();
    Edit zipEdit = new Edit();

    private void initForm()
    {
        // NOTE:  This form is storing resource information in an
        // external file.  Do not modify the string parameter to any
        // resources.getObject() function call.  For example, do not
        // modify "foo1_location" in the following line of code
        // even if the name of the Foo object changes: 
        //	 foo1.setLocation((Point)resources.getObject("foo1_location"));

        IResourceManager resources = new ResourceManager(this, "PatronInfoForm");
        label1.setFont(new Font("Times New Roman", 22.0f, FontSize.POINTS, FontWeight.BOLD, true, false, false, CharacterSet.DEFAULT, 0));
        label1.setLocation(new Point(110, 0));
        label1.setSize(new Point(326, 33));
        label1.setTabIndex(1);
        label1.setTabStop(false);
        label1.setText("Olivet Nazarene University");
        label1.setAutoSize(true);
        label1.setTextAlign(HorizontalAlignment.RIGHT);

        label2.setFont(new Font("Times New Roman", 16.0f, FontSize.POINTS, FontWeight.BOLD, false, false, false, CharacterSet.DEFAULT, 0));
        label2.setLocation(new Point(110, 34));
        label2.setSize(new Point(326, 24));
        label2.setTabIndex(2);
        label2.setTabStop(false);
        label2.setText("Interlibrary Loan Request");
        label2.setAutoSize(true);
        label2.setTextAlign(HorizontalAlignment.RIGHT);

        requestorInfoGroupBox.setFont(new Font("MS Sans Serif", 8.0f, FontSize.POINTS, FontWeight.NORMAL, false, false, false, CharacterSet.DEFAULT, 0));
        requestorInfoGroupBox.setLocation(new Point(6, 108));
        requestorInfoGroupBox.setSize(new Point(430, 244));
        requestorInfoGroupBox.setTabIndex(4);
        requestorInfoGroupBox.setTabStop(false);
        requestorInfoGroupBox.setText("Requestor Information");

        label3.setAllowDrop(true);
        label3.setFont(new Font("MS Sans Serif", 8.0f, FontSize.POINTS, FontWeight.BOLD, false, false, false, CharacterSet.DEFAULT, 0));
        label3.setLocation(new Point(8, 70));
        label3.setSize(new Point(428, 32));
        label3.setTabIndex(3);
        label3.setTabStop(false);
        label3.setText("NOTE:  Fields in bold letters are required.  Completely filled forms will process faster.");

        cancelButton.setLocation(new Point(360, 360));
        cancelButton.setSize(new Point(75, 23));
        cancelButton.setTabIndex(6);
        cancelButton.setText("Cancel");
        cancelButton.setDialogResult(DialogResult.CANCEL);

        this.setText("Benner Library Interlibrary Loan - Patron Information");
        this.setAutoScaleBaseSize(13);
        this.setBorderStyle(FormBorderStyle.FIXED_DIALOG);
        this.setCancelButton(cancelButton);
        this.setClientSize(new Point(444, 392));
        this.setMaximizeBox(false);
        this.setMinimizeBox(false);
        this.setShowInTaskbar(false);
        this.setStartPosition(FormStartPosition.CENTER_SCREEN);

        okButton.setLocation(new Point(278, 360));
        okButton.setSize(new Point(75, 23));
        okButton.setTabIndex(5);
        okButton.setText("OK");
        okButton.addOnClick(new EventHandler(this.okButton_click));

        label5.setFont(new Font("MS Sans Serif", 8.0f, FontSize.POINTS, FontWeight.BOLD, false, false, false, CharacterSet.DEFAULT, 0));
        label5.setLocation(new Point(12, 66));
        label5.setSize(new Point(100, 13));
        label5.setTabIndex(6);
        label5.setTabStop(false);
        label5.setText("Your Name");
        label5.setAutoSize(true);

        nameEdit.setLocation(new Point(12, 83));
        nameEdit.setSize(new Point(194, 20));
        nameEdit.setTabIndex(7);
        nameEdit.setText("");

        facultyButton.setLocation(new Point(12, 34));
        facultyButton.setSize(new Point(60, 25));
        facultyButton.setTabIndex(1);
        facultyButton.setTabStop(true);
        facultyButton.setText("Faculty");

        staffButton.setLocation(new Point(78, 34));
        staffButton.setSize(new Point(50, 26));
        staffButton.setTabIndex(2);
        staffButton.setText("Staff");

        undergradButton.setLocation(new Point(134, 34));
        undergradButton.setSize(new Point(96, 25));
        undergradButton.setTabIndex(3);
        undergradButton.setText("Undergraduate");

        gradButton.setLocation(new Point(236, 34));
        gradButton.setSize(new Point(68, 25));
        gradButton.setTabIndex(4);
        gradButton.setText("Graduate");

        otherButton.setLocation(new Point(310, 34));
        otherButton.setSize(new Point(52, 25));
        otherButton.setTabIndex(5);
        otherButton.setText("Other");

        label6.setFont(new Font("MS Sans Serif", 8.0f, FontSize.POINTS, FontWeight.NORMAL, false, false, false, CharacterSet.DEFAULT, 0));
        label6.setLocation(new Point(225, 66));
        label6.setSize(new Point(188, 13));
        label6.setTabIndex(8);
        label6.setTabStop(false);
        label6.setText("Student ID or Social Security Number");
        label6.setAutoSize(true);

        idEdit.setLocation(new Point(225, 83));
        idEdit.setSize(new Point(192, 20));
        idEdit.setTabIndex(9);
        idEdit.setText("");

        label4.setFont(new Font("MS Sans Serif", 8.0f, FontSize.POINTS, FontWeight.BOLD, false, false, false, CharacterSet.DEFAULT, 0));
        label4.setLocation(new Point(12, 20));
        label4.setSize(new Point(100, 13));
        label4.setTabIndex(0);
        label4.setTabStop(false);
        label4.setText("Your Status");
        label4.setAutoSize(true);

        label7.setFont(new Font("MS Sans Serif", 8.0f, FontSize.POINTS, FontWeight.BOLD, false, false, false, CharacterSet.DEFAULT, 0));
        label7.setLocation(new Point(12, 110));
        label7.setSize(new Point(110, 13));
        label7.setTabIndex(10);
        label7.setTabStop(false);
        label7.setText("Your Box Number");
        label7.setAutoSize(true);

        poboxEdit.setLocation(new Point(12, 126));
        poboxEdit.setSize(new Point(194, 20));
        poboxEdit.setTabIndex(11);
        poboxEdit.setText("");

        label13.setFont(new Font("MS Sans Serif", 8.0f, FontSize.POINTS, FontWeight.BOLD, false, false, false, CharacterSet.DEFAULT, 0));
        label13.setLocation(new Point(12, 196));
        label13.setSize(new Point(100, 13));
        label13.setTabIndex(21);
        label13.setTabStop(false);
        label13.setText("Email Address");
        label13.setAutoSize(true);

        emailEdit.setLocation(new Point(12, 212));
        emailEdit.setSize(new Point(194, 20));
        emailEdit.setTabIndex(22);
        emailEdit.setText("");

        label14.setLocation(new Point(225, 196));
        label14.setSize(new Point(100, 13));
        label14.setTabIndex(23);
        label14.setTabStop(false);
        label14.setText("Phone Number");
        label14.setAutoSize(true);

        phoneEdit.setLocation(new Point(225, 212));
        phoneEdit.setSize(new Point(192, 20));
        phoneEdit.setTabIndex(24);
        phoneEdit.setText("");

        pictureBox1.setLocation(new Point(8, 0));
        pictureBox1.setSize(new Point(64, 64));
        pictureBox1.setTabIndex(0);
        pictureBox1.setTabStop(false);
        pictureBox1.setText("pictureBox1");
        pictureBox1.setImage((Bitmap)resources.getObject("pictureBox1_image"));
        pictureBox1.setSizeMode(PictureBoxSizeMode.AUTO_SIZE);

        label9.setFont(new Font("MS Sans Serif", 8.0f, FontSize.POINTS, FontWeight.BOLD, false, false, false, CharacterSet.DEFAULT, 0));
        label9.setLocation(new Point(225, 110));
        label9.setSize(new Point(136, 13));
        label9.setTabIndex(13);
        label9.setTabStop(false);
        label9.setText("Your Mailing Address");
        label9.setAutoSize(true);

        addrEdit.setLocation(new Point(225, 126));
        addrEdit.setSize(new Point(192, 20));
        addrEdit.setTabIndex(14);
        addrEdit.setText("");

        label8.setFont(new Font("MS Sans Serif", 8.0f, FontSize.POINTS, FontWeight.BOLD, false, false, false, CharacterSet.DEFAULT, 0));
        label8.setLocation(new Point(188, 110));
        label8.setSize(new Point(28, 13));
        label8.setTabIndex(12);
        label8.setTabStop(false);
        label8.setText("OR");
        label8.setAutoSize(true);

        label10.setLocation(new Point(12, 152));
        label10.setSize(new Point(32, 13));
        label10.setTabIndex(15);
        label10.setTabStop(false);
        label10.setText("City");
        label10.setAutoSize(true);

        cityEdit.setLocation(new Point(12, 170));
        cityEdit.setSize(new Point(194, 20));
        cityEdit.setTabIndex(16);
        cityEdit.setText("");

        label11.setLocation(new Point(225, 152));
        label11.setSize(new Point(32, 13));
        label11.setTabIndex(17);
        label11.setTabStop(false);
        label11.setText("State");
        label11.setAutoSize(true);

        stateEdit.setLocation(new Point(225, 170));
        stateEdit.setSize(new Point(48, 20));
        stateEdit.setTabIndex(18);
        stateEdit.setText("");
        stateEdit.setCharacterCasing(CharacterCasing.UPPER);
        stateEdit.setMaxLength(2);

        label12.setLocation(new Point(292, 152));
        label12.setSize(new Point(100, 13));
        label12.setTabIndex(19);
        label12.setTabStop(false);
        label12.setText("ZIP Code");
        label12.setAutoSize(true);

        zipEdit.setLocation(new Point(292, 170));
        zipEdit.setSize(new Point(124, 20));
        zipEdit.setTabIndex(20);
        zipEdit.setText("");
        zipEdit.setMaxLength(5);

        this.setNewControls(new Control[] {
                            pictureBox1, 
                            okButton, 
                            cancelButton, 
                            label3, 
                            requestorInfoGroupBox, 
                            label2, 
                            label1});
        requestorInfoGroupBox.setNewControls(new Control[] {
                                             zipEdit, 
                                             label12, 
                                             stateEdit, 
                                             label11, 
                                             cityEdit, 
                                             label10, 
                                             label8, 
                                             addrEdit, 
                                             label9, 
                                             phoneEdit, 
                                             label14, 
                                             emailEdit, 
                                             label13, 
                                             poboxEdit, 
                                             label7, 
                                             label4, 
                                             idEdit, 
                                             label6, 
                                             otherButton, 
                                             gradButton, 
                                             undergradButton, 
                                             staffButton, 
                                             facultyButton, 
                                             nameEdit, 
                                             label5});
    }

	/**
	 * The main entry point for the application. 
	 *
	 * @param args Array of parameters passed to the application
	 * via the command line.
	 */
	public static void main(String args[])
	{
		Application.run(new PatronInfoForm());
	}
}
