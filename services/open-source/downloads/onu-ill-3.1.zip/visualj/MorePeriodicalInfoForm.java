import com.ms.wfc.app.*;
import com.ms.wfc.core.*;
import com.ms.wfc.ui.*;
import com.ms.wfc.html.*;

/**
 * This class can take a variable number of parameters on the command
 * line. Program execution begins with the main() method. The class
 * constructor is not invoked unless an object of type 'MorePeriodicalInfoForm'
 * created in the main() method.
 */
public class MorePeriodicalInfoForm extends Form
{
	public MorePeriodicalInfoForm()
	{
		super();

		// Required for Visual J++ Form Designer support
		initForm();		

		// TODO: Add any constructor code after initForm call
	}

	/**
	 * MorePeriodicalInfoForm overrides dispose so it can clean up the
	 * component list.
	 */
	public void dispose()
	{
		super.dispose();
		components.dispose();
	}

    private void sourceComboBox_selectedIndexChanged(Object source, Event e)
    {
        if ( sourceComboBox.getSelectedIndex( ) == 1 ) {
            label4.setText( "Enter the database and keywords used." );
            sourceEdit.setVisible( true );
        }
        else
        {
            label4.setText( "Enter the title and page of reference." );
            sourceEdit.setVisible( true );
        }
    }

    /**
     * NOTE: The following code is required by the Visual J++ form
     * designer.  It can be modified using the form editor.  Do not
     * modify it using the code editor.
     */
    Container components = new Container();
    GroupBox citationGroupBox = new GroupBox();
    Edit sourceEdit = new Edit();
    Label label4 = new Label();
    Label label5 = new Label();
    Edit commentEdit = new Edit();
    Label label3 = new Label();
    Label label2 = new Label();
    ComboBox sourceComboBox = new ComboBox();
    Button okButton = new Button();
    Button cancelButton = new Button();

    private void initForm()
    {
        this.setText("More Periodical Infoformation");
        this.setAutoScaleBaseSize(13);
        this.setBorderStyle(FormBorderStyle.FIXED_DIALOG);
        this.setClientSize(new Point(450, 241));
        this.setMaximizeBox(false);
        this.setMinimizeBox(false);
        this.setShowInTaskbar(false);
        this.setStartPosition(FormStartPosition.CENTER_SCREEN);

        citationGroupBox.setLocation(new Point(8, 8));
        citationGroupBox.setSize(new Point(434, 194));
        citationGroupBox.setTabIndex(0);
        citationGroupBox.setTabStop(false);
        citationGroupBox.setText("Citation Information");

        sourceEdit.setLocation(new Point(228, 66));
        sourceEdit.setSize(new Point(194, 20));
        sourceEdit.setTabIndex(4);
        sourceEdit.setText("");
        sourceEdit.setVisible(false);

        label4.setLocation(new Point(228, 50));
        label4.setSize(new Point(194, 13));
        label4.setTabIndex(3);
        label4.setTabStop(false);
        label4.setText("");
        label4.setAutoSize(true);

        label5.setLocation(new Point(12, 96));
        label5.setSize(new Point(324, 13));
        label5.setTabIndex(5);
        label5.setTabStop(false);
        label5.setText("Enter any addition comments about this book in the field below.");
        label5.setAutoSize(true);

        commentEdit.setLocation(new Point(12, 112));
        commentEdit.setSize(new Point(410, 70));
        commentEdit.setTabIndex(6);
        commentEdit.setText("");
        commentEdit.setMultiline(true);

        label3.setLocation(new Point(12, 50));
        label3.setSize(new Point(112, 13));
        label3.setTabIndex(1);
        label3.setTabStop(false);
        label3.setText("Source of the Citation:");
        label3.setAutoSize(true);

        label2.setLocation(new Point(12, 18));
        label2.setSize(new Point(410, 25));
        label2.setTabIndex(0);
        label2.setTabStop(false);
        label2.setText("Choose or enter the descriptions that best describe the source of the citation where you found this item.");

        sourceComboBox.setLocation(new Point(12, 66));
        sourceComboBox.setSize(new Point(194, 21));
        sourceComboBox.setTabIndex(2);
        sourceComboBox.setText("");
        sourceComboBox.setSorted(true);
        sourceComboBox.setItems(new Object[] {
                                "Bibliography", 
                                "Electronic Database", 
                                "Reference"});
        sourceComboBox.addOnSelectedIndexChanged(new EventHandler(this.sourceComboBox_selectedIndexChanged));

        okButton.setLocation(new Point(284, 208));
        okButton.setSize(new Point(75, 23));
        okButton.setTabIndex(1);
        okButton.setText("OK");
        okButton.setDialogResult(DialogResult.OK);

        cancelButton.setLocation(new Point(366, 208));
        cancelButton.setSize(new Point(75, 23));
        cancelButton.setTabIndex(2);
        cancelButton.setText("Cancel");
        cancelButton.setDialogResult(DialogResult.CANCEL);

        this.setNewControls(new Control[] {
                            cancelButton, 
                            okButton, 
                            citationGroupBox});
        citationGroupBox.setNewControls(new Control[] {
                                        sourceComboBox, 
                                        label2, 
                                        label3, 
                                        commentEdit, 
                                        label5, 
                                        label4, 
                                        sourceEdit});
    }

	/**
	 * The main entry point for the application. 
	 *
	 * @param args Array of parameters passed to the application
	 * via the command line.
	 */
	public static void main(String args[])
	{
		Application.run(new MorePeriodicalInfoForm());
	}
}
