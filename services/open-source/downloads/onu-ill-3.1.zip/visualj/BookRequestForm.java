import com.ms.wfc.app.*;
import com.ms.wfc.core.*;
import com.ms.wfc.ui.*;
import com.ms.wfc.html.*;

import java.text.*;
import java.io.IOException;

/**
 * This class can take a variable number of parameters on the command
 * line. Program execution begins with the main() method. The class
 * constructor is not invoked unless an object of type 'BookRequestForm'
 * created in the main() method.
 */
public class BookRequestForm extends Form implements ONU_ILL_CONST
{
    /*
    ** Attributes
    */
    ItemInfo item = new ItemInfo( );

    public BookRequestForm( )
    {
		super( );

		// Required for Visual J++ Form Designer support
		initForm();		

        // Pre-enter the default need before date
        DateFormat df = DateFormat.getDateInstance( DateFormat.LONG );
        needBeforeEdit.setText( df.format( DEFAULT_NEEDBEFORE_DATE ) );
    }    
    
    public BookRequestForm( ItemInfo item )
    {
		super( );

		// Required for Visual J++ Form Designer support
		initForm();		
        
        this.item = item;
        
        // Set the fields to the user's entries
        needBeforeEdit.setText( item.need_before_date );
        authorEdit.setText( item.author );
        titleEdit.setText( item.title );
        publisherEdit.setText( item.publisher );
        volumeEdit.setText( item.volume );
        editionEdit.setText( item.edition );
        pubYearEdit.setText( item.publication_date );
        isbnEdit.setText( item.isbn );
    }

	/**
	 * BookRequestForm overrides dispose so it can clean up the
	 * component list.
	 */
	public void dispose()
	{
		super.dispose();
		components.dispose();
	}

    /**
     * Method to handle the okButton event.  This checks for 
     * completeness and correctness, including the proper date
     * format.
     */
    private void okButton_click(Object source, Event e)
    {
        if ( titleEdit.getText( ).equals( "" ) ||
             authorEdit.getText( ).equals( "" ) ||
             needBeforeEdit.getText( ).equals( "" ) ||
             noRadioButton.getChecked( ) )
        {
            String msgString = new String( "You did not fill in the following required fields:\n\n" );
            if ( titleEdit.getText( ).equals( "" ) )
                msgString += "Book Title\n";
            if ( authorEdit.getText( ).equals( "" ) )
                msgString += "Author's Name\n";
            if ( needBeforeEdit.getText( ).equals( "" ) )
                msgString += "Date Needed By\n";
            if ( noRadioButton.getChecked( ) )
                msgString += "Checked Benner Library Holdings\n";
            MessageBox.show( msgString, "ONU Interlibrary Loan",
                             MessageBox.OK | MessageBox.ICONWARNING );
        }
        else
        {
            item.ill_service_type = BOOK_REQUEST;
            item.author = authorEdit.getText( );
            item.edition = editionEdit.getText( );
            item.isbn = isbnEdit.getText( );
            item.publication_date = pubYearEdit.getText( );
            item.publisher = publisherEdit.getText( );
            item.title = titleEdit.getText( );
            item.volume = volumeEdit.getText( );
            DateFormat df = DateFormat.getDateInstance( DateFormat.LONG );
            try {
                // Attempt to parse the date before setting 
                // it in the item record
                String dateString = new String(
                    ILLDate.getFormattedDate( df.parse( needBeforeEdit.getText( ) ) ) );
                item.need_before_date = needBeforeEdit.getText( );
            }
            catch ( ParseException parse ) {
                String msgString = new String( "The date was entered in the wrong format.\n\n" );
                String dateString = new String( df.format( DEFAULT_NEEDBEFORE_DATE ) );
                msgString += "The proper format looks like\n";
                msgString += "\"" + dateString + "\"";
                msgString += " or \"" + dateString.substring( 0, 3 ) +
                             dateString.substring( dateString.indexOf( ' ' ) ) +
                             "\"";
                MessageBox.show( msgString, "ONU Interlibrary Loan",
                                 MessageBox.OK | MessageBox.ICONWARNING );
                return;
            }
            
            this.setDialogResult( DialogResult.OK );
            this.setVisible( false );
        }
    }

    private void holdingsButton_click(Object source, Event e)
    {
        try {
            String execApp = new String( DEFAULT_BOOK_APP );
            String execParam = new String( DEFAULT_BOOK_PARAM );
            // TODO:  Get information from administrative file.
            
            String execString = new String( "\"" + execApp + "\" \"" 
                                            + execParam + "\"" );
            Runtime.getRuntime( ).exec( execString );
        }
        catch ( IOException runtimeException ) {
            String msgString = new String( "Benner Library Book Holdings could not be opened.\n\n" );
            msgString += runtimeException.toString( );
            MessageBox.show( msgString, "ONU Interlibrary Loan",
                             MessageBox.OK | MessageBox.ICONERROR );
        }
    }

    private void moreButton_click(Object source, Event e)
    {
        MoreBookInfoForm moreInfoForm = new MoreBookInfoForm( );
        if ( moreInfoForm.showDialog( ) == DialogResult.OK ) {
            item.oclc_no = moreInfoForm.oclcNumEdit.getText( );
            item.patron_notes = new String( "ERIC No.:  " + 
                                            moreInfoForm.ericNumEdit.getText( ) );
            if ( moreInfoForm.dissertationCheckBox.getChecked( ) ) {
                item.dissertation = new String( "Dissertation/Thesis" );
            }
            if ( moreInfoForm.proceedingsCheckBox.getChecked( ) ) {
                if ( !item.patron_notes.equals( "" ) )
                    item.patron_notes += "; ";
                item.patron_notes += "Conference Proceedings";
            }
            if ( !moreInfoForm.sourceComboBox.getText( ).equals( "" ) ) {
                if ( !item.patron_notes.equals( "" ) )
                    item.patron_notes += "; ";
                item.patron_notes += moreInfoForm.sourceComboBox.getText( );
                if ( !moreInfoForm.sourceEdit.getText( ).equals( "" ) )
                    item.patron_notes += ": " + moreInfoForm.sourceEdit.getText( );
                item.verification_reference_source = moreInfoForm.sourceComboBox.getText( );
            }
            if ( !moreInfoForm.commentEdit.getText( ).equals( "" ) ) {
                if ( !item.patron_notes.equals( "" ) )
                    item.patron_notes += "; ";
                item.patron_notes += moreInfoForm.commentEdit.getText( );
            }
        }
    }

    /**
     * NOTE: The following code is required by the Visual J++ form
     * designer.  It can be modified using the form editor.  Do not
     * modify it using the code editor.
     */
    Container components = new Container();
    Label label1 = new Label();
    Label label2 = new Label();
    GroupBox bookInfoGroupBox = new GroupBox();
    Label label10 = new Label();
    Button cancelButton = new Button();
    Button okButton = new Button();
    GroupBox holdingsGroupBox = new GroupBox();
    Label label12 = new Label();
    Edit needBeforeEdit = new Edit();
    Label label11 = new Label();
    Button moreButton = new Button();
    Label label4 = new Label();
    Edit authorEdit = new Edit();
    Label label3 = new Label();
    Edit titleEdit = new Edit();
    Label label5 = new Label();
    Edit isbnEdit = new Edit();
    Label label6 = new Label();
    Edit editionEdit = new Edit();
    Label label7 = new Label();
    Edit volumeEdit = new Edit();
    Label label8 = new Label();
    Edit publisherEdit = new Edit();
    Label label9 = new Label();
    Edit pubYearEdit = new Edit();
    Label label13 = new Label();
    RadioButton yesRadioButton = new RadioButton();
    RadioButton noRadioButton = new RadioButton();
    Button holdingsButton = new Button();

    private void initForm()
    {
        label1.setFont(new Font("Times New Roman", 20.0f, FontSize.POINTS, FontWeight.BOLD, true, false, false, CharacterSet.DEFAULT, 0));
        label1.setLocation(new Point(8, 8));
        label1.setSize(new Point(428, 30));
        label1.setTabIndex(0);
        label1.setTabStop(false);
        label1.setText("Book Request Form");
        label1.setAutoSize(true);

        label2.setFont(new Font("MS Sans Serif", 8.0f, FontSize.POINTS, FontWeight.BOLD, false, false, false, CharacterSet.DEFAULT, 0));
        label2.setLocation(new Point(8, 44));
        label2.setSize(new Point(344, 13));
        label2.setTabIndex(1);
        label2.setTabStop(false);
        label2.setText("NOTE:  Fields in Bold are required to complete this request.");
        label2.setAutoSize(true);

        bookInfoGroupBox.setLocation(new Point(8, 64));
        bookInfoGroupBox.setSize(new Point(432, 234));
        bookInfoGroupBox.setTabIndex(2);
        bookInfoGroupBox.setTabStop(false);
        bookInfoGroupBox.setText("Book Information");

        label10.setFont(new Font("MS Sans Serif", 8.0f, FontSize.POINTS, FontWeight.BOLD, false, false, false, CharacterSet.DEFAULT, 0));
        label10.setLocation(new Point(12, 186));
        label10.setSize(new Point(186, 13));
        label10.setTabIndex(14);
        label10.setTabStop(false);
        label10.setText("The date this item is needed by.");
        label10.setAutoSize(true);

        cancelButton.setLocation(new Point(364, 396));
        cancelButton.setSize(new Point(75, 23));
        cancelButton.setTabIndex(6);
        cancelButton.setText("Cancel");
        cancelButton.setDialogResult(DialogResult.CANCEL);

        this.setText("Book Request Form");
        this.setAutoScaleBaseSize(13);
        this.setBorderStyle(FormBorderStyle.FIXED_DIALOG);
        this.setCancelButton(cancelButton);
        this.setClientSize(new Point(450, 431));
        this.setMaximizeBox(false);
        this.setMinimizeBox(false);
        this.setShowInTaskbar(false);
        this.setStartPosition(FormStartPosition.CENTER_SCREEN);

        okButton.setLocation(new Point(284, 396));
        okButton.setSize(new Point(75, 23));
        okButton.setTabIndex(5);
        okButton.setText("OK");
        okButton.addOnClick(new EventHandler(this.okButton_click));

        holdingsGroupBox.setLocation(new Point(8, 304));
        holdingsGroupBox.setSize(new Point(432, 84));
        holdingsGroupBox.setTabIndex(3);
        holdingsGroupBox.setTabStop(false);
        holdingsGroupBox.setText("Benner Library Holdings");

        label12.setFont(new Font("MS Sans Serif", 8.0f, FontSize.POINTS, FontWeight.BOLD, false, false, false, CharacterSet.DEFAULT, 0));
        label12.setLocation(new Point(12, 18));
        label12.setSize(new Point(276, 13));
        label12.setTabIndex(0);
        label12.setTabStop(false);
        label12.setText("Have you checked Benner Library for this item.");
        label12.setAutoSize(true);

        needBeforeEdit.setLocation(new Point(12, 202));
        needBeforeEdit.setSize(new Point(194, 20));
        needBeforeEdit.setTabIndex(15);
        needBeforeEdit.setText("");

        label11.setLocation(new Point(226, 186));
        label11.setSize(new Point(194, 38));
        label11.setTabIndex(16);
        label11.setTabStop(false);
        label11.setText("The default date is entered for you.  Use the same date format as indicated by the preset date.");

        moreButton.setLocation(new Point(10, 396));
        moreButton.setSize(new Point(75, 23));
        moreButton.setTabIndex(4);
        moreButton.setText("More");
        moreButton.addOnClick(new EventHandler(this.moreButton_click));

        label4.setFont(new Font("MS Sans Serif", 8.0f, FontSize.POINTS, FontWeight.BOLD, false, false, false, CharacterSet.DEFAULT, 0));
        label4.setLocation(new Point(12, 60));
        label4.setSize(new Point(120, 13));
        label4.setTabIndex(2);
        label4.setTabStop(false);
        label4.setText("Author (Last, First)");
        label4.setAutoSize(true);

        authorEdit.setLocation(new Point(12, 76));
        authorEdit.setSize(new Point(194, 20));
        authorEdit.setTabIndex(3);
        authorEdit.setText("");

        label3.setFont(new Font("MS Sans Serif", 8.0f, FontSize.POINTS, FontWeight.BOLD, false, false, false, CharacterSet.DEFAULT, 0));
        label3.setLocation(new Point(12, 20));
        label3.setSize(new Point(100, 13));
        label3.setTabIndex(0);
        label3.setTabStop(false);
        label3.setText("Book Title");
        label3.setAutoSize(true);

        titleEdit.setLocation(new Point(12, 34));
        titleEdit.setSize(new Point(408, 20));
        titleEdit.setTabIndex(1);
        titleEdit.setText("");

        label5.setLocation(new Point(226, 60));
        label5.setSize(new Point(196, 13));
        label5.setTabIndex(4);
        label5.setTabStop(false);
        label5.setText("ISBN (Recommended for quicker service)");
        label5.setAutoSize(true);

        isbnEdit.setLocation(new Point(226, 76));
        isbnEdit.setSize(new Point(194, 20));
        isbnEdit.setTabIndex(5);
        isbnEdit.setText("");

        label6.setLocation(new Point(12, 102));
        label6.setSize(new Point(100, 13));
        label6.setTabIndex(6);
        label6.setTabStop(false);
        label6.setText("Edition");
        label6.setAutoSize(true);

        editionEdit.setLocation(new Point(12, 118));
        editionEdit.setSize(new Point(194, 20));
        editionEdit.setTabIndex(7);
        editionEdit.setText("");

        label7.setLocation(new Point(226, 102));
        label7.setSize(new Point(100, 13));
        label7.setTabIndex(8);
        label7.setTabStop(false);
        label7.setText("Volume");
        label7.setAutoSize(true);

        volumeEdit.setLocation(new Point(226, 118));
        volumeEdit.setSize(new Point(194, 20));
        volumeEdit.setTabIndex(9);
        volumeEdit.setText("");

        label8.setLocation(new Point(12, 144));
        label8.setSize(new Point(100, 13));
        label8.setTabIndex(10);
        label8.setTabStop(false);
        label8.setText("Publisher");
        label8.setAutoSize(true);

        publisherEdit.setLocation(new Point(12, 160));
        publisherEdit.setSize(new Point(194, 20));
        publisherEdit.setTabIndex(11);
        publisherEdit.setText("");

        label9.setLocation(new Point(226, 144));
        label9.setSize(new Point(100, 13));
        label9.setTabIndex(12);
        label9.setTabStop(false);
        label9.setText("Year Published");
        label9.setAutoSize(true);

        pubYearEdit.setLocation(new Point(226, 160));
        pubYearEdit.setSize(new Point(194, 20));
        pubYearEdit.setTabIndex(13);
        pubYearEdit.setText("");
        pubYearEdit.setMaxLength(4);

        label13.setLocation(new Point(12, 32));
        label13.setSize(new Point(406, 13));
        label13.setTabIndex(1);
        label13.setTabStop(false);
        label13.setText("This item cannot be requested if Benner Library has this item in its holdings.");
        label13.setAutoSize(true);

        yesRadioButton.setLocation(new Point(12, 50));
        yesRadioButton.setSize(new Point(42, 25));
        yesRadioButton.setTabIndex(2);
        yesRadioButton.setText("Yes");

        noRadioButton.setLocation(new Point(56, 50));
        noRadioButton.setSize(new Point(38, 25));
        noRadioButton.setTabIndex(3);
        noRadioButton.setTabStop(true);
        noRadioButton.setText("No");
        noRadioButton.setChecked(true);

        holdingsButton.setLocation(new Point(110, 52));
        holdingsButton.setSize(new Point(308, 23));
        holdingsButton.setTabIndex(4);
        holdingsButton.setText("Check Benner Library Book Holdings");
        holdingsButton.addOnClick(new EventHandler(this.holdingsButton_click));

        this.setNewControls(new Control[] {
                            holdingsGroupBox, 
                            moreButton, 
                            okButton, 
                            cancelButton, 
                            bookInfoGroupBox, 
                            label2, 
                            label1});
        bookInfoGroupBox.setNewControls(new Control[] {
                                        needBeforeEdit, 
                                        label11, 
                                        label10, 
                                        pubYearEdit, 
                                        label9, 
                                        publisherEdit, 
                                        label8, 
                                        volumeEdit, 
                                        label7, 
                                        editionEdit, 
                                        label6, 
                                        isbnEdit, 
                                        label5, 
                                        titleEdit, 
                                        label3, 
                                        authorEdit, 
                                        label4});
        holdingsGroupBox.setNewControls(new Control[] {
                                        label13, 
                                        holdingsButton, 
                                        noRadioButton, 
                                        yesRadioButton, 
                                        label12});
    }

    public static void main( String args[] )
    {
        Application.run( new BookRequestForm( ) );
    }

}
