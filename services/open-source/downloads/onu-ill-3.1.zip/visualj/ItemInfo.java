/*  ItemInfo.java
**
**  by Bryan Wilhelm, Olivet Nazarene University
**  September 11, 1998
**
**  Contains the item information for the Book and Periodical forms.
*/

public class ItemInfo implements ONU_ILL_CONST
{
    public String 
        need_before_date,
        held_medium_type, // PRINTED_HMT (This field could be used to 
                          // indicated other media such as audio/video, 
                          // microfilm, etc.).  It is included here for
                          // future use.
        author,           // Books go in author, while
                          // periodicals go in author_of_article.
        title,
        publisher,
        volume,
        issue,
        edition,
        publication_date,  // Books go in publication_date, while
                           // periodicals go in publication_date_of_component.
        title_of_article,
        pagination,
        isbn,
        issn,
        oclc_no,
        dissertation,
        verification_reference_source,
        patron_notes;

    public short
        ill_service_type;  // BOOK_REQUEST (1) or PERIODICAL_REQUEST (2)

    // constructor
    public ItemInfo( )
    {
        need_before_date = new String( );
        held_medium_type = new String( "" + 1 );  // PRINTED_HMT = 1
            // This is the same for all materials at this time.  Later
            // versions may include support for multimedia, audio-visual,
            // etc.
        author = new String( );
        title = new String( );
        publisher = new String( );
        volume = new String( );
        issue = new String( );
        edition = new String( );
        publication_date = new String( );
        title_of_article = new String( );
        pagination = new String( );
        isbn = new String( );
        issn = new String( );
        oclc_no = new String( );
        dissertation = new String( );
        verification_reference_source = new String( );
        ill_service_type = 0;
    }
    
    public String toString( )
    {
        String retstr = new String( );
        if ( this.ill_service_type == BOOK_REQUEST ) {
            retstr = "\"" + title + "\", by " + author;
            if ( !publisher.equals( "" ) ||
                 !volume.equals( "" ) ||
                 !edition.equals( "" ) ||
                 !publication_date.equals( "" ) ||
                 !isbn.equals( "" ) )
            {
                boolean prev = false;
                retstr += " (";
                if ( !volume.equals( "" ) ) {
                    retstr += "Volume: " + volume;
                    prev = true;
                }
                if ( !edition.equals( "" ) ) {
                    if ( prev ) retstr += "; ";
                    else prev = true;
                    retstr += "Edition: " + edition;
                }
                if ( !publisher.equals( "" ) && !publication_date.equals( "" ) ) {
                    if ( prev ) retstr += "; ";
                    else prev = true;
                    retstr += publisher + ", " + publication_date;
                } else if ( !publisher.equals( "" ) ) {
                    if ( prev ) retstr += "; ";
                    else prev = true;
                    retstr += publisher;
                } else if ( !publication_date.equals( "" ) ) {
                    if ( prev ) retstr += "; ";
                    else prev = true;
                    retstr += publication_date;
                }
                if ( !isbn.equals( "" ) ) {
                    if ( prev ) retstr += "; ";
                    else prev = true;
                    retstr += "ISBN: " + isbn;
                }
                
                retstr += ").";
            }
            else
            {
                retstr += ".";
            }
        }
        else
        {
            retstr = "\"" + title_of_article + "\", in \"" + title + "\"";
            if ( !author.equals( "" ) )
                retstr += " by " + author;
            
            retstr += " (";
                
            boolean prev = false;
            if ( !volume.equals( "" ) ||
                 !issue.equals( "" ) )
            {
                if ( !volume.equals( "" ) ) {
                    retstr += "Volume: " + volume;
                    prev = true;
                }
                if ( !issue.equals( "" ) ) {
                    if ( prev ) retstr += "; ";
                    else prev = true;
                    retstr += "Issue: " + issue;
                }
            }
            
            if ( prev ) retstr += "; ";
            retstr += publication_date + "; Pages: " + pagination;
            retstr += ").";
         }
        
        return new String( retstr );
    }
}