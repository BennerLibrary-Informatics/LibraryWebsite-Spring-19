import com.ms.wfc.app.*;
import com.ms.wfc.core.*;
import com.ms.wfc.ui.*;
import com.ms.wfc.html.*;

/**
 * This class can take a variable number of parameters on the command
 * line. Program execution begins with the main() method. The class
 * constructor is not invoked unless an object of type 'MoreBookInfoForm'
 * created in the main() method.
 */
public class MoreBookInfoForm extends Form
{
	public MoreBookInfoForm( )
	{
		super();

		// Required for Visual J++ Form Designer support
		initForm();		

		// TODO: Add any constructor code after initForm call
        
	}

	/**
	 * MoreBookInfoForm overrides dispose so it can clean up the
	 * component list.
	 */
	public void dispose()
	{
		super.dispose();
		components.dispose();
	}

    private void oclcNumCheckBox_checkStateChanged(Object source, Event e)
    {
        oclcNumEdit.setVisible( oclcNumCheckBox.getChecked( ) );
    }

    private void ericNumCheckBox_checkStateChanged(Object source, Event e)
    {
        ericNumEdit.setVisible( ericNumCheckBox.getChecked( ) );
    }

    private void sourceComboBox_selectedIndexChanged(Object source, Event e)
    {
        if ( sourceComboBox.getSelectedIndex( ) == 1 ) {
            label4.setText( "Enter the database and keywords used." );
            sourceEdit.setVisible( true );
        }
        else
        {
            label4.setText( "Enter the title and page of reference." );
            sourceEdit.setVisible( true );
        }
    }

    /**
     * NOTE: The following code is required by the Visual J++ form
     * designer.  It can be modified using the form editor.  Do not
     * modify it using the code editor.
     */
    Container components = new Container();
    Label label1 = new Label();
    GroupBox bookIDGroupBox = new GroupBox();
    CheckBox oclcNumCheckBox = new CheckBox();
    Edit oclcNumEdit = new Edit();
    CheckBox ericNumCheckBox = new CheckBox();
    Edit ericNumEdit = new Edit();
    CheckBox dissertationCheckBox = new CheckBox();
    CheckBox proceedingsCheckBox = new CheckBox();
    GroupBox citationGroupBox = new GroupBox();
    ComboBox sourceComboBox = new ComboBox();
    Label label2 = new Label();
    Label label3 = new Label();
    Edit commentEdit = new Edit();
    Label label5 = new Label();
    Button okButton = new Button();
    Button cancelButton = new Button();
    Label label4 = new Label();
    Edit sourceEdit = new Edit();

    private void initForm()
    {
        label1.setLocation(new Point(8, 8));
        label1.setSize(new Point(432, 26));
        label1.setTabIndex(0);
        label1.setTabStop(false);
        label1.setText("NOTE:  Nothing in this dialog is required, but will assist librarians in completing your request in a timely manner.  ");

        bookIDGroupBox.setLocation(new Point(8, 44));
        bookIDGroupBox.setSize(new Point(434, 122));
        bookIDGroupBox.setTabIndex(1);
        bookIDGroupBox.setTabStop(false);
        bookIDGroupBox.setText("Book Classification and Identification");

        oclcNumCheckBox.setLocation(new Point(12, 18));
        oclcNumCheckBox.setSize(new Point(178, 25));
        oclcNumCheckBox.setTabIndex(0);
        oclcNumCheckBox.setText("OCLC Number (from FirstSearch)");
        oclcNumCheckBox.addOnCheckStateChanged(new EventHandler(this.oclcNumCheckBox_checkStateChanged));

        oclcNumEdit.setLocation(new Point(228, 18));
        oclcNumEdit.setSize(new Point(194, 20));
        oclcNumEdit.setTabIndex(1);
        oclcNumEdit.setText("");
        oclcNumEdit.setVisible(false);

        ericNumCheckBox.setLocation(new Point(12, 42));
        ericNumCheckBox.setSize(new Point(204, 25));
        ericNumCheckBox.setTabIndex(2);
        ericNumCheckBox.setText("ERIC Number (from ERIC Database)");
        ericNumCheckBox.addOnCheckStateChanged(new EventHandler(this.ericNumCheckBox_checkStateChanged));

        ericNumEdit.setLocation(new Point(228, 42));
        ericNumEdit.setSize(new Point(194, 20));
        ericNumEdit.setTabIndex(3);
        ericNumEdit.setText("");
        ericNumEdit.setVisible(false);

        dissertationCheckBox.setLocation(new Point(12, 66));
        dissertationCheckBox.setSize(new Point(196, 25));
        dissertationCheckBox.setTabIndex(4);
        dissertationCheckBox.setText("Published Dissertation or Thesis");

        proceedingsCheckBox.setLocation(new Point(12, 90));
        proceedingsCheckBox.setSize(new Point(190, 25));
        proceedingsCheckBox.setTabIndex(5);
        proceedingsCheckBox.setText("Published Conference Proceedings");

        citationGroupBox.setLocation(new Point(8, 172));
        citationGroupBox.setSize(new Point(434, 194));
        citationGroupBox.setTabIndex(2);
        citationGroupBox.setTabStop(false);
        citationGroupBox.setText("Citation Information");

        sourceComboBox.setLocation(new Point(12, 66));
        sourceComboBox.setSize(new Point(194, 21));
        sourceComboBox.setTabIndex(2);
        sourceComboBox.setText("");
        sourceComboBox.setSorted(true);
        sourceComboBox.setItems(new Object[] {
                                "Bibliography", 
                                "Electronic Database", 
                                "Reference"});
        sourceComboBox.addOnSelectedIndexChanged(new EventHandler(this.sourceComboBox_selectedIndexChanged));

        label2.setLocation(new Point(12, 18));
        label2.setSize(new Point(410, 25));
        label2.setTabIndex(0);
        label2.setTabStop(false);
        label2.setText("Choose or enter the descriptions that best describe the source of the citation where you found this item.");

        label3.setLocation(new Point(12, 50));
        label3.setSize(new Point(112, 13));
        label3.setTabIndex(1);
        label3.setTabStop(false);
        label3.setText("Source of the Citation:");
        label3.setAutoSize(true);

        commentEdit.setLocation(new Point(12, 112));
        commentEdit.setSize(new Point(410, 70));
        commentEdit.setTabIndex(6);
        commentEdit.setText("");
        commentEdit.setMultiline(true);

        label5.setLocation(new Point(12, 96));
        label5.setSize(new Point(324, 13));
        label5.setTabIndex(5);
        label5.setTabStop(false);
        label5.setText("Enter any addition comments about this book in the field below.");
        label5.setAutoSize(true);

        okButton.setLocation(new Point(286, 372));
        okButton.setSize(new Point(75, 23));
        okButton.setTabIndex(3);
        okButton.setText("OK");
        okButton.setDialogResult(DialogResult.OK);

        cancelButton.setLocation(new Point(366, 372));
        cancelButton.setSize(new Point(75, 23));
        cancelButton.setTabIndex(4);
        cancelButton.setText("Cancel");
        cancelButton.setDialogResult(DialogResult.CANCEL);

        this.setText("Additional Book Request Information");
        this.setAcceptButton(okButton);
        this.setAutoScaleBaseSize(13);
        this.setBorderStyle(FormBorderStyle.FIXED_DIALOG);
        this.setCancelButton(cancelButton);
        this.setClientSize(new Point(450, 404));
        this.setMaximizeBox(false);
        this.setMinimizeBox(false);
        this.setStartPosition(FormStartPosition.CENTER_SCREEN);

        label4.setLocation(new Point(228, 50));
        label4.setSize(new Point(194, 13));
        label4.setTabIndex(3);
        label4.setTabStop(false);
        label4.setText("");
        label4.setAutoSize(true);

        sourceEdit.setLocation(new Point(228, 66));
        sourceEdit.setSize(new Point(194, 20));
        sourceEdit.setTabIndex(4);
        sourceEdit.setText("");
        sourceEdit.setVisible(false);

        this.setNewControls(new Control[] {
                            cancelButton, 
                            okButton, 
                            citationGroupBox, 
                            bookIDGroupBox, 
                            label1});
        bookIDGroupBox.setNewControls(new Control[] {
                                      proceedingsCheckBox, 
                                      dissertationCheckBox, 
                                      ericNumEdit, 
                                      ericNumCheckBox, 
                                      oclcNumEdit, 
                                      oclcNumCheckBox});
        citationGroupBox.setNewControls(new Control[] {
                                        sourceEdit, 
                                        label4, 
                                        label5, 
                                        commentEdit, 
                                        label3, 
                                        label2, 
                                        sourceComboBox});
    }

	/**
	 * The main entry point for the application. 
	 *
	 * @param args Array of parameters passed to the application
	 * via the command line.
	 */
	public static void main(String args[])
	{
		Application.run(new MoreBookInfoForm());
	}
}
