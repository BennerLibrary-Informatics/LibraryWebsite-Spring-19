import com.ms.wfc.app.*;
import com.ms.wfc.core.*;
import com.ms.wfc.ui.*;
import com.ms.wfc.html.*;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * This class can take a variable number of parameters on the command
 * line. Program execution begins with the main() method. The class
 * constructor is not invoked unless an object of type 'RequestSubmitForm'
 * created in the main() method.
 */
public class      RequestSubmitForm 
       extends    Form  
       implements ILL_API, 
                  ILL_ASN,
                  ONU_ILL_CONST
{
    PatronInfo  patronInfo;
    Vector      requestRecord = new Vector( );
        // Vector of ItemInfo
    int         numRequests;
    int         requestsSubmitted = 0;
    
    Vector      requests = new Vector( );
        // Vector of IsoIllRequests
    IsoIllApdu  apdu;
    BerString   berRec,
                berResponse;
    Socket      connection;
    DataOutputStream output;
    DataInputStream  input;
    
    short serviceCode = 3;
    
    boolean errorFlag = false;
    boolean exceptionFlag = false;
    Vector  errorRequests = new Vector( MAX_REQUESTS );
    
	public RequestSubmitForm( )
	{
		super();

		// Required for Visual J++ Form Designer support
		initForm();		

		// TODO: Add any constructor code after initForm call
    }
    
	public RequestSubmitForm( PatronInfo pinfo, 
                              Vector items,
                              int requests )
	{
		super();

		// Required for Visual J++ Form Designer support
		initForm();		

		// TODO: Add any constructor code after initForm call
        patronInfo = pinfo;
        requestRecord = items;
        numRequests = requests;
        setVisible( true );
        submitRequest( );
	}

	/**
	 * RequestSubmitForm overrides dispose so it can clean up the
	 * component list.
	 */
	public void dispose()
	{
		super.dispose();
		components.dispose();
	}
    
    private void submitRequest( )
    {
        int progressStep = (int) ( 100 / ( 5 * numRequests + 3 ) );
        int x;
        boolean transactionNotComplete;
        
        progressBar.setValue( 0 );
        progressBar.setStep( progressStep );
        
        for ( x = 0; x < numRequests; x++ ) {
            label1.setText( "Compiling information for request " + ( x + 1 ) );
            progressBar.step( );
            IsoIllRequest request = new IsoIllRequest( );
            request.service_date = ILLDate.getFormattedDate( new Date( ) );
            request.transaction_qualifier = 
                new String( LIB_SYMBOL + ( new Date( ) ).getTime( ) );
                // The transaction qualifier must be universally unique
            request.transaction_group_qualifier =
                new String( LIB_SYMBOL + "-ILL-WIN-APP" );
            request.user_pid = System.getProperty( "user.name" );
            request.requester_id = new String( LIB_SYMBOL );
            request.authorization = new String( AUTHORIZATION );
            request.password = new String( PASSWORD );
            request.delivery_name = new String( INSTITUTION_NAME );
            request.delivery_extension = new String( DEL_EXT );
            request.delivery_street_no = new String( DEL_STREET );
            request.delivery_po_box = new String( DEL_PO_BOX );
            request.delivery_city = new String( DEL_CITY );
            request.delivery_region = new String( DEL_STATE );
            request.delivery_country = new String( DEL_COUNTRY );
            request.delivery_postal_code = new String( DEL_ZIP_CODE );
            request.delivery_service = new String( SHIP_VIA_SERVICE );
            request.electronic_delivery_description = new String( ELECTRONIC_SERVICE );
            request.fax_address = new String( DEL_FAX );
            request.email_address = new String( DEL_EMAIL );
            request.need_before_date = ( (ItemInfo) requestRecord.elementAt( x ) ).need_before_date;
            request.patron_id = patronInfo.patron_id;
            request.patron_full_name = patronInfo.patron_full_name;
            request.p_home_street_no = patronInfo.p_home_street_no;
            request.p_home_po_box = patronInfo.p_home_po_box;
            request.p_home_city = patronInfo.p_home_city;
            request.p_home_region = patronInfo.p_home_region;
            request.p_home_country = patronInfo.p_home_country;
            request.p_home_postal_code = patronInfo.p_home_postal_code;
            request.patron_phone = patronInfo.patron_phone;
            request.patron_email = patronInfo.patron_email;
            request.patron_fax = patronInfo.patron_fax;
            request.patron_status = patronInfo.patron_status;
            request.patron_notes = ( (ItemInfo) requestRecord.elementAt( x ) ).patron_notes;
            request.held_medium_type = ( (ItemInfo) requestRecord.elementAt( x ) ).held_medium_type;
            request.author = 
                ( ( (ItemInfo) requestRecord.elementAt( x ) ).ill_service_type == BOOK_REQUEST ?
                ( (ItemInfo) requestRecord.elementAt( x ) ).author : "" );
            request.title = ( (ItemInfo) requestRecord.elementAt( x ) ).title;
            request.publisher = ( (ItemInfo) requestRecord.elementAt( x ) ).publisher;
            request.volume = ( (ItemInfo) requestRecord.elementAt( x ) ).volume;
            request.issue = ( (ItemInfo) requestRecord.elementAt( x ) ).issue;
            request.edition = ( (ItemInfo) requestRecord.elementAt( x ) ).edition;
            request.publication_date = 
                ( ( (ItemInfo) requestRecord.elementAt( x ) ).ill_service_type == BOOK_REQUEST ?
                ( (ItemInfo) requestRecord.elementAt( x ) ).publication_date : "" );
            request.publication_date_of_component = 
                ( ( (ItemInfo) requestRecord.elementAt( x ) ).ill_service_type == PERIODICAL_REQUEST ?
                ( (ItemInfo) requestRecord.elementAt( x ) ).publication_date : "" );
            request.author_of_article =
                ( ( (ItemInfo) requestRecord.elementAt( x ) ).ill_service_type == PERIODICAL_REQUEST ?
                ( (ItemInfo) requestRecord.elementAt( x ) ).author : "" );
            request.title_of_article = ( (ItemInfo) requestRecord.elementAt( x ) ).title_of_article;
            request.pagination = ( (ItemInfo) requestRecord.elementAt( x ) ).pagination;
            request.isbn = ( (ItemInfo) requestRecord.elementAt( x ) ).isbn;
            request.issn = ( (ItemInfo) requestRecord.elementAt( x ) ).issn;
            request.oclc_no = ( (ItemInfo) requestRecord.elementAt( x ) ).oclc_no;
            request.verification_reference_source = ( (ItemInfo) requestRecord.elementAt( x ) ).verification_reference_source;
            request.dissertation = ( (ItemInfo) requestRecord.elementAt( x ) ).dissertation;
            request.copyright_compliance = new String( COPYRIGHT );
            request.send_to_list = new String( "" );
            //request.send_to_list = new String( LENDER_LIST );
            request.requester_note = 
                ( ( (ItemInfo) requestRecord.elementAt( x ) ).ill_service_type == BOOK_REQUEST ?
                BOOK_DATA : PER_DATA );
            request.oclc_ill_service_type = serviceCode;
            request.ill_service_type = ( (ItemInfo) requestRecord.elementAt( x ) ).ill_service_type;
            request.preference = UNORDERED;
            request.change_send_to = ( serviceCode == 1 );

            requests.addElement( request );
        }
        
        try {
            label1.setText( "Connecting to the remote host, OCLC" );
            connection = new Socket( OCLC_SERVER, OCLC_PORT );
            progressBar.step( );

            label1.setText( "Creating I/0 data streams to remote host." );
            output = new DataOutputStream( connection.getOutputStream( ) );
            input = new DataInputStream( connection.getInputStream( ) );
            progressBar.step( );

            for ( x = 0; x < numRequests; x++ ) {
                // Build the ASN.1/BER record
                label1.setText( "Building BER record for request " + ( x + 1 ) );
                berRec = ( (IsoIllRequest) requests.elementAt( x ) ).BuildIsoIllRequest( );
                progressBar.step( );

                // Send the record to OCLC
                label1.setText( "Sending request " + ( x + 1 ) +
                                " to the remote host." );
                berRec.writeBerString( output );
                progressBar.step( );

                // Get their response
                label1.setText( "Receiving status report from the remote host." );
                byte response[] = new byte[ 256 ];
                if ( input.read( response ) <= 0 )
                    throw new IOException( "No Response received." );
                else
                    berResponse = new BerString( response );
                progressBar.step( );

                // Process response
                label1.setText( "Processing status report." );
                apdu = new IsoIllApdu( berResponse );

                transactionNotComplete = true;
                
                switch ( apdu.type ) {
                case ( STATUS_OR_ERROR_REPORT_APDU ):
                    // current_state does not need to be checked for
                    // because this is not inquiring about a previously
                    // requested item.
                    if ( apdu.report.current_state != 0 ) {
                        label1.setText( "Request submitted successfully." );
                        requestsSubmitted++;
                    } else if ( apdu.report.error_occurred != 0 ) {
                        errorFlag = true;
                        label1.setText( "" + apdu.report.errors.size( ) +
                                        " errors occurred during this request." );
                        label2.setText( "Error submitting request " + ( x + 1 ) );
                        errorRequests.addElement( (ItemInfo) requestRecord.elementAt( x ) );
                        requestRecord.removeElementAt( x );
                    } else {
                        errorFlag = true;
                        label1.setText( "Status or error report could not be evaluated." );
                        label2.setText( "Error submitting request " + ( x + 1 ) );
                        errorRequests.addElement( (ItemInfo) requestRecord.elementAt( x ) );
                        requestRecord.removeElementAt( x );
                    }
                case ( ILL_ANSWER_APDU ):
                        
                    switch ( apdu.answer.transaction_results ) {
                    case ( CONDITIONAL_TR ):
                        label1.setText( "" );
                        // TODO:  Find out what CONDITIONAL_TR means.
                        requestsSubmitted++;
                        break;
                    case ( RETRY_TR ):
                        label1.setText( "Request " + ( x + 1 ) + " must be resubmitted." );
                        // TODO:  This result should automatically resubmit.
                        requestsSubmitted++;
                        break;
                    case ( UNFILLED_TR ):
                        label1.setText( "Request " + ( x + 1 ) + " is unfilled." );
                        requestsSubmitted++;
                        break;
                    case ( LOCATIONS_PROVIDED_TR ):
                        label1.setText( "Locations were provided for request " + ( x + 1 ) );
                        requestsSubmitted++;
                        break;
                    case ( WILL_SUPPLY_TR ):
                        label1.setText( "A lender has been located that will supply the item." );
                        requestsSubmitted++;
                        break;
                    case ( HOLD_PLACED_TR ):
                        label1.setText( "Request " + ( x + 1 ) + " is on hold by the lender." );
                        requestsSubmitted++;
                        break;
                    case ( ESTIMATE_TR ):
                        label1.setText( "" );
                        // TODO:  Find out what ESTIMATE_TR means.
                        requestsSubmitted++;
                        break;
                    default:
                        errorFlag = true;
                        label1.setText( "The transaction results could not be determined." );
                        label2.setText( "Error submitting response " + ( x + 1 ) );
                        errorRequests.addElement( (ItemInfo) requestRecord.elementAt( x ) );
                        requestRecord.removeElementAt( x );
                    }
                    break;
                    
                default:
                    errorFlag = true;
                    label1.setText( "The response type could not be determined." );
                    label2.setText( "Error submitting response " + ( x + 1 ) );
                    errorRequests.addElement( (ItemInfo) requestRecord.elementAt( x ) );
                    requestRecord.removeElementAt( x );
                }
                progressBar.step( );
            }

            // close connections
            label1.setText( "Closing I/O data streams and socket connection." );
            input.close( );
            output.close( );
            connection.close( );
            progressBar.step( );
        }
        catch ( Exception anyException ) {
            exceptionFlag = true;
            String msgString = new String( "A fatal error occurred during the submission of this request:\n\n" );
            msgString += anyException.toString( );
            MessageBox.show( msgString, "ONU Interlibrary Loan",
                             MessageBox.ICONERROR | MessageBox.OK );
        }
        
        this.setVisible( false );
    }

    /**
     * NOTE: The following code is required by the Visual J++ form
     * designer.  It can be modified using the form editor.  Do not
     * modify it using the code editor.
     */
    Container components = new Container();
    Label label1 = new Label();
    Label label2 = new Label();
    ProgressBar progressBar = new ProgressBar();
    Label label3 = new Label();

    private void initForm()
    {
        this.setText("");
        this.setAutoScaleBaseSize(13);
        this.setBorderStyle(FormBorderStyle.FIXED_DIALOG);
        this.setClientSize(new Point(391, 99));
        this.setControlBox(false);
        this.setMaximizeBox(false);
        this.setMinimizeBox(false);
        this.setStartPosition(FormStartPosition.CENTER_SCREEN);

        label1.setLocation(new Point(8, 8));
        label1.setSize(new Point(376, 13));
        label1.setTabIndex(0);
        label1.setTabStop(false);
        label1.setText("");
        label1.setAutoSize(true);
        label1.setTextAlign(HorizontalAlignment.CENTER);

        label2.setFont(new Font("MS Sans Serif", 8.0f, FontSize.POINTS, FontWeight.BOLD, false, false, false));
        label2.setForeColor(Color.RED);
        label2.setLocation(new Point(8, 22));
        label2.setSize(new Point(376, 13));
        label2.setTabIndex(1);
        label2.setTabStop(false);
        label2.setText("");
        label2.setAutoSize(true);
        label2.setTextAlign(HorizontalAlignment.CENTER);

        progressBar.setLocation(new Point(8, 44));
        progressBar.setSize(new Point(376, 20));
        progressBar.setTabIndex(2);
        progressBar.setText("");

        label3.setFont(new Font("MS Sans Serif", 10.0f, FontSize.POINTS, FontWeight.BOLD, false, false, false, CharacterSet.DEFAULT, 0));
        label3.setLocation(new Point(8, 72));
        label3.setSize(new Point(376, 16));
        label3.setTabIndex(3);
        label3.setTabStop(false);
        label3.setText("ONU-ILL is automatically submitting your request");
        label3.setAutoSize(true);
        label3.setTextAlign(HorizontalAlignment.CENTER);

        this.setNewControls(new Control[] {
                            label3, 
                            progressBar, 
                            label2, 
                            label1});
    }
    
    public static void main( String args[] )
    {
        Application.run( new RequestSubmitForm( ) );
    }
}
