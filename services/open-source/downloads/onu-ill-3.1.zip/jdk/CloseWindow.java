/*  CloseWindow.java
**  
**  Bryan Wilhelm, Olivet Nazarene University
**  September 11, 1998
**  
**  Closes a window and returns to the application.
*/


import java.awt.event.*;

class CloseWindow extends WindowAdapter
{
    public void windowClosing( WindowEvent e )
    { e.getWindow( ).setVisible( false ); }
}

