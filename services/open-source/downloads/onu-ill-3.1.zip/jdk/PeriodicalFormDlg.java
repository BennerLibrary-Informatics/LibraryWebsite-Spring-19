/*  PeriodicalFormDlg.java
**
**  by Bryan Wilhelm, Olivet Nazarene University
**  September 11, 1998
**
**  The PeriodicalFormDlg is used to get information about a request for an
**  article or periodical item.  It stores its information in an element of
**  the ItemInfo Vector.  This information is latter retreived in the
**  RequestFinalizer class an put into an IsoIllRequest record to form an
**  ISO-Request.
*/


import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.*;
import java.util.*;

import sun.net.ftp.*;     // for the FtpClient to get the data file

public class PeriodicalFormDlg 
       extends Dialog 
       implements ActionListener, 
                  ONU_ILL_CONST
{
    /*
    ** Attributes
    */
    private Font bigFont = new Font( "Serif", Font.BOLD + Font.ITALIC, 24 );

    private Button        btn_ok, 
                          btn_cancel, 
                          btn_more,
                          btn_holdings;
    private InfoTextField tf_title,        // TITLE
                          tf_author,       // AUTHOR
                          tf_volume,       // VOLUME
                          tf_number,       // SERIAL_NO
                          tf_issn,         // PATRON_NOTES
                          tf_date,         // DATE
                          tf_pages,        // PAGES
                          tf_article;      // ARTICLE
    private TextField     tf_needBefore;   // NEEDBEFORE_DATE
    private CheckboxGroup grp_verified;    // VERIFIED
    private Checkbox      cb_yesVerified, 
                          cb_noVerified;

    public ItemInfo request;
    private int     numRequests;

    String str_bookApp = new String( DEFAULT_BOOK_APP ),
           str_bookParam = new String( DEFAULT_BOOK_PARAM ),
           str_perApp = new String( DEFAULT_PER_APP ),
           str_perParam = new String( DEFAULT_PER_PARAM );

    private Toolkit sys_metrics = Toolkit.getDefaultToolkit( );
    private Font    boldFont = new Font( "Sans Serif", Font.BOLD, 11 );


    /*=====================================================================*/
    /* MoreInfo                                                            */
    /*                                                                     */
    /* This is an inner-class of PeriodicalForm to get more information    */
    /* about the periodical being requested.                               */
    /*=====================================================================*/
    class MoreInfoDlg extends Dialog implements ActionListener
    {
        /* Attributes
        ** These properties are local to MoreInfoDlg and are not in the scope
        ** of PeriodicalFormDlg. However, the properties of PeriodicalFormDlg
        ** are in the scope of MoreInfoDlg.
        */
        private Button        btn_ok, 
                              btn_cancel;
        private InfoTextField tf_whereFound;    // +PATRON_NOTES
        private TextArea      ta_comments;      // +PATRON_NOTES

        /*
        ** Constructor
        */
        public MoreInfoDlg( Frame parent, int n )
        {
            /* Call dialog superclass constructor. */
            super( parent, "Item " + n + ":  Additional Information", true );

            /* set window size, layout, and listeners */
            setSize( 456, 456 );
            setResizable( false );
            setLayout( null );
            setFont( new Font( "Sans Serif", Font.PLAIN, 11 ) );
            addWindowListener( new CloseWindow( ) );

            /* Create dialog box components. */
            Label illTitle = new Label( "Interlibrary Loan" );
            Label perTitle = new Label( "Periodical Request Form" );
            Label commentLabel = new Label( "Enter any comments helpful to order" +
                " this item" );
            illTitle.setFont( bigFont );
            perTitle.setFont( bigFont );

            tf_whereFound = new InfoTextField( "Where did you find this citation", 32 );
            ta_comments = new TextArea( 32, 10 );

            btn_ok = new Button( "OK" );
            btn_ok.addActionListener( this );
            btn_cancel = new Button( "Cancel" );
            btn_cancel.addActionListener( this );

            /* Add components to the dialog box. */
            add( illTitle );
            add( perTitle );
            add( tf_whereFound );
            add( commentLabel );
            add( ta_comments );
            add( btn_ok );
            add( btn_cancel );

            /* Set the location and bounds of the dialog components. */
            illTitle.setBounds( 24, 24, 384, 27 );
            perTitle.setBounds( 24, 51, 384, 27 );

            tf_whereFound.setBounds( 36, 102,
                ( tf_whereFound.getSize( ) ).width,
                ( tf_whereFound.getSize( ) ).height );
            commentLabel.setBounds( 36, 150, 384, 14 );
            ta_comments.setBounds( 36, 166, 384, 218 );

            btn_ok.setBounds( 298, 416, 64, 24 );
            btn_cancel.setBounds( 374, 416, 64, 24 );

            /* Display dialog box. */
            int x = (int)( ( ( sys_metrics.getScreenSize( ) ).width - 456 ) / 2 );
            int y = (int)( ( ( sys_metrics.getScreenSize( ) ).height - 456 ) / 2 );
            setLocation( x, y );
            setVisible( true );

        }

        public void paint( Graphics g )
        {
            /* Draw 3D rectangle */
            g.draw3DRect( 18, 93, 420, 307, false );
        }

        public void actionPerformed( ActionEvent event )
        {
            /* if "OK" pressed, process fields */
            if ( event.getSource( ) == btn_ok ) {

                /* PATRON_NOTES
                ** If whereFound is empty then do not worry about the other
                ** two fields.
                */
                if ( !tf_whereFound.getText( ).equals( "" ) ) {
                    request.patron_notes = tf_whereFound.getText( );
                }

                /* Comments also go in PATRON_NOTES */
                if ( request.patron_notes.equals( "" ) ) {
                    request.patron_notes = ta_comments.getText( );
                } else if ( !ta_comments.getText( ).equals( "" ) ) {
                    request.patron_notes += "; " + ta_comments.getText( );
                }

            }

            /* else "Cancel" was pressed. */

            /* This is done when either button is pressed. */
            setVisible( false );
            dispose( );
        }

    }
    /* End of MoreInfo                                                     */
    /*=====================================================================*/


    /*
    ** Constructor
    */
    public PeriodicalFormDlg( Frame parent, ItemInfo r, int n )
    {
        /* Call dialog superclass constructor. */
        super( parent, "Item " + n + ":  Periodical Request Form", true );
        request = r;
        numRequests = n;

        /* Set window size, layout, and listener. */
        setSize( 456, 456 );
        setResizable( false );
        setLayout( null );
        setFont( new Font( "Sans Serif", Font.PLAIN, 11 ) );
        addWindowListener( new CloseWindow( ) );

        /* Create dialog box components */
        Label illTitle = new Label( "Interlibrary Loan" );
        Label perTitle = new Label( "Periodical Request Form" );
        Label itemInfo = new Label( "Item Information" );
        Label nbdTitle = new Label( "Date Needed By" );
        illTitle.setFont( bigFont );
        perTitle.setFont( bigFont );

        Label verifiedLabel = new Label( "Have you checked " + LIBRARY_NAME +
            " for this item?" );
        verifiedLabel.setFont( boldFont );
        grp_verified = new CheckboxGroup( );
        cb_yesVerified = new Checkbox( "Yes", grp_verified, false );
        cb_noVerified = new Checkbox( "No", grp_verified, true );

        Label nbdLabel = new Label( "Enter the date this item is needed by. " +
            "The default date is pre-entered." );
        nbdLabel.setFont( boldFont );
        DateFormat df = DateFormat.getDateInstance( DateFormat.LONG );
        tf_needBefore = new TextField( 10 );
        tf_needBefore.setText( df.format( DEFAULT_NEEDBEFORE_DATE ) );

        btn_more = new Button( "More" );
        btn_more.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        btn_more.addActionListener( this );
        btn_ok = new Button( "OK" );
        btn_ok.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        btn_ok.addActionListener( this );
        btn_cancel = new Button( "Cancel" );
        btn_cancel.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        btn_cancel.addActionListener( this );
        btn_holdings = new Button( LIBRARY_NAME + " Periodical Holdings" );
        btn_holdings.addActionListener( this );

        /* Add components to the dialog box. */
        add( illTitle );
        add( perTitle );
        add( itemInfo );
        add( tf_title = new InfoTextField( "Periodical Title", 32, boldFont ) );
        tf_title.setText( new String( request.title ) );
        add( tf_article = new InfoTextField( "Article Title", 32, boldFont ) );
        tf_article.setText( new String( request.title_of_article ) );
        add( tf_author = new InfoTextField( "Author (Last, First)", 15 ) );
        tf_author.setText( new String( request.author ) );
        add( tf_volume = new InfoTextField( "Volume", 7 ) );
        tf_volume.setText( new String( request.volume ) );
        add( tf_number = new InfoTextField( "Number", 7 ) );
        tf_number.setText( new String( request.issue ) );
        add( tf_issn = new InfoTextField( "ISSN", 15 ) );
        tf_issn.setText( new String( request.issn ) );
        add( tf_date = new InfoTextField( "Date", 7, boldFont ) );
        tf_date.setText( new String( request.publication_date ) );
        add( tf_pages = new InfoTextField( "Pages", 7, boldFont ) );
        tf_pages.setText( new String( request.pagination ) );
        add( verifiedLabel );
        add( cb_yesVerified );
        add( cb_noVerified );
        add( btn_holdings );
        add( nbdTitle );
        add( nbdLabel );
        add( tf_needBefore );
        add( btn_more );
        add( btn_ok );
        add( btn_cancel );

        /* Set the location and bounds of the dialog components. */
        illTitle.setBounds( 24, 24, 384, 27 );
        perTitle.setBounds( 24, 51, 384, 27 );

        itemInfo.setBounds( 24, 86, 75, 14 );
        tf_title.setBounds( 36, 102,
            ( tf_title.getSize( ) ).width,
            ( tf_title.getSize( ) ).height );
        tf_article.setBounds( 36, 146,
            ( tf_article.getSize( ) ).width,
            ( tf_article.getSize( ) ).height );
        tf_author.setBounds( 36, 190,
            ( tf_author.getSize( ) ).width,
            ( tf_author.getSize( ) ).height );
        tf_volume.setBounds( 240, 190,
            ( tf_volume.getSize( ) ).width,
            ( tf_volume.getSize( ) ).height );
        tf_number.setBounds( 336, 190,
            ( tf_number.getSize( ) ).width,
            ( tf_number.getSize( ) ).height );
        tf_issn.setBounds( 36, 234,
            ( tf_issn.getSize( ) ).width,
            ( tf_issn.getSize( ) ).height );
        tf_date.setBounds( 240, 234,
            ( tf_date.getSize( ) ).width,
            ( tf_date.getSize( ) ).height );
        tf_pages.setBounds( 336, 234,
            ( tf_pages.getSize( ) ).width,
            ( tf_pages.getSize( ) ).height );
        verifiedLabel.setBounds( 36, 278, 384, 14 );
        cb_yesVerified.setBounds( 36, 294, 50, 20 );
        cb_noVerified.setBounds( 86, 294, 50, 20 );
        btn_holdings.setBounds( 136, 294, 284, 20 );

        nbdTitle.setBounds( 24, 333, 79, 16 );
        nbdLabel.setBounds( 36, 351, 384, 16 );
        tf_needBefore.setBounds( 36, 369, 144, 20 );

        btn_more.setBounds( 18, 416, 64, 24 );
        btn_ok.setBounds( 298, 416, 64, 24 );
        btn_cancel.setBounds( 374, 416, 64, 24 );

        /* Display dialog box. */
        int x = (int)( ( ( sys_metrics.getScreenSize( ) ).width - 456 ) / 2 );
        int y = (int)( ( ( sys_metrics.getScreenSize( ) ).height - 456 ) / 2 );
        setLocation( x, y );
        setVisible( true );

    }

    public void paint( Graphics g )
    {
        /* Draw 3D rectangle */
        g.draw3DRect( 18, 93, 420, 228, false );
        g.draw3DRect( 18, 340, 420, 60, false );
    }

    public void actionPerformed( ActionEvent event )
    {
        if ( event.getSource( ) == btn_ok ) {

            /* If there is data missing warn the user */
            if ( tf_title.getText( ).equals( "" ) ||
                tf_article.getText( ).equals( "" ) ||
                tf_date.getText( ).equals( "" ) ||
                tf_pages.getText( ).equals( "" ) ||
                tf_needBefore.getText( ).equals( "" ) ||
                grp_verified.getSelectedCheckbox( ).getLabel( ).equals( "No" ) )
            {
                new ErrorMsgDlg( new Frame( ), "A required field is missing." );

            /* else get the information from the user. */
            } else {
                DateFormat df = DateFormat.getDateInstance( DateFormat.LONG );

                /* Get the date entered by the user */
                try {
                    request.need_before_date = new String( 
                        ILLDate.getFormattedDate( df.parse( tf_needBefore.getText( ) ) ) );

                /* If the user's date is not in the correct format,
                ** then provide them with the default date.
                */
                } catch ( ParseException parse ) {
                    request.need_before_date = 
                        new String( DEFAULT_NEEDBEFORE_STRING );
                    /* TODO: provide a dialog for the user to correct
                    **       a miss entered date.
                    */
                }

                request.author = new String( tf_author.getText( ) );
                request.title = new String( tf_title.getText( ) );
                request.title_of_article = new String( tf_article.getText( ) );
                request.volume = new String( tf_volume.getText( ) );
                request.issue = new String( tf_number.getText( ) );
                request.publication_date = new String( tf_date.getText( ) );
                request.pagination = new String( tf_pages.getText( ) );
                request.issn = new String( tf_issn.getText( ) );
                request.ill_service_type = PERIODICAL_REQUEST;
                request.request_made = true;

                setVisible( false );
                dispose( );
            }
        }

        else if ( event.getSource( ) == btn_more ) {
            new MoreInfoDlg( new Frame( ), numRequests );
        }

        else if ( event.getSource( ) == btn_cancel ) {
            request.request_made = false;
            setVisible( false );
            dispose( );
        }

        else if ( event.getSource( ) == btn_holdings ) {
            try {
                readData( );
                String args[] = { str_perApp, str_perParam };
                ( Runtime.getRuntime( ) ).exec( args );
            }
            catch ( Exception all ) {
                new ErrorMsgDlg( new Frame( ), "Could not access holdings" );
            }
        }

    }

    /*=====================================================================*/
    /* Methods                                                             */
    /*=====================================================================*/

    public void readData( )
    {
        try {
            /* establish connection to server */
            FtpClient client = new FtpClient( ADMIN_HOST );

            /* log into server */
            client.login( ADMIN_USER_ID, ADMIN_PASSWORD );

            /* change to appropriate directory */
            client.cd( ADMIN_PATH );

            /* get the file */
            client.get( ADMIN_FILE );

            /* close server connection */
            client.sendServer( "quit" );

            /* get information from the file */
            File file = new File( ADMIN_FILE );
            DataInputStream input = new DataInputStream(
                new FileInputStream( file ) );
            str_bookApp = input.readUTF( );
            str_bookParam = input.readUTF( );
            str_perApp = input.readUTF( );
            str_perParam = input.readUTF( );
            input.close( );
            file.delete( );
        }

        catch ( IOException rd ) {
            /* Do nothing.  If the file cannot be read then the default 
            ** parameters are used.
            */
        }
    }
}



