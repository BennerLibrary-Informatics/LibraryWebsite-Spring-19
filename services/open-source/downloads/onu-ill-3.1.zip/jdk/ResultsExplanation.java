/*  ResultsExplanation.java
**
**  by Bryan Wilhelm, Olivet Nazarene University
**  September 11, 1998
**
**  Holds the number representing the explanation for action
**  taken on a request.
*/

public class ResultsExplanation
{
    public short unfilled;
}
