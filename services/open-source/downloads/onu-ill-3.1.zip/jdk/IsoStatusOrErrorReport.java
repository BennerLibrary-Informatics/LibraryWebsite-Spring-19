/*  IsoStatusOrErrorReport.java
**
**  by Bryan Wilhelm, Olivet Nazarene University
**  September 11, 1998
**
**  Contains the data from a possible response from OCLC.
*/


import java.util.*;

public class IsoStatusOrErrorReport implements ILL_ASN, ILL_API
{
    public String
        transaction_qualifier,
        transaction_group_qualifier,
        requester_id,
        note;

    public Vector errors = new Vector();          // array to error text strings

    public short
        current_state = 0,     // only set if no error occurred
        error_occurred = 0;    // flag which indicates if an error occurred

    public IsoStatusOrErrorReport( DataDir dir )
    {
        DataDir datadir;
        DataDir extdir;

           /*
           ** get institution symbol 
           */

        datadir = finddir( finddir( finddir( finddir( finddir( finddir( dir,
    	                                                                ASN1_SEQUENCE,
						                                                ASN1_UNIVERSAL, 
                                                                        0 ),
					                                           TRANSACTION_ID, 
                                                               ASN1_CONTEXT, 
                                                               0 ),
                                                      INITIAL_REQUESTER_ID, 
                                                      ASN1_CONTEXT, 
                                                      0 ),
			                                 PERSON_OR_INSTITUTION_SYMBOL, 
                                             ASN1_CONTEXT, 
                                             0 ),
		                            INSTITUTION_SYMBOL, 
                                    ASN1_CONTEXT, 
                                    0 ),
                           ASN1_GENERALSTRING, 
                           ASN1_UNIVERSAL, 
                           0 );

        if ( datadir != null )
	        requester_id = datadir.dgetChar();

           /*
           ** get transaction qualifier 
           */


        datadir = finddir( finddir( finddir( finddir( dir,
                                                      ASN1_SEQUENCE, 
                                                      ASN1_UNIVERSAL, 
                                                      0 ),
                                             TRANSACTION_ID, 
                                             ASN1_CONTEXT, 
                                             0 ),
                                    TRANSACTION_QUALIFIER, 
                                    ASN1_CONTEXT, 
                                    0 ),
                           ASN1_GENERALSTRING, 
                           ASN1_UNIVERSAL, 
                           0 );

        if ( datadir != null )
            transaction_qualifier = datadir.dgetChar();

           /*
           ** get transaction group qualifier
           */

        datadir = finddir( finddir( finddir( finddir( dir,
                                                      ASN1_SEQUENCE, 
                                                      ASN1_UNIVERSAL, 
                                                      0 ),
                                             TRANSACTION_ID, 
                                             ASN1_CONTEXT, 
                                             0 ),
                                    TRANSACTION_GROUP_QUALIFIER, 
                                    ASN1_CONTEXT, 
                                    0 ),
		                   ASN1_GENERALSTRING, 
                           ASN1_UNIVERSAL, 
                           0 );
        if ( datadir != null )
            transaction_group_qualifier = datadir.dgetChar();

           /*
           ** get note
           */

        datadir = finddir( finddir( finddir( dir,
				                             ASN1_SEQUENCE, 
                                             ASN1_UNIVERSAL, 
                                             0 ),
			                        REQUESTER_NOTE, 
                                    ASN1_CONTEXT, 
                                    0 ),
		                   ASN1_GENERALSTRING, 
                           ASN1_UNIVERSAL, 
                           0 );

        if (datadir != null )
            note = datadir.dgetChar();


           /*
           ** if status report, get current state 
           */


        datadir = finddir( finddir( finddir( dir,
 			                                 ASN1_SEQUENCE, 
                                             ASN1_UNIVERSAL, 
                                             0 ),
		                            STATUS_REPORT, 
                                    ASN1_CONTEXT, 
                                    0 ),
                           PROVIDER_STATUS_REPORT, 
                           ASN1_CONTEXT, 
                           0 );

        if ( datadir != null )
            current_state = (short) datadir.dgetNum();
    
           /*
           ** get error report if present 
           */

        datadir = finddir( finddir( dir,
                                    ASN1_SEQUENCE, 
                                    ASN1_UNIVERSAL, 
                                    0 ),
                           ERROR_REPORT, 
                           ASN1_CONTEXT, 
                           0 );

        if ( datadir != null )
	        error_occurred = 1;
        else
	        error_occurred = 0;


           /*
           ** get extensions 
           */

        extdir = finddir( finddir( finddir( finddir( finddir( dir, 
                                                              SEQUENCE, 
                                                              ASN1_UNIVERSAL, 
                                                              0 ),
                                                     EXTENSIONS, 
                                                     ASN1_CONTEXT, 
                                                     0 ),
                                            SEQUENCE, 
                                            ASN1_UNIVERSAL, 
                                            0 ),
                                   EXTENSION_ITEM, 
                                   ASN1_CONTEXT, 
                                   0 ),
                          ASN1_EXTERNAL, 
                          ASN1_UNIVERSAL, 
                          0 );

        if ( extdir != null )
        {
            DataDir sindir;
            DataDir errdir;
	        long i;

            datadir = finddir(extdir, ASN1_OBJECTIDENTIFIER, ASN1_UNIVERSAL, 0);
            sindir = finddir(extdir, SINGLE_ASN1_TYPE, ASN1_CONTEXT, 0);

            if ( datadir != null && 
                 sindir != null && 
                 OID_OCLC_ILL_ERROR_LIST.equals( datadir.dgetoid() ) )
            {
                for ( i = 0;
                      ( datadir = finddir( finddir( finddir( sindir, 
                                                             ASN1_SEQUENCE,
		                                                     ASN1_UNIVERSAL, 
                                                             0 ),
      		                                        ASN1_SEQUENCE, 
                                                    ASN1_UNIVERSAL, 
                                                    i ),
		                                   OCLC_ILL_ERROR_TEXT, 
                                           ASN1_CONTEXT, 
                                           0 ) 
                      ) != null;
		              ++i 
                    )
	            {
                    errdir = finddir( datadir, ASN1_GENERALSTRING, ASN1_UNIVERSAL, 0 );
                    if ( errdir != null )
                        errors.addElement( errdir.dgetChar() );
	            }
            }
        }
    }



    private DataDir finddir( DataDir dir, 
                             short fldid,
                             byte asn1class,
                             long occurence )
    {
        DataDir subdir;

        if ( dir == null )
	        return null;
        for ( subdir = dir.child(); subdir != null; subdir = subdir.next() ) {
	        if ( subdir.fldid() == fldid &&
                 subdir.asn1class() == asn1class &&
                 occurence-- <= 0 )
            {
                 return subdir;
            }
        }

        return null;

    }

}


// (c)1998 Olivet Nazarene University, 240 East Marsile,
// Bourbonnais, IL 60914-0592.
//
// NOTICE TO USERS:  ONU-ILL ("Software") has been developed by
// Olivet Nazarene University.  Subject to the terms and conditions set
// forth below, Olivet grants to user a perpetual, non-exclusive, royalty-free
// license to use, reproduce, alter, modify, and create derivative works from
// Software, and to sublicense Software subject to the following terms and
// conditions:
//
// SOFTWARE IS PROVIDED AS IS.  OLIVET MAKES NO WARRANTIES, REPRESENTATIONS, OR
// GUARANTEES WHETHER EXPRESS OR IMPLIED REGARDING SOFTWARE, ITS FITNESS FOR ANY
// PARTICULAR PURPOSE, OR THE ACCURACY OF THE INFORMATION CONTAINED THEREIN.
//
// User agrees that Olivet shall have no liability to user arising therefrom,
// regardless of the basis of the action, including liability for special,
// consequential, exemplary, or incidental damages, including lost profits,
// even if it has been advised of the possibility thereof.
//
// User shall cause the copyright notice of Olivet to appear on all copies of
// Software, including derivative works made therefrom.


// (c)1996 OCLC Online Computer Library Center, Inc., 6565 Frantz Road, Dublin,
// Ohio 43017-0702.  OCLC is a registered trademark of OCLC Online Computer
// Library Center, Inc.
//
// NOTICE TO USERS:  The BER Utilities ("Software") has been developed by OCLC
// Online Computer Library Center, Inc.  Subject to the terms and conditions set
// forth below, OCLC grants to user a perpetual, non-exclusive, royalty-free
// license to use, reproduce, alter, modify, and create derivative works from
// Software, and to sublicense Software subject to the following terms and
// conditions:
//
// SOFTWARE IS PROVIDED AS IS.  OCLC MAKES NO WARRANTIES, REPRESENTATIONS, OR
// GUARANTEES WHETHER EXPRESS OR IMPLIED REGARDING SOFTWARE, ITS FITNESS FOR ANY
// PARTICULAR PURPOSE, OR THE ACCURACY OF THE INFORMATION CONTAINED THEREIN.
//
// User agrees that OCLC shall have no liability to user arising therefrom,
// regardless of the basis of the action, including liability for special,
// consequential, exemplary, or incidental damages, including lost profits,
// even if it has been advised of the possibility thereof.
//
// User shall cause the copyright notice of OCLC to appear on all copies of
// Software, including derivative works made therefrom.