/*
**  ILLAdmin.java
**
**  Bryan Wilhelm, Olivet Nazarene University
**  September 11, 1998
**
**  This is the ILL Administration Module.  It was necessary so that
**  changes in the ILL system or ILL policy would not require massive
**  revisions to the Java source code, recompilation and redistribution.
**  Storing the data would be ideal on a network drive (G:) but dial-in
**  users would not have access to it.  Therefore TIGER was chosen a the
**  server location.
**
**  Currently only a few options are available:
**      - location of the book and periodical holdings;
**      - OCLC ILL service type.
**
**  Other options may also be desired in the future, including:
**      - rush request option;
**      - default need before date (currently constant at 25 days);
**      - required fields (this would be slick!);
**      - possibly access control.
*/

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import sun.net.ftp.*;

public class ILLAdmin 
       extends Dialog 
       implements ActionListener, 
                  ItemListener,
                  ONU_ILL_CONST
{
    /*
    ** Attributes
    */
    InfoTextField tf_bookApp,
                  tf_bookParam,
                  tf_perApp,
                  tf_perParam,
                  tf_lenderList;
    CheckboxGroup grp_service;
    Checkbox      cb_lender,
                  cb_profile,
                  cb_review;
    Button        btn_ok,
                  btn_cancel;

    String str_bookApp = new String( DEFAULT_BOOK_APP ),
           str_bookParam = new String( DEFAULT_BOOK_PARAM ),
           str_perApp = new String( DEFAULT_PER_APP ),
           str_perParam = new String( DEFAULT_PER_PARAM ),
           str_lenderList = new String( );
    short  service_code = 3;

    Toolkit sys_metrics = Toolkit.getDefaultToolkit( );
    Font boldFont = new Font( "Sans Serif", Font.BOLD, 11 );


    /*
    ** Constructor
    */
    public ILLAdmin( )
    {
        /* call to superclass constructor */
        super( new Frame( ), "ILL Administration Module", true );

        /* retrieve current values */
        readData( );

        /* set characteristics */
        setSize( 456, 292 );
        setResizable( false );
        setLayout( null );
        setFont( new Font( "Sans Serif", Font.PLAIN, 11 ) );
        addWindowListener( new CloseApplication( ) );

        /* create components */
        Label bookLabel = new Label( "Enter the application and parameters for the book holdings" );
        bookLabel.setFont( boldFont );
        Label perLabel = new Label( "Enter the application and parameters for the periodical holdings" );
        perLabel.setFont( boldFont );
        tf_bookApp = new InfoTextField( "Application", 10 );
        tf_bookApp.setText( str_bookApp );
        tf_bookParam = new InfoTextField( "Parameters", 23 );
        tf_bookParam.setText( str_bookParam );
        tf_perApp = new InfoTextField( "Application", 10 );
        tf_perApp.setText( str_perApp );
        tf_perParam = new InfoTextField( "Parameters", 23 );
        tf_perParam.setText( str_perParam );

        Label serviceLabel = new Label( "Select a Direct Request service type" );
        serviceLabel.setFont( boldFont );
        grp_service = new CheckboxGroup( );
        cb_lender = new Checkbox( "Lender", grp_service, ( service_code == 1 ) );
        cb_lender.addItemListener( this );
        cb_profile = new Checkbox( "Profile", grp_service, ( service_code == 2 ) );
        cb_review = new Checkbox( "Review File", grp_service, ( service_code == 3 ) );
        tf_lenderList = new InfoTextField( "Lender List", 30 );
        tf_lenderList.setEnabled( false );

        btn_ok = new Button( "OK" );
        btn_ok.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        btn_ok.addActionListener( this );
        btn_cancel = new Button( "Cancel" );
        btn_cancel.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        btn_cancel.addActionListener( this );

        /* add the components */
        add( bookLabel );
        add( tf_bookApp );
        add( tf_bookParam );
        add( perLabel );
        add( tf_perApp );
        add( tf_perParam );

        add( serviceLabel );
        add( cb_lender );
        add( cb_profile );
        add( cb_review );
        add( tf_lenderList );

        add( btn_ok );
        add( btn_cancel );

        /* set the components */
        bookLabel.setBounds( 24, 32, 408, 12 );
        tf_bookApp.setBounds( 24, 44,
            tf_bookApp.getSize( ).width,
            tf_bookApp.getSize( ).height );
        tf_bookParam.setBounds( 156, 44,
            tf_bookParam.getSize( ).width,
            tf_bookParam.getSize( ).height );
        perLabel.setBounds( 24, 92, 408, 12 );
        tf_perApp.setBounds( 24, 104,
            tf_perApp.getSize( ).width,
            tf_perApp.getSize( ).height );
        tf_perParam.setBounds( 156, 104,
            tf_perParam.getSize( ).width,
            tf_perParam.getSize( ).height );

        serviceLabel.setBounds( 24, 160, 408, 12 );
        cb_lender.setBounds( 24, 172, 136, 20 );
        cb_profile.setBounds( 160, 172, 136, 20 );
        cb_review.setBounds( 296, 172, 136, 20 );
        tf_lenderList.setBounds( 24, 196, 408, tf_lenderList.getSize( ).height );

        btn_ok.setBounds( 300, 252, 64, 24 );
        btn_cancel.setBounds( 368, 252, 64, 24 );

        /* set the dialog location and display */
        int x = (int)( ( sys_metrics.getScreenSize( ).width - 456 ) / 2 );
        int y = (int)( ( sys_metrics.getScreenSize( ).height - 292 ) / 2 );
        setLocation( x, y );
        setVisible( true );
    }

    /*
    ** ENTRY POINT
    */
    public static void main( String args[] ) 
    {
        ILLAdmin mainApp = new ILLAdmin( );
        mainApp.addWindowListener( new CloseApplication( ) );
    }


    /*
    ** Methods
    */
    public void actionPerformed( ActionEvent event )
    {
        if ( event.getSource( ) == btn_ok ) {
            if ( tf_bookApp.getText( ).equals( "" ) ||
                 tf_bookParam.getText( ).equals( "" ) ||
                 tf_perApp.getText( ).equals( "" ) ||
                 tf_perParam.getText( ).equals( "" ) )
            {
                new ErrorMsgDlg( new Frame( ), "A field was left empty." );

            } else {

                writeData( );

            }
        }

        /* else cancel was pressed -- do nothing */

        /* the following sequence is always done */
        setVisible( false );
        dispose( );
        System.exit( 0 );
    }

    public void itemStateChanged( ItemEvent item )
    {
        if ( grp_service.getSelectedCheckbox( ).getState( ) ) {
            tf_lenderList.setEnabled( true );
        } else {
            tf_lenderList.setText( "" );
            tf_lenderList.setEnabled( false );
        }

    }

    public void writeData( )
    {
        try {
            File file = new File( ADMIN_FILE );
            DataOutputStream output = new DataOutputStream(
                new FileOutputStream( file ) );
            output.writeUTF( tf_bookApp.getText( ) );
            output.writeUTF( tf_bookParam.getText( ) );
            output.writeUTF( tf_perApp.getText( ) );
            output.writeUTF( tf_perParam.getText( ) );
            output.writeShort( grp_service.getSelectedCheckbox( ).getLabel( ).equals( "Lender" ) ? 1 :
                               grp_service.getSelectedCheckbox( ).getLabel( ).equals( "Profile" ) ? 2 :
                               3 );
            output.writeUTF( tf_lenderList.getText( ) );
            output.close( );

            /* establish connection to server */
            FtpClient client = new FtpClient( ADMIN_HOST );

            /* log into server */
            client.login( ADMIN_USER_ID, ADMIN_PASSWORD );

            /* change to appropriate directory */
            client.cd( ADMIN_PATH );

            /* set binary mode transfer */
            client.binary( );

            /* put the file on the server */
            client.put( ADMIN_FILE );

            /* disconnect from server */
            client.sendServer( "quit" );

            file.delete( );
        }

        catch ( IOException wd ) {
            /*
            ** TODO: some warning should be given here.
            */
        }

    }

    public void readData( )
    {
        try {
            /* establish connection to server */
            FtpClient client = new FtpClient( ADMIN_HOST );

            /* log into server */
            client.login( ADMIN_USER_ID, ADMIN_PASSWORD );

            /* change to appropriate directory */
            client.cd( ADMIN_PATH );

            /* get the data file */
            client.get( ADMIN_FILE );

            /* disconnection from server */
            client.sendServer( "quit" );

            /* get the data from the file */
            File file = new File( ADMIN_FILE );
            DataInputStream input = new DataInputStream(
                new FileInputStream( file ) );
            str_bookApp = input.readUTF( );
            str_bookParam = input.readUTF( );
            str_perApp = input.readUTF( );
            str_perParam = input.readUTF( );
            service_code = input.readShort( );
            str_lenderList = input.readUTF( );
            input.close( );
            file.delete( );
        }

        catch ( IOException rd ) {
            /*
             * Do nothing.  If the file cannot be read then the default 
             * parameters are used.
             */
        }
    }
}