/* ILL_API.java
**
** Bryan Wilhelm, Olivet Nazarene University
** September 11, 1998
**
** Provides data for ILL Direct Request application using
** the ISO 10161 ILL standard
*/

public interface ILL_API
{
    public static final String
        EMAIL_ID_STRING = "email",
        FAX_ID_STRING   = "fax";

    /* Object Identifiers (OIDs) */
    public static final String
        OID_NLC_SYSTEM_NUMBER         = "1.2.124.10161.2",
        OID_Z3950_ACCESS_CONTROL      = "1.2.840.10003.8.1",
        OID_ILL_REQUEST_EXTENSION     = "1.0.10161.13.2",
        OID_CLIENT_INFO_EXTENSION     = "1.0.10161.13.1000.2.1",  /* local for now */
        OID_OCLC_SPECIFIC_ILL_SERVICE = "1.0.10161.4.1000.2.1",
        OID_OCLC_SPECIFIC_RESULTS     = "1.0.10161.8.1000.2.1",
        OID_OCLC_ILL_ERROR_LIST       = "1.0.10161.13.1000.2.2";

    /* ISO 10161 Extensions */

    public static final short EXT_OID = 1;

    /* ASN.1 universal tags */

    public static final short
        OID           = 6,
        EXTERNAL      = 8,
        ENUMERATED    = 10,
        SEQUENCE      = 16,
        GENERALSTRING = 27;

    public static final short
        CHOICE_0 = 0,
        CHOICE_1 = 1,
        CHOICE_2 = 2,
        CHOICE_3 = 3,
        CHOICE_4 = 4;

    public static final short
        SINGLE_ASN1_TYPE = 0;

    public static final short
        STANDARD       = 1,
        INFO_CONTENT   = 3,
        STRING_CONTENT = 1;

    /* defines for z39.50 access control ( used for id and password ) */

    public static final short
        ACCESS_CONTROL_RESPONSE = 2,
        PROMPT_ID               = 1,
        PROMPT_RESPONSE         = 2,
        STRING                  = 1,         
        RESPONSE                = 2,
        ENUMMERATED_PROMPT      = 1,
        ACCESS_TYPE             = 1;

    /* defines for extension 0 ( ill-request extensions for PRISM ILL data ) */

    public static final short
        CLIENT_DEPARTMENT        = 0,
        COST_INFO_PAYMENT_METHOD = 1,
        ITEM_ID_UNIFORM_TITLE    = 2,
        ITEM_ID_DISSERTATION     = 3,         
        ITEM_ID_ISSUE            = 4,
        ITEM_ID_VOLUME           = 5,
        ITEM_ID_AFFILIATIONS     = 6,
        ITEM_ID_SOURCE           = 7;


    /* defines for patron extension */

    public static final short
        PATRON_ID             = 0,
        PATRON_FULL_NAME      = 30,
        PATRON_FIRST_NAME     = 32,
        PATRON_LAST_NAME      = 31,
        PATRON_INITIALS       = 33,
        PATRON_TITLE          = 34,
        PATRON_SUFFIX         = 35,
        PATRON_SSN            = 22,
        CLIENT_POSTAL_ADDRESS = 2,
        PATRON_HOME_ADDRESS   = 5,
        PATRON_WORK_ADDRESS   = 6,
        PATRON_PHONE          = 8,
        PATRON_EMAIL          = 10,
        PATRON_FAX            = 7,
        PATRON_PAGER          = 9,
        PATRON_STATUS         = 3,
        PATRON_DEPARTMENT     = 100,  /* ?? */
        PATRON_NOTES          = 101, /* ?? */
        PATRON_MAXCOST        = 102,  /* ?? */
        PATRON_MAXCOST_AMOUNT = 7;

    /* defines for system number external */

    public static final short OCLC_TYPE = 3;

    /* define for OCLC ILL Service Type */

    public static final short
        DIRECT_TO_PROFILE_SERVICE = 1,
        DIRECT_TO_LENDER_SERVICE  = 2,
        DIRECT_TO_REVIEW_SERVICE  = 3;

    /* APDU defines */

    public static final short
        ILL_REQUEST_APDU            = 1,
        FORWARD_NOTIFICATION_APDU   = 2,
        SHIPPED_APDU                = 3,
        ILL_ANSWER_APDU             = 4,
        CONDITIONAL_REPLY_APDU      = 5,   
        CANCEL_APDU                 = 6,
        CANCEL_REPLY_APDU           = 7,
        RECEIVED_APDU               = 8,  
        RECALL_APDU                 = 9,
        RETURNED_APDU               = 10,
        CHECKED_IN_APDU             = 11,
        OVERDUE_APDU                = 12,
        RENEW_APDU                  = 13,
        RENEW_ANSWER_APDU           = 14,
        LOST_APDU                   = 15,
        DAMAGED_APDU                = 16,
        MESSAGE_APDU                = 17,
        STATUS_QUERY_APDU           = 18,
        STATUS_OR_ERROR_REPORT_APDU = 19;

    /* first level defines */

    public static final short
        PROTOCOL_VERSION_NUM            =   0,
        TRANSACTION_ID                  =   1,
        SERVICE_DATE_TIME               =   2,
        REQUESTER_ID                    =   3,
        RESPONDER_ID                    =   4,
        TRANSACTION_TYPE                =   5,   
        DELIVERY_ADDRESS                =   6,
        DELIVERY_SERVICE                =   7,        /* SHIP_VIA           */
        BILLING_ADDRESS                 =   8,  
        ILL_SERVICE_TYPE                =   9,
        RESPONDER_SPECIFIC_SERVICE      =  10,
        REQUESTER_OPTIONAL_MESSAGES     =  11,
        SEARCH_TYPE                     =  12,
        SUPPLY_MEDIUM_INFO_TYPE         =  13,
        PLACE_ON_HOLD                   =  14,
        CLIENT_ID                       =  15,
        ITEM_ID                         =  16,
        SUPPLELEMENTAL_ITEM_DESCRIPTION =  17,
        COST_INFO_TYPE                  =  18,
        COPYRIGHT_COMPLIANCE            =  19,         /* COPYRT_COMPLIANCE  */
        THIRD_PARTY_INFO_TYPE           =  20,
        RETRY_FLAG                      =  21,
        FORWARD_FLAG                    =  22,
        RESPONDER_ADDRESS               =  24,
        INTERMEDIARY_ID                 =  25,
        SUPPLIER_ID                     =  26,
        SHIPPED_SERVICE_TYPE            =  27,
        RESPONDER_OPTIONAL_MESSAGES     =  28,
        SUPPLY_DETAILS                  =  29,
        RETURN_TO_ADDRESS               =  30,
        TRANSACTION_RESULTS             =  31,
        RESULTS_EXPLANATION             =  32,
        RESPONDER_SPECIFIC_RESULTS      =  33,
        ANSWER                          =  35,
        DATE_RECEIVED                   =  36,
        DATE_RETURNED                   =  37,
        RETURNED_VIA_ISO                =  38,
        INSURED_FOR                     =  39,
        DATE_CHECKED_IN                 =  40,
        DUE_DATE_ISO                    =  41,
        DESIRED_DUE_DATE                =  42,
        REASON_NO_REPORT                =  43,
        STATUS_REPORT                   =  44,
        ERROR_REPORT                    =  45,
        REQUESTER_NOTE                  =  46,         /* BORROWING_NOTES    */
        FORWARD_NOTE                    =  47,         /* REFERRAL_NOTES     */
        NOTIFICATION_NOTE               =  48,
        EXTENSIONS                      =  49,
        ELECTRONIC_DELIVERY_SERVICE     =  50;          /* SHIP_VIA           */

    /* Lower level Field IDs */


   /*
   ** elements under THIRD_PARTY_INFO
   */

    public static final short
        PERMISSION_TO_FORWARD             =  0,
        PERMISSION_TO_CHAIN               =  1,
        PERMISSION_TO_PARTITION           =  2,
        PERMISSION_TO_CHANGE_SEND_TO_LIST =  3,
        INITIAL_REQUESTER_ADDRESS         =  4,
        PREFERENCE                        =  5,
        SEND_TO_LIST                      =  6,
        ALREADY_TRIED_LIST                =  7;


   /*
   ** elements under COST_INFO_TYPE
   */

    public static final short
        ACCOUNT_NUMBER       = 0,          /* BILLING_NOTES      */
        MAXIMUM_COST         = 1, 
        RECIPROCAL_AGREEMENT = 2,
        WILL_PAY_FEE         = 3,
        PAYMENT_PROVIDED     = 4;


   /* 
   ** elements under CLIENT_ID 
   */

    public static final short
        CLIENT_NAME       = 0,          /* PATRON             */
        CLIENT_STATUS     = 1,          /* PATRON             */
        CLIENT_IDENTIFIER = 2;          /* PATRON             */


   /* 
   ** elements under ITEM_ID 
   */

    public static final short
        II_ITEM_TYPE                     =  0,
        II_HELD_MEDIUM_TYPE              =  1,
        II_CALL_NUMBER                   =  2,          /* BORROWING_NOTES    */
        II_AUTHOR                        =  3,          /* AUTHOR             */
        II_TITLE                         =  4,          /* TITLE              */
        II_SUB_TITLE                     =  5,          /* U_TITLE            */
        II_SPONSORING_BODY               =  6,
        II_PLACE_OF_PUBLICATION          =  7,          /* IMPRINT            */
        II_PUBLISHER                     =  8,          /* IMPRINT            */
        II_SERIES_TITLE_NUMBER           =  9,          /* SERIES             */
        II_VOLUME_ISSUE                  = 10,          /* VOL( and NO )      */
        II_EDITION                       = 11,          /* EDITION            */
        II_PUBLICATION_DATE              = 12,          /* IMPRINT            */
        II_PUBLICATION_DATE_OF_COMPONENT = 13,          /* DATE               */
        II_AUTHOR_OF_ARTICLE             = 14,          /* ARTICLE            */
        II_TITLE_OF_ARTICLE              = 15,          /* ARTICLE            */
        II_PAGINATION                    = 16,          /* PAGES              */
        II_NATIONAL_BIBLIOGRAPHY_NUMBER  = 17, 
        II_ISBN                          = 18,          /* VERIFIED           */
        II_ISSN                          = 19,          /* VERIFIED           */
        II_SYSTEM_NO                     = 20,                               
        II_ADDITIONAL_NO_LETTERS         = 21,          /* VERIFIED           */
        II_VERIFICATION_REFERENCE_SOURCE = 22;          /* VERIFIED           */


   /*
   ** elements under RESPONDER_SPECIFIC_SERVICE
   */

    public static final short OCLC_ILL_SERVICE_TYPE = 0;


   /* 
   ** elements under REQUESTER_OPTIONAL_MESSAGES
   */

    public static final short
        CAN_SEND_RECEIVED    = 0,
        CAN_SEND_RETURNED    = 1,
        REQUESTER_SHIPPED    = 2,
        REQUESTER_CHECKED_IN = 3;


   /*
   ** elements under SEARCH_TYPE
   */

    public static final short
        LEVEL_OF_SERVICE = 0,
        NEED_BEFORE_DATE = 1,          /* NEEDBEFORE_DATE    */
        EXPIRY_FLAG      = 2,
        EXPIRY_DATE      = 3;


   /* 
   ** elements under STATUS_REPORT
   */

    public static final short
        USER_STATUS_REPORT     = 0,
        PROVIDER_STATUS_REPORT = 1;


   /* 
   ** elements under ELECTRONIC ADDRESS
   */


    public static final short
        TELECOM_SERVICE_IDENTIFIER = 0,
        TELECOM_SERVICE_ADDRESS    = 1;

   /* 
   ** elements under USER_STATUS_REPORT
   */

    public static final short
        MOST_RECENT_SERVICE              =  6,
        DATE_OF_MOST_RECENT_SERVICE      =  7,
        INITIATOR_OF_MOST_RECENT_SERVICE =  8,
        MOST_RECENT_SERVICE_NOTE         =  9;


   /* 
   ** elements under ERROR_REPORT
   */

    public static final short
        CORRELATION_INFORMATION = 0,
        REPORT_SOURCE           = 1,
        USER_ERROR_REPORT       = 2,
        PROVIDER_ERROR_REPORT   = 3;


   /* 
   ** elements under USER_ERROR_REPORT
   */

    public static final short
        ALREADY_FORWARDED    = 0,
        INTERMEDIARY_PROBLEM = 1,
        SECURITY_PROBLEM     = 2,
        UNABLE_TO_PERFORM    = 3;


   /* 
   ** elements under PROVIDER_ERROR_REPORT
   */

    public static final short
        GENERAL_PROBLEM              = 0,
        TRANSACTION_ID_PROBLEM       = 1,
        STATE_TRANSACTION_PROHIBITED = 2;

    public static final short
        CITY                              = 4,
        COUNTRY                           = 6,
        CURRENCY_CODE                     = 0,          /* MAXCOST            */
        DATE_OF_SERVICE                   = 0, 
        DATE_TIME_OF_ORIGINAL_SERVICE     = 1, 
        DATE_TIME_OF_THIS_SERVICE         = 0,
        ELECTRONIC_ADDRESS                = 1,
        EXTENDED_POSTAL_ADDRESS           = 1,
        //INITIAL_REQUESTER_ADDRESS         = 4,
        INITIAL_REQUESTER_ID              = 0,
        INSTITUTION_SYMBOL                = 1,
        MEDIUM_CHARACTERISTICS            = 1,
        MONETARY_VALUE                    = 1,          /* MAXCOST            */
        NAME_OF_INSTITUTION               = 1,
        NAME_OF_PERSON                    = 0,
        NAME_OF_PERSON_OR_INSTITUTION     = 0,
        //PERMISSION_TO_CHAIN               = 1,
        //PERMISSION_TO_CHANGE_SEND_TO_LIST = 3,
        //PERMISSION_TO_FORWARD             = 0,
        //PERMISSION_TO_PARTITION           = 2,
        PERSON_OR_INSTITUTION_SYMBOL      = 0,
        PERSON_SYMBOL                     = 0,
        BILLING_POSTAL_ADDRESS            = 0,
        DELIVERY_POSTAL_ADDRESS           = 0,
        DELIVERY_ELECTRONIC_ADDRESS       = 1,
        POSTAL_CODE                       = 7,
        POST_OFFICE_BOX                   = 3,
        REGION                            = 5,
        STL_INSTITUTION_SYMBOL            = 1,       /* LENDER              */
        STREET_AND_NUMBER                 = 2,
        SUB_TRANSACTION_QUALIFIER         = 3,
        SUPPLY_MEDIUM_TYPE                = 0, 
        SYSTEM_ADDRESS                    = 2,
        SYSTEM_ID                         = 0,
        TIME_OF_SERVICE                   = 1,
        TRANSACTION_GROUP_QUALIFIER       = 1,
        TRANSACTION_QUALIFIER             = 2;


    /*
    ** elements under ELECTRONIC_DELIVERY_SERVICE
    */

    public static final short
        DELIVERY_DESCRIPTION = 4,
        DELIVERY_DETAILS     = 5,
        DELIVERY_NAME        = 6,
        DELIVERY_TIME        = 7; 

   /* 
   ** elements under DELIVERY_DETAILS
   */

    public static final short
        E_DELIVERY_ADDRESS = 0,
        DELIVERY_ID        = 1;


    /* values for transaction type */

    public static final short
        SIMPLE_TT      =  1,
        PARTITIONED_TT =  2,
        CHAINED_TT     =  3;


    /* values for ill_service_type */

    public static final short
        LOAN_ST                = 1,
        COPY_NON_RETURNABLE_ST = 2,
        LOCATIONS_ST           = 3,
        ESTIMATE_ST            = 4,
        RESPONDER_SPECIFIC_ST  = 5;


    /* values for item_type */

    public static final short
        MONOGRAPH_IT = 1,
        SERIAL_IT    = 2,
        OTHER_IT     = 3;


    /* values for held_medium_type */

    public static final short
        PRINTED_HMT                 = 1,
        MICROFORM_HMT               = 3,
        FILM_OR_VIDEO_RECORDING_HMT = 4,
        AUDIO_RECORDING_HMT         = 5,
        MACHINE_READABLE_HMT        = 6,
        OTHER_HMT                   = 7;

 
    /* values for options messages */

    public static final short
        REQUIRES = 1,
        DESIRES  = 2,
        NEITHER  = 3;


    /* values for  supply medium type */

    public static final short
        PRINTED_SM                 =  1,
        PHOTOCOPY_SM               =  2,
        MICROFORM_SM               =  3,
        FILM_OR_VIDEO_RECORDING_SM =  4,
        AUDIO_RECORDING_SM         =  5,
        MACHINE_READABLE_SM        =  6,
        OTHER_SM                   =  7;


    /* values for place on hold */

    public static final short
        YES_POH = 1,
        NO_POH  = 2,
        ACCORDING_TO_RESPONDER_POLICY_POH = 3;


    /* values for preference */

    public static final short
        ORDERED   = 1,
        UNORDERED = 2;

    /* new for Status-or-error-report */

    public static final short
        //STATUS_REPORT                    = 44,
        //USER_STATUS_REPORT               =  0,
        //MOST_RECENT_SERVICE              =  6,
        //DATE_OF_MOST_RECENT_SERVICE      =  7,
        //INITIATOR_OF_MOST_RECENT_SERVICE =  8,
        //MOST_RECENT_SERVICE_NOTE         =  9,
        //PROVIDER_STATUS_REPORT           =  1,
        //ERROR_REPORT                     = 45,
        //CORRELATION_INFORMATION          =  0,
        //REPORT_SOURCE                    =  1,
        //USER_ERROR_REPORT                =  2,
        //PROVIDER_ERROR_REPORT            =  3,
        NOTE                             = 46;

    public static final short
        EXTENSION_IDENTIFIER = 0,
        EXTENSION_CRITICAL   = 1,
        EXTENSION_ITEM       = 2;

    public static final short OCLC_ILL_ERROR_TEXT = 1;

    /* Values for current state */

    public static final short
        NOT_SUPPLIED_CS         =  1,
        PENDING_CS              =  2,
        IN_PROCESS_CS           =  3,
        FORWARD_CS              =  4,
        CONDITIONAL_CS          =  5,
        CANCEL_PENDING_CS       =  6,
        CANCELLED_CS            =  7,
        SHIPPED_CS              =  8,
        RECEIVED_CS             =  9,
        RENEW_PENDING_CS        = 10,
        NOT_RECEIVED_OVERDUE_CS = 11,
        RENEW_OVERDUE_CS        = 12,
        OVERDUE_CS              = 13,
        RETURNED_CS             = 14,
        CHECKED_IN_CS           = 15,
        RECALL_CS               = 16,
        LOST_CS                 = 17,
        UNKNOWN_CS              = 18;


    /* ILL-Answer */

    public static final short
        //TRANSACTION_RESULTS        =   31,
        //RESULTS_EXPLANATION        =   32,
        UNFILLED_RESULTS           =    3,
        REASON_UNFILLED            =    0,
        //RESPONDER_SPECIFIC_RESULTS =   33,
        REASON_IN_REVIEW_LIST      =    1,
        REASON_IN_REVIEW_TEXT      =    1;

    /* Values for transaction results */

    public static final short
        CONDITIONAL_TR        =   1,
        RETRY_TR              =   2,
        UNFILLED_TR           =   3,
        LOCATIONS_PROVIDED_TR =   4,
        WILL_SUPPLY_TR        =   5,
        HOLD_PLACED_TR        =   6,
        ESTIMATE_TR           =   7;

    /* Values for reason unfilled */

    public static final short
        IN_USE_ON_LOAN_RU                            =    1,
        IN_PROCESS_RU                                =    2,
        LOST_RU                                      =    3,
        NON_CIRCULATING_RU                           =    4,
        NOT_OWNED_RU                                 =    5,
        ON_ORDER_RU                                  =    6,
        VOLUME_ISSUE_NOT_YET_AVAILABLE_RU            =    7,
        AT_BINDERY_RU                                =    8,
        LACKING_RU                                   =    9,
        NOT_ON_SHELF_RU                              =   10,
        ON_RESERVE_RU                                =   11,
        POOR_CONDITION_RU                            =   12,
        COST_EXCEEDS_LIMIT_RU                        =   13,
        CHARGES_RU                                   =   14,
        PREPAYMENT_REQUIRED_RU                       =   15,
        LACKS_COPYRIGHT_COMPLIANCE_RU                =   16,
        NOT_FOUND_AS_CITED_RU                        =   17,
        LOCATIONS_NOT_FOUND_RU                       =   18,
        ON_HOLD_RU                                   =   19,
        POLICY_PROBLEM_RU                            =   20,
        MANDATORY_MESSAGING_NOT_SUPPORTED_RU         =   21,
        EXPIRY_NOT_SUPPORTED_RU                      =   22,
        REQUESTED_DELIVERY_SERVICES_NOT_SUPPORTED_RU =   23,
        PREFERRED_DELIVERY_TIME_NOT_POSSIBLE_RU      =   24,
        OTHER_RU                                     =   27,
        RESPONDER_SPECIFIC_RU                        =   28;

}


/*
(copyright)1996 OCLC Online Computer Library Center, Inc., 6565 Frantz Road, 
Dublin, Ohio 43017-0702.  OCLC is a registered trademark of OCLC Online 
Computer Library Center, Inc.

NOTICE TO USERS:  The ILLAPI Utilities ("Software") has been developed by OCLC
Online Computer Library Center, Inc.  Subject to the terms and conditions set
forth below, OCLC grants to user a perpetual, non-exclusive, royalty-free
license to use, reproduce, alter, modify, and create derivative works from
Software, and to sublicense Software subject to the following terms and
 conditions:
    

SOFTWARE IS PROVIDED AS IS.  OCLC MAKES NO WARRANTIES, REPRESENTATIONS, OR
GUARANTEES WHETHER EXPRESS OR IMPLIED REGARDING SOFTWARE, ITS FITNESS FOR ANY
PARTICULAR PURPOSE, OR THE ACCURACY OF THE INFORMATION CONTAINED THEREIN.

User agrees that OCLC shall have no liability to user arising therefrom,
regardless of the basis of the action, including liability for special,
consequential, exemplary, or incidental damages, including lost profits,
Even if it has been advised of the possibility thereof.

User shall cause the copyright notice of OCLC to appear on all copies of
Software, including derivative works made therefrom.

VERSION: 2.1
*/

