/*  ErrorMsgDlg.java
**  
**  Bryan Wilhelm, Olivet Nazarene University
**  September 11, 1998
**  
**  Display a given error message.
*/


import java.awt.*;
import java.awt.event.*;

public class ErrorMsgDlg extends Dialog implements ActionListener
{
    Button btn_ok;
    Toolkit sys_metrics = Toolkit.getDefaultToolkit( );

    public ErrorMsgDlg( Frame parent, String msg )
    {
        super( parent, "Error Message", true );

        setLayout( null );
        addWindowListener( new CloseWindow( ) );

        Label msg_label = new Label( msg, Label.CENTER );
        msg_label.setFont( new Font( "Sans Serif", Font.PLAIN, 11 ) );
        btn_ok = new Button( "OK" );
        btn_ok.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        btn_ok.addActionListener( this );

        Panel pnl_main = new Panel( );
        pnl_main.setLayout( null );
        pnl_main.add( msg_label );
        pnl_main.add( btn_ok );
        msg_label.setBounds( 0, 0, 240, 14 );
        btn_ok.setBounds( 88, 36, 48, 24 );
        add( pnl_main );
        pnl_main.setBounds( 60, 32, 240, 60 );

        setSize( 300, 104 );
        setResizable( false );

        int x = (int)( ( sys_metrics.getScreenSize( ).width - 248 ) / 2 );
        int y = (int)( ( sys_metrics.getScreenSize( ).height - 92 ) / 2 );
        setLocation( x, y );
        setVisible( true );

    }

    public void paint( Graphics g )
    {
        Image caution = sys_metrics.getImage( "caution.gif" );
        g.drawImage( caution, 12, 32, this );
    }

    public void actionPerformed( ActionEvent event )
    {
        setVisible( false );
    }
}