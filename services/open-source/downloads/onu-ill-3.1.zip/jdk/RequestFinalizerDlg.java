/*  RequestFinalizerDlg.java
**
**  by Bryan Wilhelm, Olivet Nazarene University
**  September 11, 1998
**
**  This is the complicated part.  The RequestFinalizer needed to put the
**  IsoIllRequest together from the separate pieces gathered during the
**  program, construct the ASN.1/BER record, send it to OCLC and get their
**  response.
**
**  Parameters:  (1) PatronInfo
**               (2) Vector (of ItemInfo)
**               (3) numRequests
**  For the number of requests (numRequests), RequestFinalizer will combine
**  each ItemInfo with the PatronInfo and other system supplied variables
**  into a single IsoIllRequest, encrypt the request and submit it to OCLC.
*/

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;

import sun.net.ftp.*;

public class RequestFinalizerDlg    // this
       extends Dialog               // super
       implements ActionListener,   // event handling
                  Runnable,         // thread handling
                  ILL_ASN,          // constant data
                  ILL_API,          // constant data
                  ONU_ILL_CONST     // constant data

{
    /*=====================================================================*/
    /* Attributes                                                          */
    /*=====================================================================*/

    Toolkit sys_metrics = Toolkit.getDefaultToolkit( );
    Label   action;
    Button  btn_ok;

    Thread finalizerThread;

    PatronInfo patron_info;
    Vector     record = new Vector( 10 );  
               // A Vector of ItemInfo
    int        numRequests;

    Vector            requests = new Vector( 10 );
                      // A Vector of IsoIllRequest
    IsoIllApdu        apdu;
    BerString         berRec, 
                      berResponse;
    Socket            connection;
    DataOutputStream  output;
    DataInputStream   input;

    boolean error_flag = false;

    String str_bookApp = new String( DEFAULT_BOOK_APP ),
           str_bookParam = new String( DEFAULT_BOOK_PARAM ),
           str_perApp = new String( DEFAULT_PER_APP ),
           str_perParam = new String( DEFAULT_PER_PARAM ),
           str_lenderList = new String( );
    short  service_code = 3;


    /*=====================================================================*/
    /* Constructor                                                         */
    /*=====================================================================*/

    public RequestFinalizerDlg( 
        Frame parent,
        PatronInfo patron,
        Vector items,
        int n )
    {
        /* superclass call and initial setup */
        super( parent, "Submit Request", true );
        setSize( 360, 100 );
        setResizable( false );
        setLayout( null );
        setFont( new Font( "Sans Serif", Font.PLAIN, 11 ) );

        /* initialize variables */
        readData( );
        patron_info = patron;
        record = items;
        numRequests = n;

        /* create and add components but don't show them */
        Panel msgPanel = new Panel( );
        msgPanel.setSize( 330, 25 );
        msgPanel.setLayout( new FlowLayout( FlowLayout.CENTER ) );

        action = new Label( "                    Initializing the request record...                    " );
                            // big spaces so that the label won't collapse 
                            // and smother the other labels to follow.
        msgPanel.add( action );
        action.setAlignment( Label.CENTER );
        action.setBounds( 0, 0, 330, 25 );

        btn_ok = new Button( "OK" );
        btn_ok.addActionListener( this );
        btn_ok.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        btn_ok.setEnabled( false );

        add( msgPanel );
        add( btn_ok );

        msgPanel.setBounds( 15, 20, 330, 25 );
        btn_ok.setBounds( 148, 60, 64, 24 );

        finalizerThread = new Thread( this, "Finalizer" );
        finalizerThread.start( );

        /* display the dialog */
        int x = (int) ( ( sys_metrics.getScreenSize( ).width - 300 ) / 2.0 );
        int y = (int) ( ( sys_metrics.getScreenSize( ).height - 150 ) / 2.0 );
        setLocation( x, y );
        setVisible( true );

    }


    /*=====================================================================*/
    /* Mandatory Methods                                                   */
    /*=====================================================================*/

    public void actionPerformed( ActionEvent event )
    {
        setVisible( false );
    }

    /*
    public void start( )
    {
        finalizerThread = new Thread( this, "Finalizer" );
        finalizerThread.start( );
    }

    public void stop( )
    {
        finalizerThread.stop( );
    }
    */

    public void run( )
    {
        /*
        ** I choose to compile of the variable into a single Vector of 
        ** IsoIllRequests.  Compiling each successive request item into a 
        ** single IsoIllRequest and sending them one at a time is actually
        ** more efficient for memory.  I'm assuming that memory is not a 
        ** problem on a machine running this application.  However an
        ** Applet version should run using the alternative, since the 
        ** platform capabilities cannot be assumed.
        */

        int x;

        /* initialize request record variables */
        for ( x = 0; x < numRequests; x++ ) {
            IsoIllRequest r = new IsoIllRequest( );
            r.service_date = ILLDate.getFormattedDate( new Date( ) );
            r.transaction_qualifier =
                new String( LIB_SYMBOL + ( new Date( ) ).getTime( ) );
                /* transaction qualifier must be universally unique */
            r.transaction_group_qualifier = 
                new String( LIB_SYMBOL + "-ILL-WINAPP" );
                /* Java applet is "ONU-ILL-APPLET"
                ** UNIX CGI is "ONU-ILL-CGI"
                */
            r.user_pid = System.getProperty( "user.name" );
                /* Use "AppletUser" for the applet version
                ** since it cannot get this information
                */
            r.requester_id = new String( LIB_SYMBOL );
            r.authorization = new String( AUTHORIZATION );
            r.password = new String( PASSWORD );
            r.delivery_name = new String( INSTITUTION_NAME );
            r.delivery_extension = new String( DEL_EXT );
            r.delivery_street_no = new String( DEL_STREET );
            r.delivery_po_box = new String( DEL_PO_BOX );
            r.delivery_city = new String( DEL_CITY );
            r.delivery_region = new String( DEL_STATE );
            r.delivery_country = new String( DEL_COUNTRY );
            r.delivery_postal_code = new String( DEL_ZIP_CODE );
            r.delivery_service = new String( SHIP_VIA_SERVICE );
            r.electronic_delivery_description = new String( ELECTRONIC_SERVICE );
            r.fax_address = new String( DEL_FAX );
            r.email_address = new String( DEL_EMAIL );
            r.need_before_date = ( (ItemInfo) record.elementAt( x ) ).need_before_date;
            r.patron_id = patron_info.patron_id;
            r.patron_full_name = patron_info.patron_full_name;
            r.p_home_street_no = patron_info.p_home_street_no;
            r.p_home_po_box = patron_info.p_home_po_box;
            r.p_home_city = patron_info.p_home_city;
            r.p_home_region = patron_info.p_home_region;
            r.p_home_country = patron_info.p_home_country;
            r.p_home_postal_code = patron_info.p_home_postal_code;
            r.patron_phone = patron_info.patron_phone;
            r.patron_email = patron_info.patron_email;
            r.patron_fax = patron_info.patron_fax;
            r.patron_status = patron_info.patron_status;
            r.patron_notes = ( (ItemInfo) record.elementAt( x ) ).patron_notes;
            r.held_medium_type = ( (ItemInfo) record.elementAt( x ) ).held_medium_type;
            r.author = 
                ( ( (ItemInfo) record.elementAt( x ) ).ill_service_type == BOOK_REQUEST ?
                ( (ItemInfo) record.elementAt( x ) ).author : "" );
            r.title = ( (ItemInfo) record.elementAt( x ) ).title;
            r.publisher = ( (ItemInfo) record.elementAt( x ) ).publisher;
            r.volume = ( (ItemInfo) record.elementAt( x ) ).volume;
            r.issue = ( (ItemInfo) record.elementAt( x ) ).issue;
            r.edition = ( (ItemInfo) record.elementAt( x ) ).edition;
            r.publication_date = 
                ( ( (ItemInfo) record.elementAt( x ) ).ill_service_type == BOOK_REQUEST ?
                ( (ItemInfo) record.elementAt( x ) ).publication_date : "" );
            r.publication_date_of_component = 
                ( ( (ItemInfo) record.elementAt( x ) ).ill_service_type == PERIODICAL_REQUEST ?
                ( (ItemInfo) record.elementAt( x ) ).publication_date : "" );
            r.author_of_article =
                ( ( (ItemInfo) record.elementAt( x ) ).ill_service_type == PERIODICAL_REQUEST ?
                ( (ItemInfo) record.elementAt( x ) ).author : "" );
            r.title_of_article = ( (ItemInfo) record.elementAt( x ) ).title_of_article;
            r.pagination = ( (ItemInfo) record.elementAt( x ) ).pagination;
            r.isbn = ( (ItemInfo) record.elementAt( x ) ).isbn;
            r.issn = ( (ItemInfo) record.elementAt( x ) ).issn;
            r.oclc_no = ( (ItemInfo) record.elementAt( x ) ).oclc_no;
            r.verification_reference_source = ( (ItemInfo) record.elementAt( x ) ).verification_reference_source;
            r.dissertation = ( (ItemInfo) record.elementAt( x ) ).dissertation;
            r.copyright_compliance = new String( COPYRIGHT );
            r.send_to_list = new String( str_lenderList );
                /* send to list can be used to send a profile to search
                ** for this specific item.
                */
            r.requester_note = 
                ( ( (ItemInfo) record.elementAt( x ) ).ill_service_type == BOOK_REQUEST ?
                BOOK_DATA : PER_DATA );
            r.oclc_ill_service_type = service_code;
            r.ill_service_type = ( (ItemInfo) record.elementAt( x ) ).ill_service_type;
            r.preference = UNORDERED;
            r.change_send_to = ( service_code == 1 );

            requests.addElement( r );
        }

        try {
            action.setText( "Establishing connection to OCLC..." );

            connection = new Socket( OCLC_SERVER, OCLC_PORT );

            action.setText( "Establishing I/O streams..." );
            output = new DataOutputStream( connection.getOutputStream( ) );
            input = new DataInputStream( connection.getInputStream( ) );

            for ( x = 0; x < numRequests; x++ ) {
                /* Build the ASN.1/BER record */
                action.setText( "Building request record..." );
                berRec = ( (IsoIllRequest) requests.elementAt( x ) ).BuildIsoIllRequest( );

                /* Send the record to OCLC */
                action.setText( "Sending request record..." );
                berRec.writeBerString( output );

                /* Get their response */
                byte response[] = new byte[ 256 ];
                action.setText( "Receiving response from OCLC..." );
                if ( input.read( response ) <= 0 )
                    throw new IOException( "No Response received." );
                else
                    berResponse = new BerString( response );

                /* Process response */
                action.setText( "Processing request response..." );
                apdu = new IsoIllApdu( berResponse );

                switch ( apdu.type ) {
                case ( STATUS_OR_ERROR_REPORT_APDU ):
                    action.setText( "Request failed, contact Benner Library." );
                    error_flag = true;
                case ( ILL_ANSWER_APDU ):
                    action.setText( "Request was successful!" );
                default:
                    action.setText( "Indeterminant response type." );
                }
            }

            /* close connections */
            action.setText( "Closing connection and I/O streams..." );
            input.close( );
            output.close( );
            connection.close( );

            action.setText( "Request transaction is complete." );

        }
        catch ( Exception all ) {
            error_flag = true;
            action.setText( "Request failed, contact Benner Library." );
        }
        finally {
            btn_ok.setEnabled( true );
        }

    }


    /*=====================================================================*/
    /* Methods                                                             */
    /*=====================================================================*/

    public void readData( )
    {
        try {
            /* establish connection to server */
            FtpClient client = new FtpClient( ADMIN_HOST );

            /* log into server */
            client.login( ADMIN_USER_ID, ADMIN_PASSWORD );

            /* change to the appropriate directory */
            client.cd( ADMIN_PATH );

            /* get the file */
            client.get( ADMIN_FILE );

            /* close the server connection */
            client.sendServer( "quit" );

            /* get data file information */
            File file = new File( ADMIN_FILE );
            DataInputStream input = new DataInputStream(
                new FileInputStream( file ) );
            str_bookApp = input.readUTF( );
            str_bookParam = input.readUTF( );
            str_perApp = input.readUTF( );
            str_perParam = input.readUTF( );
            str_lenderList = input.readUTF( );
            service_code = input.readShort( );
            input.close( );
            file.delete( );
        }

        catch ( IOException rd ) {
            /* Do nothing.  If the file cannot be read then the default 
            ** parameters are used.
            */
        }
    }
}