/*
**  ONU ILL
**
**  VERSION:  3.1 (Java/2.1)
**  AUTHOR:   Bryan Wilhelm
**            Olivet Nazarene University
**
**  DATE CREATED:  May 11, 1998
**
**  MODIFICATION HISTORY:
**  --------------------------------------------------------------------
**  06/19/1998    Created the EDU.olivet.ill package to handle the more
**                technical details.  Changed the implementation of the
**                FieldInfo.  Eliminated the RequestRecord class.
**  07/24/1998    Abandoned IPT in favor of ISO 10161 standard.
**  --------------------------------------------------------------------
**
**  This Java application is a windows utility for requesting inter-
**  library loan services through OCLC.  Both book and periodical
**  requests are handled by this application.
**
**  ONU_ILL was written in Java 1.1 (JDK 1.1.6) using ASN.1/BER
**  utilities from OCLC.  This application complies with the OCLC ILL
**  format requirements as of May 1998.
**
**  ISO 10161 ILL Request standards are also met.
*/


import java.awt.*;
import java.awt.event.*;
import java.util.*;


public class ONU_ILL 
       extends Frame 
       implements ActionListener, 
                  ONU_ILL_CONST
{
    /*=====================================================================*/
    /* Attributes                                                          */
    /*=====================================================================*/
    private Button    btn_book,
                      btn_periodical,
                      btn_submit,
                      btn_delete,
                      btn_clear,
                      btn_cancel;
    private List      lst_display;
    private MenuBar   menubar;
    private Menu      menu_main, 
                      menu_request, 
                      menu_help;
    private MenuItem  mi_book,
                      mi_periodical,
                      mi_submit,
                      mi_delete,
                      mi_clear,
                      mi_exit,
                      mi_about;

    /* Patron information is stored separately until submission.
    ** Both the patron information and the request record can be
    ** accessed from outside the class.
    */
    public PatronInfo patron_info;
    public Vector record = new Vector( MAX_REQUESTS );  // Vector of ItemInfo
    public int numRequests = 0;  // does not need to be public

    private Toolkit sys_metrics = Toolkit.getDefaultToolkit( );
    private int i;   // loop counter


    /*=====================================================================*/
    /* Constructor                                                         */
    /*=====================================================================*/
    public ONU_ILL( )
    {
        /* Call to superclass */
        super( INSTITUTION_NAME + " Interlibrary Loan" );

        /* Setup window layout */
        setSize( 580, 360 );
        setLayout( new BorderLayout( ) );

        /* Call to PatronInfoDlg to retrieve patron information */
        new PatronInfoDlg( this, patron_info = new PatronInfo( ) );

        /* Create application components */
        btn_book = new Button( "Book Form" );
        btn_book.addActionListener( this );
        btn_periodical = new Button( "Periodical Form" );
        btn_periodical.addActionListener( this );
        btn_submit = new Button( "Submit Request" );
        btn_submit.addActionListener( this );
        btn_submit.setEnabled( false );
        btn_delete = new Button( "Delete" );
        btn_delete.addActionListener( this );
        btn_delete.setEnabled( false );
        btn_clear = new Button( "Clear" );
        btn_clear.addActionListener( this );
        btn_clear.setEnabled( false );
        btn_cancel = new Button( "Cancel" );
        btn_cancel.addActionListener( this );

        lst_display = new List( 10, true );
        lst_display.setMultipleMode( false );
        lst_display.addActionListener( this );

        mi_book = new MenuItem ( "Book Form" );
        mi_book.addActionListener( this );
        mi_periodical = new MenuItem( "Periodical Form" );
        mi_periodical.addActionListener( this );
        mi_delete = new MenuItem( "Delete" );
        mi_delete.addActionListener( this );
        mi_delete.setEnabled( false );
        mi_clear = new MenuItem( "Clear" );
        mi_clear.addActionListener( this );
        mi_clear.setEnabled( false );
        mi_submit = new MenuItem( "Submit" );
        mi_submit.addActionListener( this );
        mi_submit.setEnabled( false );
        mi_exit = new MenuItem( "Exit" );
        mi_exit.addActionListener( this );
        mi_about = new MenuItem( "About ONU-ILL" );
        mi_about.addActionListener( this );

        menu_request = new Menu( "Request Form" );
        menu_request.add( mi_book );
        menu_request.add( mi_periodical );
        menu_main = new Menu( "Main" );
        menu_main.add( menu_request );
        menu_main.add( mi_delete );
        menu_main.add( mi_clear );
        menu_main.addSeparator();
        menu_main.add( mi_submit );
        menu_main.add( mi_exit );
        menu_help = new Menu( "Help" );
        menu_help.add( mi_about );
        menubar = new MenuBar();
        menubar.add( menu_main );
        menubar.add( menu_help );
        menubar.setHelpMenu( menu_help );

        Panel pnl_main = new Panel( );
        pnl_main.setLayout( null );
        pnl_main.setBackground( SystemColor.menu );
        pnl_main.setSize( ( sys_metrics.getScreenSize( ) ).width, 36 );
        pnl_main.add( btn_book );
        pnl_main.add( btn_periodical );
        pnl_main.add( btn_submit );
        pnl_main.add( btn_delete );
        pnl_main.add( btn_clear );
        pnl_main.add( btn_cancel );

        /* Set button bounds. */
        btn_book.setBounds(         8,  0,  80,  24 );
        btn_periodical.setBounds(  92,  0, 104,  24 );
        btn_submit.setBounds(     204,  0, 104,  24 );
        btn_delete.setBounds(     316,  0,  80,  24 );
        btn_clear.setBounds(      400,  0,  80,  24 );
        btn_cancel.setBounds(     484,  0,  80,  24 );

        /* Add window components */
        setMenuBar( menubar );
        add( pnl_main, BorderLayout.NORTH );
        add( lst_display, BorderLayout.CENTER );

        /* Display the window in the center of the screen. */
        int x = (int)( ( ( sys_metrics.getScreenSize( ) ).width - 580 ) / 2 );
        int y = (int)( ( ( sys_metrics.getScreenSize( ) ).height - 360 ) / 2 );
        setLocation( x, y );
        setVisible( true );

    }


    /*=====================================================================*/
    /* Abstract methods                                                    */
    /*=====================================================================*/

    public void actionPerformed( ActionEvent event )
    {
        if ( event.getSource( ) == btn_book || 
             event.getSource( ) == mi_book ) 
        {
            ItemInfo item = new ItemInfo( );

            /* Display book form and return with request. */
            new BookFormDlg( this, item, numRequests + 1 );

            /* Check if request was made, if so increment number of requests;
            ** if not return to main program--do not change the status of the
            ** main window.
            */
            if ( item.request_made ) {

                /* increment number of requests */
                record.addElement( item );
                ++numRequests;

                /* enable appropriate buttons and menu items */
                btn_submit.setEnabled( true );
                btn_delete.setEnabled( true );
                btn_clear.setEnabled( true );
                mi_submit.setEnabled( true );
                mi_delete.setEnabled( true );
                mi_clear.setEnabled( true );
                if ( numRequests == MAX_REQUESTS ) {
                    btn_book.setEnabled( false );
                    btn_periodical.setEnabled ( false );
                    mi_book.setEnabled( false );
                    mi_periodical.setEnabled( false );
                }

                /* add request item to list */
                lst_display.addItem( 
                    new String( item.title + ", by " +
                                item.author ) 
                );

            }

        }

        else if ( event.getSource( ) == btn_periodical ||
                  event.getSource( ) == mi_periodical ) 
        {
            ItemInfo item = new ItemInfo( );

            /* Display periodical form and return with request. */
            new PeriodicalFormDlg( this, item, numRequests + 1 );

            /* Check if request was made, if so increment number of requests;
            ** if not return to main program--do not change the status of the
            ** main window.
            */
            if ( item.request_made ) {

                /* increment number of requests */
                record.addElement( item );
                ++numRequests;

                /* enable appropriate buttons and menu items */
                btn_submit.setEnabled( true );
                btn_clear.setEnabled( true );
                btn_delete.setEnabled( true );
                mi_submit.setEnabled( true );
                mi_clear.setEnabled( true );
                mi_delete.setEnabled( true );
                if ( numRequests == MAX_REQUESTS ) {
                    btn_book.setEnabled( false );
                    btn_periodical.setEnabled ( false );
                    mi_book.setEnabled( false );
                    mi_periodical.setEnabled( false );
                }

                /* add request item to list */
                lst_display.addItem( new String(
                    "\"" + item.title_of_article +
                    "\", in " + item.title + 
                    ( item.author.equals( "" ) ? "" : 
                    ", by " + item.author ) )
                );
            }

        }

        /*
        ** Request submission and program termination
        */

        else if ( event.getSource( ) == btn_submit || 
                  event.getSource( ) == mi_submit ) 
        {

            RequestFinalizerDlg rf = 
                new RequestFinalizerDlg( this, patron_info, record, numRequests );

            setVisible( false );

            new AppreciationDlg( this, rf.error_flag );

            System.exit( 0 );  // exit status success

        }

        else if ( event.getSource( ) == btn_delete ||
                  event.getSource( ) == mi_delete ) 
        {
            int sel;
            /* get the current selection... */
            if ( ( sel = lst_display.getSelectedIndex( ) ) == -1 ) {
                new ErrorMsgDlg( this, "No item is selected." );
            }
            else {
                /* ...and get rid of it */
                lst_display.remove( sel );
                record.removeElementAt( sel );

                /* if there are no more requests then
                 * disable some buttons
                 */
                if ( --numRequests == 0 ) {
                    btn_book.setEnabled( true );
                    btn_periodical.setEnabled( true );
                    btn_submit.setEnabled( false );
                    btn_delete.setEnabled( false );
                    btn_clear.setEnabled( false );
                    mi_book.setEnabled( true );
                    mi_periodical.setEnabled( true );
                    mi_submit.setEnabled( false );
                    mi_delete.setEnabled( false );
                    mi_clear.setEnabled( false );
                }
            }
        }

        else if ( event.getSource( ) == btn_clear ||
                  event.getSource( ) == mi_clear ) 
        {
            /* Disable appropriate buttons and menu items */
            btn_book.setEnabled( true );
            btn_periodical.setEnabled( true );
            btn_submit.setEnabled( false );
            btn_delete.setEnabled( false );
            btn_clear.setEnabled( false );
            mi_book.setEnabled( true );
            mi_periodical.setEnabled( true );
            mi_submit.setEnabled( false );
            mi_delete.setEnabled( false );
            mi_clear.setEnabled( false );

            /* Clear request records. */
            record.removeAllElements( );

            /* Set number of requests to zero. */
            numRequests = 0;

            /* Clear the list box. */
            lst_display.removeAll( );

        }

        else if ( event.getSource( ) == mi_about ) {

            /* Display about dialog and return. */
            new AboutDlg( this );

        } else if ( event.getSource( ) == lst_display ) {
            /* This event indicates that an event such as a double-click
            ** or pressing ENTER occurred.
            */

            /* get the current selection -- if the event was on
            ** the list box then one of the items will have the
            ** focus, so getSelectedIndex will never return -1
            ** here.
            */
            int sel = lst_display.getSelectedIndex( );
            ItemInfo item = (ItemInfo) record.elementAt( sel );

            switch ( item.ill_service_type ) {
            case ( BOOK_REQUEST ):
                new BookFormDlg( this, item, sel + 1 );
                lst_display.deselect( sel );
                lst_display.replaceItem( 
                    new String( item.title + ", by " +
                                item.author ),
                    sel
                );
                break;
            case ( PERIODICAL_REQUEST ):
                new PeriodicalFormDlg( this, item, sel + 1 );
                lst_display.deselect( sel );
                lst_display.replaceItem( new String(
                    "\"" + item.title_of_article +
                    "\", in " + item.title + 
                    ( item.author.equals( "" ) ? "" : 
                    ", by " + item.author ) ),
                    sel
                );
            }

        } else {

            /* Remove the window and end the program. */
            setVisible( false );
            System.exit( 0 );

        }

    }


    /*=====================================================================*/
    /* Methods                                                             */
    /*=====================================================================*/


    /*
    ** PROGRAM ENTRY POINT
    ** This is the first method to be called on startup.  It passes
    ** control to the main application window.
    */
    public static void main( String args[] )
    {
        ONU_ILL main_app = new ONU_ILL( );
        main_app.addWindowListener( new CloseApplication( ) );
    }

}



/*
** (c)1998 Olivet Nazarene University, 240 East Marsile,
** Bourbonnais, IL 60914-0592.
**
** NOTICE TO USERS:  ONU-ILL ("Software") has been developed by
** Olivet Nazarene University.  Subject to the terms and conditions set
** forth below, Olivet grants to user a perpetual, non-exclusive, royalty-
** free license to use, reproduce, alter, modify, and create derivative
** works from Software, and to sublicense Software subject to the following
** terms and conditions:
**
** SOFTWARE IS PROVIDED AS IS.  OLIVET MAKES NO WARRANTIES, REPRESENTATIONS,
** OR GUARANTEES WHETHER EXPRESS OR IMPLIED REGARDING SOFTWARE, ITS FITNESS
** FOR ANY PARTICULAR PURPOSE, OR THE ACCURACY OF THE INFORMATION CONTAINED
** THEREIN.
**
** User agrees that Olivet shall have no liability to user arising
** therefrom, regardless of the basis of the action, including liability for
** special, consequential, exemplary, or incidental damages, including lost
** profits, even if it has been advised of the possibility thereof.
**
** User shall cause the copyright notice of Olivet to appear on all copies
** of Software, including derivative works made therefrom.
*/

/*
** (c)1996 OCLC Online Computer Library Center, Inc., 6565 Frantz Road,
** Dublin, Ohio 43017-0702.  OCLC is a registered trademark of OCLC Online
** Computer Library Center, Inc.
**
** NOTICE TO USERS:  The BER Utilities ("Software") has been developed by
** OCLC Online Computer Library Center, Inc.  Subject to the terms and
** conditions set forth below, OCLC grants to user a perpetual, non-
** exclusive, royalty-free license to use, reproduce, alter, modify, and
** create derivative works from Software, and to sublicense Software subject
** to the following terms and conditions:
**
** SOFTWARE IS PROVIDED AS IS.  OCLC MAKES NO WARRANTIES, REPRESENTATIONS,
** OR GUARANTEES WHETHER EXPRESS OR IMPLIED REGARDING SOFTWARE, ITS FITNESS
** FOR ANY PARTICULAR PURPOSE, OR THE ACCURACY OF THE INFORMATION CONTAINED
** THEREIN.
**
** User agrees that OCLC shall have no liability to user arising therefrom,
** regardless of the basis of the action, including liability for special,
** consequential, exemplary, or incidental damages, including lost profits,
** even if it has been advised of the possibility thereof.
**
** User shall cause the copyright notice of OCLC to appear on all copies of
** Software, including derivative works made therefrom.
*/
