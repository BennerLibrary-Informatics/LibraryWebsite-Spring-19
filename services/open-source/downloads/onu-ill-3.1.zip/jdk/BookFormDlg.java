/*  BookFormDlg.java
**
**  by Bryan Wilhelm, Olivet Nazarene University
**  September 11, 1998
** 
**  Dialog box interface to get information about a book request.  It
**  stores the information in a ItemInfo record that is latter retrieved to
**  construct a ISO-Request.
*/


import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.*;
import java.util.*;
import sun.net.ftp.*;

public class BookFormDlg 
       extends Dialog 
       implements ActionListener, 
                  ILL_API, 
                  ONU_ILL_CONST
{
    /*
    ** Attributes
    */
    private Button        btn_ok, 
                          btn_cancel, 
                          btn_more,
                          btn_holdings;
    private InfoTextField tf_author,       // AUTHOR
                          tf_title,        // TITLE
                          tf_edition,      // EDITION
                          tf_publisher,    // IMPRINT
                          tf_pubyear,      // IMPRINT
                          tf_volume;       // VOLUME
    private TextField     tf_needbefore;   // NEEDBEFORE_DATE
    private CheckboxGroup grp_verified;    // VERIFIED
    private Checkbox      cb_yesVerified, 
                          cb_noVerified;

    public  ItemInfo request;
    private int      numRequests;

    private Toolkit sys_metrics = Toolkit.getDefaultToolkit( );
    private Font    boldFont = new Font( "Sans Serif", Font.BOLD, 11 );

    String str_bookApp = new String( DEFAULT_BOOK_APP ),
           str_bookParam = new String( DEFAULT_BOOK_PARAM );


    /*=======================================================================
    ** MoreInfoDlg
    */
    class MoreInfoDlg extends Dialog implements ActionListener, ItemListener
    {
        /*
        ** Attributes
        ** These properties are local to MoreInfoDlg and are not in the scope
        ** of BookFormDlg.  However, the properties of BookFormDlg are in the
        ** scope of MoreInfoDlg.
        */
        private Button        btn_ok, 
                              btn_cancel;
        private Checkbox      cb_oclcNum,
                              cb_ericNum,
                              cb_isbn,
                              cb_dissertation,     // DISSERTATION_NOTE
                              cb_conference;       // +DISSERTATION_NOTE
        private TextField     tf_oclcNum,          // OCLC_NO
                              tf_ericNum,          // PATRON_NOTES
                              tf_isbn;
        private InfoTextField tf_whereFound;       // +PATRON_NOTES
        private TextArea      ta_comments;         // +PATRON_NOTES

        /*
        ** Constructor
        */
        public MoreInfoDlg( Frame parent, int n )
        {
            /* Call dialog superclass constructor */
            super( parent, "Item " + n + ":  Additional Information", true );

            /* Set window size, layout, and listeners */
            setSize( 456, 456 );
            setResizable( false );
            setLayout( null );
            setFont( new Font( "Sans Serif", Font.PLAIN, 11 ) );
            addWindowListener( new CloseWindow( ) );

            /* Create dialog box components */
            Label illTitle = new Label( "Interlibrary Loan" );
            Label formTitle = new Label( "Book Request Form" );
            Label addInfo = new Label( "Additional Information" );
            Label srcInfo = new Label( "Source Information" );
            illTitle.setFont( new Font( "Serif", Font.BOLD + Font.ITALIC, 24 ) );
            formTitle.setFont( new Font( "Serif", Font.BOLD + Font.ITALIC, 24 ) );

            cb_isbn = new Checkbox( "ISBN Number", false );
            cb_isbn.addItemListener( this );
            cb_oclcNum = new Checkbox( "OCLC Number", false );
            cb_oclcNum.addItemListener( this );
            cb_ericNum = new Checkbox( "ERIC Document Number", false );
            cb_ericNum.addItemListener( this );
            cb_dissertation = new Checkbox( "Dissertation/Thesis", false );
            cb_conference = new Checkbox( "Conference Proceedings", false );

            tf_whereFound = new InfoTextField( "Source of citation", 32 );
            Label commentsLabel = new Label( "Enter any comments helpful to order " +
                "this item" );
            ta_comments = new TextArea( 32, 10 );

            btn_ok = new Button( "OK" );
            btn_ok.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
            btn_ok.addActionListener( this );
            btn_cancel = new Button( "Cancel" );
            btn_cancel.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
            btn_cancel.addActionListener( this );

            /* Add components to the dialog box. */
            add( illTitle );
            add( formTitle );
            add( addInfo );
            add( srcInfo );
            add( cb_isbn );
            add( tf_isbn = new TextField( ) );
            add( cb_oclcNum );
            add( tf_oclcNum = new TextField( ) );
            add( cb_ericNum );
            add( tf_ericNum = new TextField( ) );
            add( cb_dissertation );
            add( cb_conference );
            add( tf_whereFound );
            add( commentsLabel );
            add( ta_comments );
            add( btn_ok );
            add( btn_cancel );

            /* Set the location and bounds of the dialog components. */
            illTitle.setBounds( 24, 24, 384, 27 );
            formTitle.setBounds( 24, 51, 384, 27 );

            addInfo.setBounds( 24, 86, 104, 14 );
            cb_isbn.setBounds( 36, 108, 164, 15 );
            cb_oclcNum.setBounds( 36, 134, 164, 15 );
            cb_ericNum.setBounds( 36, 160, 164, 15 );
            cb_dissertation.setBounds( 36, 186, 164, 15 );
            cb_conference.setBounds( 36, 212, 164, 15 );
            tf_isbn.setBounds( 240, 107, 180, 20 );
            tf_oclcNum.setBounds( 240, 133, 180, 20 );
            tf_ericNum.setBounds( 240, 159, 180, 20 );

            srcInfo.setBounds( 24, 254, 92, 14 );
            tf_whereFound.setBounds( 36, 270,
                ( tf_whereFound.getSize( ) ).width,
                ( tf_whereFound.getSize( ) ).height );
            commentsLabel.setBounds( 36, 316, 300, 14 );
            ta_comments.setBounds( 36, 332, 384, 60 );

            btn_ok.setBounds( 298, 416, 64, 24 );
            btn_cancel.setBounds( 374, 416, 64, 24 );

            /* Display dialog box in the center of the screen. */
            int x = (int)( ( ( sys_metrics.getScreenSize( ) ).width - 456 ) / 2 );
            int y = (int)( ( ( sys_metrics.getScreenSize( ) ).height - 456 ) / 2 );
            setLocation( x, y );
            setVisible( true );

        }

        public void paint( Graphics g )
        {
            /* Draw 3D rectangle */
            g.draw3DRect( 18, 93, 420, 149, false );
            g.draw3DRect( 18, 261, 420, 145, false );

            /* 
            ** Hide the two text fields.  All components are visible after the
            ** constructor terminates.  This method is automatically called
            ** after the constructor.
            */
            tf_isbn.setVisible( false );
            tf_oclcNum.setVisible( false );
            tf_ericNum.setVisible( false );
        }

        public void actionPerformed( ActionEvent event )
        {
            /* If "OK" was pressed, process fields, */
            if ( event.getSource( ) == btn_ok ) {

                request.oclc_no = 
                    cb_oclcNum.getState( ) ? tf_oclcNum.getText( ) : BLANK;
                request.patron_notes =
                    cb_ericNum.getState( ) ? tf_ericNum.getText( ) : BLANK;
                request.dissertation =
                    cb_dissertation.getState( ) ? cb_dissertation.getLabel( ) : BLANK;
                if ( request.dissertation.equals( BLANK ) ) {
                    request.dissertation =
                        cb_conference.getState( ) ? cb_conference.getLabel( ) : BLANK;
                } else {
                    request.dissertation +=
                        cb_conference.getState( ) ? cb_conference.getLabel( ) : BLANK;
                }
                request.isbn = tf_isbn.getText( );

                if ( request.patron_notes.equals( BLANK ) ) {
                    if ( ( request.patron_notes = tf_whereFound.getText( ) ).equals( BLANK ) ) {
                        request.patron_notes = ta_comments.getText( );
                    } else {
                        request.patron_notes += ta_comments.getText( );
                    }
                } else {
                    if ( ( request.patron_notes += tf_whereFound.getText( ) ).equals( BLANK ) ) {
                        request.patron_notes = ta_comments.getText( );
                    } else {
                        request.patron_notes += ta_comments.getText( );
                    }
                }

            }

            /* else "Cancel" was pressed--don't do anything. */

            /* This is done when either button is pressed. */
            setVisible( false );
            dispose( );
        }

        public void itemStateChanged( ItemEvent e )
        {
            /* Display the text fields based on the state of the check box. */
            tf_isbn.setVisible( cb_isbn.getState( ) );
            tf_oclcNum.setVisible( cb_oclcNum.getState( ) );
            tf_ericNum.setVisible( cb_ericNum.getState( ) );

            /*
            ** TODO:  There seems to be a boolean logic problem here or in 
            **        the JVM.
            */
        }

    }
    /*
    ** End of MoreInfoDlg
    =======================================================================*/


    /*
    ** Constructor
    */
    public BookFormDlg( Frame parent, ItemInfo r, int n )
    {
        /* Call dialog superclass constructor */
        super( parent, "Item " + n + ":  Book Request Form", true );
        request = r;
        numRequests = n;

        /* Set window size, layout, and listeners */
        setSize( 456, 456 );
        setResizable( false );
        setLayout( null );
        setFont( new Font( "Sans Serif", Font.PLAIN, 11 ) );
        addWindowListener( new CloseWindow( ) );

        /* Create dialog box components */
        Label illTitle = new Label( "Interlibrary Loan" );
        Label formTitle = new Label( "Book Request Form" );
        Label itemInfo = new Label( "Item Information" );
        Label nbdTitle = new Label( "Date Needed By" );
        illTitle.setFont( new Font( "Serif", Font.BOLD + Font.ITALIC, 24 ) );
        formTitle.setFont( new Font( "Serif", Font.BOLD + Font.ITALIC, 24 ) );

        Label verifiedLabel = new Label( "Have you checked " + LIBRARY_NAME + 
            " for this item?" );
        verifiedLabel.setFont( boldFont );
        grp_verified = new CheckboxGroup( );
        cb_yesVerified = new Checkbox( "Yes", grp_verified, false );
        cb_noVerified = new Checkbox( "No", grp_verified, true );

        Label nbdLabel = new Label( "Enter the date this item is needed by. " +
            "The default date is pre-entered." );
        nbdLabel.setFont( boldFont );
        DateFormat df = DateFormat.getDateInstance( DateFormat.LONG );
        tf_needbefore = new TextField( 10 );
        tf_needbefore.setText( df.format( DEFAULT_NEEDBEFORE_DATE ) );

        btn_more = new Button( "More" );
        btn_more.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        btn_more.addActionListener( this );
        btn_ok = new Button( "OK" );
        btn_ok.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        btn_ok.addActionListener( this );
        btn_cancel = new Button( "Cancel" );
        btn_cancel.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        btn_cancel.addActionListener( this );
        btn_holdings = new Button( LIBRARY_NAME + " Book Holdings" );
        btn_holdings.addActionListener( this );

        /* Add components to the dialog box. */
        add( illTitle );
        add( formTitle );
        add( itemInfo );
        add( tf_author = new InfoTextField( "Author (Last, First)", 32, boldFont ) );
        tf_author.setText( new String( request.author ) );
        add( tf_title = new InfoTextField( "Book Title", 32, boldFont ) );
        tf_title.setText( new String( request.title ) );
        add( tf_edition = new InfoTextField( "Edition", 15 ) );
        tf_edition.setText( request.edition == "" ? "ANY" : new String( request.edition ) );
        add( tf_volume = new InfoTextField( "Volume", 15 ) );
        tf_volume.setText( new String( request.volume ) );
        add( tf_publisher = new InfoTextField( "Publisher", 15 ) );
        tf_publisher.setText( new String( request.publisher ) );
        add( tf_pubyear = new InfoTextField( "Year Published", 15 ) );
        tf_pubyear.setText( new String( request.publication_date ) );
        add( verifiedLabel );
        add( cb_yesVerified );
        add( cb_noVerified );
        add( btn_holdings );
        add( nbdTitle );
        add( nbdLabel );
        add( tf_needbefore );
        add( btn_more );
        add( btn_ok );
        add( btn_cancel );

        /* Set the location and bounds of the dialog components. */
        illTitle.setBounds( 24, 24, 384, 27 );
        formTitle.setBounds( 24, 51, 384, 27 );

        itemInfo.setBounds( 24, 86, 75, 14 );
        tf_author.setBounds( 36, 102,
            ( tf_author.getSize( ) ).width,
            ( tf_author.getSize( ) ).height );
        tf_title.setBounds( 36, 146,
            ( tf_title.getSize( ) ).width,
            ( tf_title.getSize( ) ).height );
        tf_edition.setBounds( 36, 190,
            ( tf_edition.getSize( ) ).width,
            ( tf_edition.getSize( ) ).height );
        tf_volume.setBounds( 240, 190,
            ( tf_volume.getSize( ) ).width,
            ( tf_volume.getSize( ) ).height );
        tf_publisher.setBounds( 36, 234,
            ( tf_publisher.getSize( ) ).width,
            ( tf_publisher.getSize( ) ).height );
        tf_pubyear.setBounds( 240, 234,
            ( tf_pubyear.getSize( ) ).width,
            ( tf_pubyear.getSize( ) ).height );
        verifiedLabel.setBounds( 36, 278, 384, 14 );
        cb_yesVerified.setBounds( 36, 294, 50, 20 );
        cb_noVerified.setBounds( 86, 294, 50, 20 );
        btn_holdings.setBounds( 136, 294, 284, 20 );

        nbdTitle.setBounds( 24, 333, 79, 16 );
        nbdLabel.setBounds( 36, 351, 384, 16 );
        tf_needbefore.setBounds( 36, 369, 144, 20 );

        btn_more.setBounds( 18, 416, 64, 24 );
        btn_ok.setBounds( 298, 416, 64, 24 );
        btn_cancel.setBounds( 374, 416, 64, 24 );

        /* Display dialog box in the center of the screen. */
        int x = (int)( ( ( sys_metrics.getScreenSize( ) ).width - 456 ) / 2 );
        int y = (int)( ( ( sys_metrics.getScreenSize( ) ).height - 456 ) / 2 );
        setLocation( x, y );
        setVisible( true );
    }

    public void paint( Graphics g )
    {
        /* Draw 3D rectangle */
        g.draw3DRect( 18, 93, 420, 228, false );
        g.draw3DRect( 18, 340, 420, 60, false );
    }

    public void actionPerformed( ActionEvent event )
    {
        if ( event.getSource( ) == btn_ok ) {

            /* If there is data missing warn the user, */
            if ( tf_author.getText( ).equals( "" ) ||
                 tf_title.getText( ).equals( "" ) ||
                 tf_needbefore.getText( ).equals( "" ) ||
                 grp_verified.getSelectedCheckbox( ).getLabel( ).equals( "No" ) )
            {
                new ErrorMsgDlg( new Frame( ), "A required field is missing." );

            /* else get the information from the user. */
            } else {
                DateFormat df = DateFormat.getDateInstance( DateFormat.LONG );

                /* Get the date entered by the user. */
                try {
                    request.need_before_date = new String(
                        ILLDate.getFormattedDate( df.parse( tf_needbefore.getText( ) ) ) );

                /*
                 * If the user's date is not in the correct format,
                 * then provide them with the default date.
                 */
                } catch ( ParseException parse ) {
                    request.need_before_date = new String( DEFAULT_NEEDBEFORE_STRING );

                    /* 
                     * TODO: provide a dialog for the user to correct
                     *       a miss-entered date.
                     */
                }

                request.author = new String( tf_author.getText( ) );
                request.title = new String( tf_title.getText( ) );
                request.edition = new String( tf_edition.getText( ) );
                request.publisher = new String( tf_publisher.getText( ) );
                request.publication_date = new String( tf_pubyear.getText( ) );
                request.volume = new String( tf_volume.getText( ) );

                request.ill_service_type = BOOK_REQUEST;
                request.request_made = true;

                setVisible( false );
                dispose( );
            }
        }

        else if ( event.getSource( ) == btn_more ) {
            new MoreInfoDlg( new Frame( ), numRequests );
        }

        else if ( event.getSource( ) == btn_cancel ) {
            request.request_made = false;
            setVisible( false );
            dispose( );
        }

        else if ( event.getSource( ) == btn_holdings ) {
            try {
                /*
                 * Get the data file parameters.  This could also be done in
                 * the constructor but would slow the dialog box from coming
                 * up.  Netscape is dirt slow anywhere so what's another few
                 * seconds.
                 */
                readData( );

                /* Construct the argument and parameter and run application. */
                String args[] = { str_bookApp, str_bookParam };
                ( Runtime.getRuntime( ) ).exec( args );
            }
            catch ( Exception all ) {
                new ErrorMsgDlg( new Frame( ), "Could not access holdings" );
            }
        }

    }

    /*
    ** Methods
    */

    /*
    ** Gets information from the administration module data file.  This
    ** method uses sun.net.ftp.FtpClient which logically follows a standard 
    ** ftp session.
    */
    public void readData( )
    {
        try {
            /* establish connection */
            FtpClient client = new FtpClient( ADMIN_HOST );

            /* log into ftp server */
            client.login( ADMIN_USER_ID, ADMIN_PASSWORD );

            /* change to proper directory */
            client.cd( ADMIN_PATH );

            /* get the data file */
            client.get( ADMIN_FILE );

            /* disconnection from ftp server */
            client.sendServer( "quit" );

            /* get i/o stream to file and retrieve data. */
            File file = new File( ADMIN_FILE );
            DataInputStream input = new DataInputStream(
                new FileInputStream( file ) );
            str_bookApp = input.readUTF( );
            str_bookParam = input.readUTF( );
            input.close( );
            file.delete( );
        }

        catch ( IOException rd ) {
            /*
             * Do nothing.  If the file cannot be read then the default 
             * parameters are used.
             */
        }
    }
}