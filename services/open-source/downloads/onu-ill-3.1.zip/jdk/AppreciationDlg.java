/*  AppreciationDlg.java
**
**  by Bryan Wilhelm, Olivet Nazarene University
**  September 11, 1998
**
**  Displays the results of the request submission, 
**  before exiting ONU-ILL.
*/

import java.awt.*;
import java.awt.event.*;

public class AppreciationDlg extends Dialog implements ActionListener, ONU_ILL_CONST
{
    Button button;
    Label  message;
    Toolkit sys_metrics = Toolkit.getDefaultToolkit( );

    public AppreciationDlg( Frame parent, boolean flag )
    {
        super( parent, flag ? "Failed Request" : "Successful Request", true );

        setSize( 360, 100 );
        setResizable( false );
        setLayout( null );
        setFont( new Font( "Sans Serif", Font.PLAIN, 11 ) );

        Panel msgPanel = new Panel( );
        msgPanel.setLayout( new FlowLayout( FlowLayout.CENTER ) );
        msgPanel.setSize( 330, 25 );

        message = new Label( flag ? "Your request was not successful--contact " + LIBRARY_NAME + "." :
                             "Thank you for using " + LIBRARY_NAME + " Interlibrary Loan." );
        msgPanel.add( message);

        button = new Button( "OK" );
        button.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        button.addActionListener( this );

        add( msgPanel );
        add( button );

        msgPanel.setBounds( 15, 20, 330, 25 );
        button.setBounds( 148, 60, 64, 24 );

        int x = (int) ( ( sys_metrics.getScreenSize( ).width - 300 ) / 2.0 );
        int y = (int) ( ( sys_metrics.getScreenSize( ).height - 150 ) / 2.0 );
        setLocation( x, y );
        setVisible( true );
    }

    public void actionPerformed( ActionEvent event )
    {
        setVisible( false );
        dispose( );
    }
}