/*  PatronInfoDlg.java
**
**  by Bryan Wilhelm, Olivet Nazarene University
**  September 11, 1998
**
**  The PatronInfoDlg is the first visible window of the application.  It
**  gets the necessary information about the patron in order to complete
**  the request.  The information provided in this dialog is used for all
**  requests in this application session.  The information is stored in the
**  PatronInfo class.
*/


import java.awt.*;
import java.awt.event.*;


public class PatronInfoDlg extends Dialog implements ActionListener, ONU_ILL_CONST
{
    /*
    ** Attributes
    */
    private Checkbox       cb_faculty, 
                           cb_staff, 
                           cb_undergrad, 
                           cb_grad, 
                           cb_other;
    private CheckboxGroup  grp_status;      // PSTATUS
    private InfoTextField  tf_name,         // PATRON
                           tf_po_box,       // PATRON_ADDR
                           tf_address,      // PATRON_ADDR
                           tf_city,         // PATRON_ADDR
                           tf_state,        // PATRON_ADDR
                           tf_zip,          // PATRON_ADDR
                           tf_id,           // PATRON_ID
                           tf_email,        // PATRON_EMAIL
                           tf_phone,        // PATRON_PHONE
                           tf_fax;          // PATRON_FAX
    private Button         btn_ok, 
                           btn_cancel;

    PatronInfo patron_info;

    private Toolkit sys_metrics = Toolkit.getDefaultToolkit( );
    private Font boldFont = new Font( "Sans Serif", Font.BOLD, 11 );


    /*
    ** Constructor
    */
    public PatronInfoDlg( Frame parent, PatronInfo info )
    {
        /* Call dialog superclass constructor. */
        super( parent, INSTITUTION_NAME + " Interlibrary Loan", true );
        patron_info = info;

        /* Set window size, layout, and listener. */
        setSize( 456, 456 );
        setResizable( false );
        setLayout( null );
        setFont( new Font( "Sans Serif", Font.PLAIN, 11 ) );
        addWindowListener( new CloseWindow( ) );
        
        /* Add dialog box components. */
        Label onu = new Label( INSTITUTION_NAME );
        onu.setFont( new Font( "Serif", Font.BOLD + Font.ITALIC, 28 ) );

        Label ill = new Label( "Interlibrary Loan" );
        ill.setFont( new Font( "Serif", Font.BOLD + Font.ITALIC, 24 ) );

        Label dir1 = new Label( "DIRECTIONS: Enter the information in the " +
            "fields below and press OK." );
        Label dir2 = new Label( "Press Cancel to exit the program." );

        Label note = new Label( "NOTE:  " );
        Label bold = new Label( "BOLD" );
        bold.setFont( boldFont );
        Label endnote = new Label( " denotes a required field." );

        Label pinfo = new Label( "Patron Information" );

        grp_status = new CheckboxGroup( );
        Panel pnl_status = new Panel( );
        pnl_status.setLayout( new FlowLayout( FlowLayout.LEFT ) );
        pnl_status.add( cb_faculty = new Checkbox( "Faculty", grp_status, false ) );
        pnl_status.add( cb_staff = new Checkbox( "Staff", grp_status, false ) );
        pnl_status.add( cb_undergrad = new Checkbox( "Undergrad", grp_status, true ) );
        pnl_status.add( cb_grad = new Checkbox( "Grad", grp_status, false ) );
        pnl_status.add( cb_other = new Checkbox( "Other", grp_status, false ) );

        /* Add components to the dialog box. */
        add( onu );
        add( ill );
        add( dir1 );
        add( dir2 );
        add( note );
        add( bold );
        add( endnote );
        add( pinfo );
        add( pnl_status );
        add( tf_name = new InfoTextField( "Your Name", 32, boldFont ) );
        add( tf_po_box = new InfoTextField( "Box No.      OR", 16, boldFont ) );
        add( tf_address = new InfoTextField( "Street Address", 16, boldFont ) );
        add( tf_city = new InfoTextField( "City", 15 ) );
        add( tf_state = new InfoTextField( "State", 2 ) );
        add( tf_zip = new InfoTextField( "Zip Code", 5 ) );
        add( tf_id = new InfoTextField( "Your Student ID or SSN", 15 ) );
        add( tf_email = new InfoTextField( "Your E-mail Address", 15, boldFont ) );
        add( tf_phone = new InfoTextField( "Your Phone Number", 15 ) );
        add( tf_fax = new InfoTextField( "Your Fax Number", 15 ) );

        btn_ok = new Button( "OK" );
        btn_ok.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        btn_ok.addActionListener( this );
        btn_cancel = new Button( "Cancel" );
        btn_cancel.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        btn_cancel.addActionListener( this );
        add( btn_ok );
        add( btn_cancel );

        /* Set the location and bounds of the dialog components. */
        onu.setBounds( 128, 24, 310, 40 );
        ill.setBounds( 260, 52, 200, 40 );
        dir1.setBounds( 24, 108, 408, 12 );
        dir2.setBounds( 24, 120, 408, 12 );
        note.setBounds( 24, 132, 36, 12 );
        bold.setBounds( 60, 132, 32, 12 );
        endnote.setBounds( 92, 132, 128, 12 );
        pinfo.setBounds( 36, 153, 92, 12 );

        pnl_status.setBounds( 36, 164, 384, 24 );

        tf_name.setBounds( 36, 190,
            ( tf_name.getSize( ) ).width,
            ( tf_name.getSize( ) ).height );
        tf_po_box.setBounds( 36, 231, 84, 
            ( tf_po_box.getSize( ) ).height );
        tf_address.setBounds( 128, 231, 292,
            ( tf_address.getSize( ) ).height );
        tf_city.setBounds( 36, 272, 232,
            ( tf_city.getSize( ) ).height );
        tf_state.setBounds( 280, 272, 36,
            ( tf_state.getSize( ) ).height );
        tf_zip.setBounds( 324, 272, 96,
            ( tf_zip.getSize( ) ).height );
        tf_id.setBounds( 36, 313,
            ( tf_id.getSize( ) ).width,
            ( tf_id.getSize( ) ).height );
        tf_email.setBounds( 240, 313,
            ( tf_email.getSize( ) ).width,
            ( tf_email.getSize( ) ).height );
        tf_phone.setBounds( 36, 354,
            ( tf_phone.getSize( ) ).width,
            ( tf_phone.getSize( ) ).height );
        tf_fax.setBounds( 240, 354,
            ( tf_fax.getSize( ) ).width,
            ( tf_fax.getSize( ) ).height );

        btn_ok.setBounds( 298, 414, 64, 24 );
        btn_cancel.setBounds( 374, 414, 64, 24 );

        /* Display dialog box. */
        int x = (int)( ( ( sys_metrics.getScreenSize( ) ).width - 456 ) / 2 );
        int y = (int)( ( ( sys_metrics.getScreenSize( ) ).height - 456 ) / 2 );
        setLocation( x, y );
        setVisible( true );

    }

    public void paint( Graphics g )
    {
        /* Draw the ONU seal image */
        Image seal = sys_metrics.getImage( LOGO );
        g.drawImage( seal, 18, 24, this );

        /* Draw 3D rectangle */
        g.draw3DRect( 18, 158, 420, 248, false );

    }

    public void actionPerformed( ActionEvent event )
    {
        if ( event.getSource( ) == btn_cancel ) {

            /* Remove dialog box and exit program. */
            setVisible( false );
            System.exit( 0 );

        } else {

            /* Check request fields, if any are missing then warn user. */
            if ( tf_name.getText( ).equals( "" ) ||
                 tf_email.getText( ).equals( "" ) ||
                 ( tf_po_box.getText( ).equals( "" ) &&
                   tf_address.getText( ).equals( "" ) ) )
            {
                new ErrorMsgDlg( new Frame( ), "A required field is missing." );

            /* If none are missing then continue program. */
            } else {

                /* Put patron information into request records */
                for ( int i = 0; i < 10; i++ ) {
                    patron_info.patron_status = grp_status.getSelectedCheckbox( ).getLabel( );
                    patron_info.patron_full_name = tf_name.getText( );
                    patron_info.p_home_po_box = tf_po_box.getText( );
                    patron_info.p_home_street_no = tf_address.getText( );
                    patron_info.p_home_city = tf_city.getText( );
                    patron_info.p_home_region = tf_state.getText( );
                    patron_info.p_home_postal_code = tf_zip.getText( );
                    patron_info.patron_id = tf_id.getText( );
                    patron_info.patron_email = tf_email.getText( );
                    patron_info.patron_phone = tf_phone.getText( );
                    patron_info.patron_fax = tf_fax.getText( );

                }

                /* Remove dialog box. */
                setVisible( false );
                dispose( );

            }

        }

    }

}