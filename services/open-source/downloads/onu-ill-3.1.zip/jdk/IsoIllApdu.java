/* IsoIllApdu.java
** 
** Bryan Wilhelm, Olivet Nazarene University
** September 11, 1998
**
** Contains the data from the ISO 10161 ILL response,
** and processes it into a useful format.
*/


public class IsoIllApdu implements ILL_API, ILL_ASN
{
    public short type;

    public IsoStatusOrErrorReport report;
    public IsoIllAnswer           answer;

    public IsoIllApdu( BerString buf )
    {
        DataDir dir = new DataDir( buf );

        type = (short) dir.fldid();

        if ( type == STATUS_OR_ERROR_REPORT_APDU ) {
            report = new IsoStatusOrErrorReport( dir );
            answer = null;
        }
        else if ( type == ILL_ANSWER_APDU ) {
            if ( dir == null ) System.out.println( "APDU DataDir equals NULL" );
            else {
            answer = new IsoIllAnswer( dir );
            report = null;
            }
        }
    }
}


// (c)1998 Olivet Nazarene University, 240 East Marsile,
// Bourbonnais, IL 60914-0592.
//
// NOTICE TO USERS:  ONU-ILL ("Software") has been developed by
// Olivet Nazarene University.  Subject to the terms and conditions set
// forth below, Olivet grants to user a perpetual, non-exclusive, royalty-free
// license to use, reproduce, alter, modify, and create derivative works from
// Software, and to sublicense Software subject to the following terms and
// conditions:
//
// SOFTWARE IS PROVIDED AS IS.  OLIVET MAKES NO WARRANTIES, REPRESENTATIONS, OR
// GUARANTEES WHETHER EXPRESS OR IMPLIED REGARDING SOFTWARE, ITS FITNESS FOR ANY
// PARTICULAR PURPOSE, OR THE ACCURACY OF THE INFORMATION CONTAINED THEREIN.
//
// User agrees that Olivet shall have no liability to user arising therefrom,
// regardless of the basis of the action, including liability for special,
// consequential, exemplary, or incidental damages, including lost profits,
// even if it has been advised of the possibility thereof.
//
// User shall cause the copyright notice of Olivet to appear on all copies of
// Software, including derivative works made therefrom.


// (c)1996 OCLC Online Computer Library Center, Inc., 6565 Frantz Road, Dublin,
// Ohio 43017-0702.  OCLC is a registered trademark of OCLC Online Computer
// Library Center, Inc.
//
// NOTICE TO USERS:  The BER Utilities ("Software") has been developed by OCLC
// Online Computer Library Center, Inc.  Subject to the terms and conditions set
// forth below, OCLC grants to user a perpetual, non-exclusive, royalty-free
// license to use, reproduce, alter, modify, and create derivative works from
// Software, and to sublicense Software subject to the following terms and
// conditions:
//
// SOFTWARE IS PROVIDED AS IS.  OCLC MAKES NO WARRANTIES, REPRESENTATIONS, OR
// GUARANTEES WHETHER EXPRESS OR IMPLIED REGARDING SOFTWARE, ITS FITNESS FOR ANY
// PARTICULAR PURPOSE, OR THE ACCURACY OF THE INFORMATION CONTAINED THEREIN.
//
// User agrees that OCLC shall have no liability to user arising therefrom,
// regardless of the basis of the action, including liability for special,
// consequential, exemplary, or incidental damages, including lost profits,
// even if it has been advised of the possibility thereof.
//
// User shall cause the copyright notice of OCLC to appear on all copies of
// Software, including derivative works made therefrom.