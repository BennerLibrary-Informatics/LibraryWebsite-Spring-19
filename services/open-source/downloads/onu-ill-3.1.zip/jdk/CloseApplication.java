/*  CloseApplication.java
**  
**  Bryan Wilhelm, Olivet Nazarene University
**  September 11, 1998
**  
**  Closes an application and returns to the operating system.
*/

import java.awt.event.*;

class CloseApplication extends WindowAdapter
{
    public void windowClosing( WindowEvent e )
    { System.exit( 0 ); }
}

