/*  ONU_ILL_CONST.java
**
**  by Bryan Wilhelm, Olivet Nazarene University
**  September 11, 1998
**
**  Contains data specifically for the ONU-ILL application 
**  and to Benner Library
*/

import java.util.*;

public interface ONU_ILL_CONST {

    // CONSTANTS
    public static final int
        DEFAULT_NEEDBEFORE_DAYS = 25,   // default of 25 days
        MAX_REQUESTS            = 10,

        OCLC_PORT               = 5771;

    public static final Date  // DO NOT MODIFY THESE
        TODAY                   = new Date(),
        DEFAULT_NEEDBEFORE_DATE = new Date( System.currentTimeMillis() + 
                                  (long)(DEFAULT_NEEDBEFORE_DAYS * 8.64e7) );

    public static final String
        BLANK            = new String( "" ),
        LIB_SYMBOL       = new String( "XXX" ),
        AUTHORIZATION    = new String( "NNN-NNN-NNN" ),  // PRISM AUTHORIZATION
        PASSWORD         = new String( "PASSWORD" ),          // PRISM PASSWORD
        INSTITUTION_NAME = new String( "YOUR INSTITUTION NAME" ),
        LIBRARY_NAME     = new String( "YOUR LIBRARY NAME" ),
        LOGO             = new String( "YOUR LOGO.gif" ),

        DEL_NAME         = new String( "" ),
        DEL_EXT          = new String( "" ),
        DEL_STREET       = new String( "" ),
        DEL_PO_BOX       = new String( "" ),
        DEL_CITY         = new String( "" ),
        DEL_STATE        = new String( "" ),
        DEL_COUNTRY      = new String( "" ),
        DEL_ZIP_CODE     = new String( "" ),

        DEL_FAX          = new String( "" ),
        DEL_EMAIL        = new String( "" ),

        SHIP_VIA_SERVICE = new String( "" ),
        ELECTRONIC_SERVICE = new String( "" ),

        MAX_COST         = new String( "$0" ),

        BOOK_DATA        = new String( "We lend books free nationwide." ),
        PER_DATA         = new String( "We lend 30 pages free nationwide." ),

        COPYRIGHT        = new String( "" ),  // CCL or CCG

        OCLC_SERVER      = new String( "testenv.oclc.org" ),

        DEFAULT_NEEDBEFORE_STRING = 
                     new String( ILLDate.getFormattedDate( DEFAULT_NEEDBEFORE_DATE ) );

    public static final short
        BOOK_REQUEST = 1,
        PERIODICAL_REQUEST = 2;


    
    // ILLAdmin

    // You may decide not to use this feature
    // This assumes that you want to store the
    // administrative data on an FTP server.  If
    // this is not the case, remove all administrative
    // methods in
    //      BookRequestDlg
    //      PeriodicalRequestDlg
    //      ONU_ILL
    //      RequestFinalizerDlg
    // including the btn_holdings variable.
    public static final String
        ADMIN_HOST = new String( "" ),
        ADMIN_USER_ID = new String( "" ),
        ADMIN_PASSWORD = new String( "" ),
        ADMIN_PATH = new String( "." ),
        ADMIN_FILE = new String( "" ),
        DEFAULT_BOOK_APP = new String( "" ),
        DEFAULT_BOOK_PARAM = new String( "" ),
        DEFAULT_PER_APP = new String( "" ),
        DEFAULT_PER_PARAM = new String( "" );

}


