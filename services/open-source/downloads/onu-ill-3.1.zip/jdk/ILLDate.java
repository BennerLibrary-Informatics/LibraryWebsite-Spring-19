/* ILLDate.java
**
** Bryan Wilhelm, Olivet Nazarene University
** September 11, 1998
**
** Converts a date object into a String in the correct format
** for ILL request to OCLC
*/

import java.util.*;

public class ILLDate {

    public static String getFormattedDate( Date d )
    {
        Calendar c = Calendar.getInstance();
        c.setTime( d );

        int year = c.get( Calendar.YEAR );
        int month = c.get( Calendar.MONTH ) + 1;
        int day = c.get( Calendar.DAY_OF_MONTH );

        String s = new String( "" + year +
            ( month < 10 ? "0" : "" ) + month +
            ( day < 10 ? "0" : "" ) + day );

        return new String( s );
    }

}

