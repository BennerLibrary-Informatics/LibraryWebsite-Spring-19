/*
(c)1996 OCLC Online Computer Library Center, Inc., 6565 Frantz Road, Dublin,
Ohio 43017-0702.  OCLC is a registered trademark of OCLC Online Computer
Library Center, Inc.
 
NOTICE TO USERS:  The BER Utilities ("Software") has been developed by OCLC
Online Computer Library Center, Inc.  Subject to the terms and conditions set
forth below, OCLC grants to user a perpetual, non-exclusive, royalty-free
license to use, reproduce, alter, modify, and create derivative works from
Software, and to sublicense Software subject to the following terms and
conditions:
 
SOFTWARE IS PROVIDED AS IS.  OCLC MAKES NO WARRANTIES, REPRESENTATIONS, OR
GUARANTEES WHETHER EXPRESS OR IMPLIED REGARDING SOFTWARE, ITS FITNESS FOR ANY
PARTICULAR PURPOSE, OR THE ACCURACY OF THE INFORMATION CONTAINED THEREIN.
 
User agrees that OCLC shall have no liability to user arising therefrom,
regardless of the basis of the action, including liability for special,
consequential, exemplary, or incidental damages, including lost profits,
even if it has been advised of the possibility thereof.
 
User shall cause the copyright notice of OCLC to appear on all copies of
Software, including derivative works made therefrom.
*/


/** DataDir is a class for manipulating tree structures and for putting data
 * into and getting data out of tree structures. <p>Example: Create a DBI Begin 
 * Session request and get the session id from the response. This example 
 * assumes methods to send requests and get responses from a DBI Server.</p>
<pre>
BerString ber_record;
DataDir dir, subdir;
int sessid;
//
dir = new DataDir(DBI.DBI_IN, ASN1.APPLICATION); // create DataDir
subdir = dir.daddTag(DBI.BEGINS, ASN1.CONTEXT);  // make it a Begin Session
subdir.daddChar(DBI.BS_USERID, ASN1.CONTEXT, "ralph"); // add userid
ber_record = new BerString(dir);	         // make BER record
//
send_request(ber_record);
ber_record = get_response();
//
dir = new DataDir(ber_record);
subdir = dir.child();		// skip over DBI_OUT node
subdir = subdir.child();	// skip over BEGINS node
while (subdir != null)		// find node with tag==SESSID
{
    if (subdir.fldid() == DBI.SESSID)
    {
        sessid = subdir.dgetNum();
        break;
    }
    subdir = subdir.next();	// point to sibling of this node
}
</pre>
 * @see ASN1
 * @version %W% %G%
 * @author Jenny Colvard
 */

public class DataDir extends ASN1 {

 	protected DataDir child;  // first (or left-most) child
	protected DataDir last_child;  // last (or right-most) child
	protected DataDir parent;
	protected DataDir next;
	protected DataDir prev;

	protected DataDirObject object;
	protected byte dataSource[];
        protected int dataOffset;
	protected int number;

	protected int fldid;
	protected byte asn1class;
	protected byte form;
	protected int length;
	protected int count;

	private static final byte mask[] = {(byte)0x80, (byte)0x40, (byte)0x20, 
				    (byte)0x10, (byte)0x08, (byte)0x04, 
				    (byte)0x02, (byte)0x01};

/**
* Accessor method for child of this DataDir.
*/
	public final DataDir child() { return child; }
/**
* Accessor method for parent of this DataDir.
*/
	public final DataDir parent() { return parent; }
/**
* Accessor method for next sibling of this DataDir.
*/
	public final DataDir next() { return next; }
/**
* Accessor method for previous sibling of this DataDir.
*/
 	public final DataDir prev() { return prev; }
/**
* Accessor method for DataDirObject for this DataDir.
*/
	public final DataDirObject object() { return object; }
/**
* Accessor method for data for this DataDir.
*/
	public final void data(byte dest[], int offset, int length) {
	    System.arraycopy(dataSource, dataOffset, dest, offset, 
		Math.min(length, count));
	}

	public final byte[] data() {
	  if (dataSource == null || count == 0)
	      return null;

	  byte [] data = new byte[count];
	  System.arraycopy(dataSource, dataOffset, data, 0, count);
	  return data;
	}
/**
* Accessor method for fldid for this DataDir.
*/
	public final int fldid() { return fldid; }
/**
* Accessor method for asn1class for this DataDir.
*/
	public final byte asn1class() { return asn1class; }
/**
* Accessor method for form for this DataDir.
*/
	public final byte form() { return form; }
/**
* Accessor method for count for this DataDir. If the DataDir is PRIMITIVE,
* then the count is the length of the data, object or number. If the
* DataDir is CONSTRUCTED, then the count is the number of children
* belonging to this DataDir.
*/
	public final int count() { return count; }

/**
* Produce a formatted hex dump of a directory.
* @return String 
*/
	public final String toString() {
	    return toString("\n");
	}

	private final String toString(String line_prefix) {
	    StringBuffer str = new StringBuffer("DataDir: fldid(" + fldid +
				") asn1class(" + asn1class +
				") form(" + form +
				") length(" + length +
				") count(" + count + ")");
	    if (form == CONSTRUCTED && child != null)
		str.append(line_prefix + "  child: " + child.toString(line_prefix + "  "));
	    else // form == PRIMITIVE
	    {
	        StringBuffer alpha = new StringBuffer();
		byte data[] = data();
		str.append(line_prefix + "    data: ");
                for (int i=0; data != null && i<count; i++)
                {
                    if ((data[i]&0xff)<16)
                        str.append(" 0");
                    else
                        str.append(" ");
                    str.append(Integer.toString(data[i]&0xff,16));
    
	     	    alpha.append(String.valueOf((char)(data[i])));
                    if (((i+1)%16)==0)
		    {
                        str.append("  " + alpha + line_prefix + "          ");
		        alpha.setLength(0);
		    }
                }
		if (data == null)
		{
		    if (object != null)
			str.append(object.toString());
		    else
			str.append(Integer.toString(number));
		}
		str.append("  " + alpha);
	    }
  	    if (next != null)
		str.append(line_prefix + "sibling: " + next.toString(line_prefix));
	    return str.toString();
	}

/**
* Create a DataDir node with the specified fldid and asn1class.
* @param fldid tag to be assigned to new node
* @param asn1class class to be assigned to new node
*/
	public DataDir(int fldid, byte asn1class) {
	    this.fldid = fldid;
	    this.asn1class = asn1class;
	    form = CONSTRUCTED;
	}

/**
* Add a non-leaf node to a directory.
* @param fldid tag to be assigned to new node
* @param asn1class class to be assigned to new node
*/
	public DataDir daddTag(int fldid, byte asn1class) {
            return new DataDir(this, fldid, asn1class);
        }

/**
* Insert a new tag before an existing dir and all its siblings.
* @param fldid tag to be assigned to new node
* @param asn1class class to be assigned to new node
*/
	public DataDir dinsTag(int fldid, byte asn1class) {
	    DataDir dir, newDir;

	    newDir = new DataDir(fldid, asn1class);
	    if (parent != null)
	    {
		newDir.child = parent.child;
		parent.child = newDir;
		parent.count = 1;
	    }
	    else
		newDir.child = this;
	    newDir.parent = parent;

	    for (newDir.count=0, dir = newDir.child; dir != null; 
		 newDir.count++, dir = dir.next)
		dir.parent = newDir;

	    return newDir;
	}

/**
* Create a non-leaf node that will be a child of the specified parent.
* @param fldid tag to be assigned to new node
* @param asn1class class to be assigned to new node
*/
	public DataDir(DataDir parent_dir, int fldid, byte asn1class) {
	    // cannot return null from constructor. figure out how
	    // to do this!!!!
	    // if (parent.form == PRIMITIVE)
		// return null;

            this.fldid = fldid;
            this.asn1class = asn1class;
            form = CONSTRUCTED;

	    parent = parent_dir;
	    if (parent_dir!=null){
	        parent_dir.count++;
	        if (parent_dir.child == null)
	            parent_dir.child = parent_dir.last_child = this;
	        else
	        {
		    this.prev = parent_dir.last_child;
		    parent_dir.last_child.next = this;
		    parent_dir.last_child = this;
	        }
	    }
	}

 	private void bldNode(BerString record, int fieldlen[], int taglen[]) {
	    byte asn1class;
	    int b, fldid, size;
	    int lenlen;

	    b = record.record[record.offset];
	    asn1class = (byte)((b&0xff) >> 6);

            int oldoffset = record.offset;
	    int tfldlen;

	    fldid = record.getTag(taglen);
            lenlen = record.getLen(fieldlen);

	    tfldlen = fieldlen[0];
            if (tfldlen == -1) {
              if (record.IsCompleteBER(oldoffset, 0x7fffffff, fieldlen)) {
                fieldlen[0] -= (taglen[0]+lenlen+2);
                // -= 2;  // don't include trailing nulls in loop later
              }
	      tfldlen = fieldlen[0];  // re-set local copy
            } 

            if (record.offset+tfldlen > record.record.length) {
                 record.offset += tfldlen;
                 return;
            }

	    if ((b & 0x20) == 0) // PRIMITIVE
	    {
	  	// make copy of data
		// or store offset and count in DataDir.
                if (tfldlen >= 0)
  	          daddChar(fldid, asn1class, record.record, 
                           record.offset,tfldlen);
		record.offset += tfldlen;
	    }
	    else if (tfldlen > 0) 
	    {
		DataDir newdir = new DataDir(this, fldid, asn1class);
		size = record.offset + tfldlen;
	  	while (record.offset < size)
	 	{
		    newdir.bldNode(record, fieldlen, taglen);
		}
	    }
	}



/**
* Builds a DataDir tree structure for a BER record.
* @param record BER record
*/
	public DataDir(BerString record) {
	    int lenlen = 0;
	    int nodesize = 0, size = 0;

	    record.offset = 0;

	    if ((byte)(record.record[record.offset]&0x20) == 0x20)
		form = CONSTRUCTED;
	    else
	        form = PRIMITIVE; 

            int fieldlen[] = new int[1];
            int taglen[] = new int[1];
	    int tfldlen;

            asn1class = (byte)((record.record[record.offset]&0xff) >> 6);
            fldid = record.getTag(taglen);

            lenlen = record.getLen(fieldlen);

            if (fieldlen[0] == -1) {
              if (record.IsCompleteBER( 0x7fffffff, fieldlen)) {
                fieldlen[0] -= (taglen[0]+lenlen+2);
                // -= 2;  // don't include trailing nulls in loop later
              }
            }


	    tfldlen = fieldlen[0];
	    if (form == PRIMITIVE){
	        dataSource = record.record;
		dataOffset = record.offset;
		count = tfldlen;
                record.offset += tfldlen;
		return;
	    }

	    size = record.offset + tfldlen;
	    while (record.offset < size) {
		// bldNode does not need this fieldLen or tagLen
		// but it was allocating lots more of them and this
		// save alots of 'new's!
		bldNode(record, fieldlen, taglen);
            }

	}

/**
* Assembles a BER record from a DataDir into a BerString object.
* NOTE: recLen() must be called immediately before calling asmRec().
* recLen() sets information in the DataDir that is critical for the
* function of asmRec(). recLen() also returns the length needed to
* construct the BerString object.
* @param record object to hold BER record
*/
 	public final void asmRec(BerString record) {
 	    DataDir pchild;

 	    record.putTag(fldid, asn1class, form);
 	    record.putLen(length);
 	    if (form == CONSTRUCTED)
 		for (pchild = child; pchild != null; pchild = pchild.next)
 		{
 		    pchild.asmRec(record);
 		}
 	    else
 	    {
 		if (dataSource == null)
 		    if (object == null)
 		        record.putNumber(number);
 		    else
 		        record.putChar(object.toByteArray(), object.length());
 		else
 		    record.putChar(dataSource, dataOffset, count);
 	    }
 	}

/**
* Re-initialize the root node of a directory.
* @param fldid tag to be assigned to new node
* @param asn1class class to be assigned to new node
* @return root node
*/
	DataDir dinit(int fldid, byte asn1class) { 
	    parent = child = next = prev = null;
	    dataSource = null;
	    number = 0;
	    this.fldid = fldid;
	    this.asn1class = asn1class;
	    form = 0;
	    length = count = 0;
	    return this;
	}

/**
* Remove the reference to any data and create a reference to the specified
* DataDirObject. This is useful when the DataDir was constructed from a
* BerString. The caller can create an object from the byte array in the
* original DataDir and then replace the byte array with a reference to the
* desired object.
* @param obj object reference to added to DataDir
*/
        public void daddObj(DataDirObject obj) {
            object = obj;
            count = obj.length();
            dataSource = null;
            number = 0;
        }

/**
* Add a leaf node to the directory with DataDirObject data.
* @param fldid tag to be assigned to new node
* @param asn1class class to be assigned to new node
* @param obj object reference 
*/
        public DataDir daddObj(int fldid, byte asn1class, DataDirObject obj) {
            // Objects passed to this must have a toByteArray and
            // length method.
  
            DataDir newdir = new DataDir(this, fldid, asn1class);
            newdir.form = PRIMITIVE;
            newdir.object = obj;
            newdir.count = obj.length();
            return newdir;
        }

/**
* Add a leaf node to the directory with String data. The data will be 
* converted to a byte array.
* @param fldid tag to be assigned to new node
* @param asn1class class to be assigned to new node
* @param input_data String reference 
*/
 	public final DataDir daddChar(int fldid, byte asn1class, 
                                String input_data) {
	    byte data[] = input_data.getBytes();
	    return daddChar(fldid, asn1class, data);
	}
/**
 * Replace the data contents with a new String
 * @param input_data String reference
 */
	public final void drepChar(String input_data) {
	    dataSource = input_data.getBytes();
	    count = dataSource.length;
	    dataOffset = 0;
	}

/**
* Add a leaf node to the directory with byte[] data.
* @param fldid tag to be assigned to new node
* @param asn1class class to be assigned to new node
* @param byte[] dataSource
*/
	public final DataDir daddChar(int fldid, byte asn1class, 
				byte dataSource[]) {
	  return daddChar(fldid, asn1class, dataSource, 0, dataSource.length);
	}
/**
* Add a leaf node to the directory with byte[] data.
* @param fldid tag to be assigned to new node
* @param asn1class class to be assigned to new node
* @param byte[] dataSource
* @param int dataOffset
* @param int dataLength
*/
	public final DataDir daddChar(int fldid, byte asn1class, 
				byte dataSource[], int dataOffset,
                                int dataLength) {
	    DataDir newdir = new DataDir(this, fldid, asn1class);
	    newdir.form = PRIMITIVE;
	    newdir.dataSource = dataSource;
	    newdir.dataOffset = dataOffset;
	    newdir.count = dataLength;
	    return newdir;
	}

/**
* Add a leaf node to the directory with INTEGER data.
* @param fldid tag to be assigned to new node
* @param asn1class class to be assigned to new node
* @param num INTEGER
*/
	public final DataDir daddNum(int fldid, byte asn1class, int num) {
	    DataDir newdir = new DataDir(this, fldid, asn1class);

	    newdir.form = PRIMITIVE;
	    newdir.dataSource = null;
	    object = null; newdir.number = num; 
	    newdir.count = numLen(num);
	    return newdir;
	}

/**
* Replace the data contents with an INTEGER value.
* @param num INTEGER
*/
	public final DataDir dreplaceNum(int num) {
	    if (form != PRIMITIVE)
		return null;

	    dataSource = null; object = null;
	    number = num;
	    count = numLen(num);
	    return this;
	}

/**
* Add a leaf node which contains a BITSTRING to a directory.
* NOTE: Any of the characters '1', 'y', 'Y', 't' or 'T' get a 1 in the
* encoded bitstring. Any other characters get a 0.
* @param fldid tag to be assigned to new node
* @param asn1class class to be assigned to new node
* @param bits String containing array of bits.
*/
	public final DataDir daddBits(int fldid, byte asn1class, String bits) {
	    int len = bits.length();
	    byte bytes[] = new byte[1 + len/8 + ((len%8)>0?1:0)];
	    int offset = 0;
	    byte unused = 0;

	    unused = (byte)(8-len%8);
	    if (unused == 8)
		unused = 0;

	    bytes[offset++]=unused;
	    for (int i=0; i<len; i+=8, offset++)
	    {
		bytes[offset] = 0;
		for (int j=0; j<8 && i+j<len; j++)
		    if (bits.charAt(i+j)=='y' || bits.charAt(i+j)=='Y' ||
			bits.charAt(i+j)=='t' || bits.charAt(i+j)=='T' ||
			bits.charAt(i+j)=='1')
			bytes[offset] |= mask[j];
	    }
	    return daddChar(fldid, asn1class, bytes);
	}

/**
* Add a leaf node to a directory which contains an OID.
* @param fldid tag to be assigned to new node
* @param asn1class class to be assigned to new node
* @param cstring String containing human readable OID
*/
	public final DataDir daddoid(int fldid, byte asn1class, String cstring) 
	{
	    int  cstring_offset = 0, dot = 0, offset = 0, value = 0;
	    byte place[] = new byte[100], ptr[] = null;

	    while (cstring_offset < cstring.length() && 
		   Character.isDigit(cstring.charAt(cstring_offset)) == true)
	    {
		if (offset > 90) // too large
		    return null;

		dot = cstring.indexOf('.', cstring_offset);
		dot = dot == -1 ? cstring.length() : dot;
		value = Integer.parseInt(cstring.substring(cstring_offset, 
			dot));

		if (offset==0) // 1st two are special
		{
		    if (dot == -1)
			return null; // can't be this short
		    cstring_offset = dot+1; // skip past '.'

		    dot = cstring.indexOf('.', cstring_offset);
		    dot = dot == -1 ? cstring.length() : dot;
		    value = value * 40 + 
		      Integer.parseInt(cstring.substring(cstring_offset,dot));
		}

		if (value >= 0x80)
		{
		    int count = 0;
		    byte bits[] = new byte[12]; // save a 84 (12*7) bit number

		    while (value != 0)
		    {
			bits[count++] = (byte)(value & 0x7f);
			value >>= 7;
		    }
		    // Now place in the correct order
		    while (--count > 0)
			place[offset++] = (byte)(bits[count] | 0x80);

		    place[offset++] = bits[count];
		}
		else
		    place[offset++] = (byte)value;

		dot = cstring.indexOf('.', cstring_offset);
		if (dot != -1)
		    cstring_offset = dot+1;
		else
		    cstring_offset = cstring.length();
	    }

	    ptr = new byte[offset];
	    System.arraycopy(place,0,ptr,0,offset);
	    return daddChar(fldid, asn1class, ptr);
	}

/**
* Returns the length of the BER record that would be created from the
* directory.
* @return length of record that would be created by asmRec().
*/
	public final int recLen() {
	    DataDir pchild;

	    length = 0;
	    if (form == CONSTRUCTED)
		for (pchild = child; pchild != null; pchild = pchild.next)
		    length += pchild.recLen();
	    else
		length = count;

	    return length + tagLen(fldid) + lenLen(length);
	}

/**
* Get a String from a leaf node.
* @return String
*/
	public final String dgetChar() {
	    return new String(dataSource, dataOffset, count);
	}

/**
* Get an INTEGER from a leaf node.
* @return value of INTEGER data. Undefined if not a leaf node or if leaf
* node doesn't contain INTEGER data.
*/
	public final int dgetNum() {
            if (dataSource != null)
              return getNum(dataSource, dataOffset, count);
	    return number;
	}

/**
* Get a human readable OID from a leaf node.
* @return A String with human readable OID
*/
	public final String dgetoid() {
	    int offset = 0, value;
	    StringBuffer oid = new StringBuffer();
	    while (offset < count) {
		value = 0;
		do {
		    value <<= 7;
		    value |= dataSource[dataOffset+offset] & 0x7f;
		} while ((dataSource[dataOffset+offset++] & 0x80) != 0);

		if (oid.length() == 0)
		    oid = oid.append(Integer.toString(value/40) + "." + 
			       Integer.toString(value%40));
		else
		    oid = oid.append("." + Integer.toString(value));
	    }
	    return oid.toString();
	}

/**
* Get a BITSTRING from a leaf node.
* @return A String with 'y' for 1 bits and 'n' for 0 bits.
*/
	public final String dgetBits() {
	    StringBuffer bits = new StringBuffer();
	    int i = 0, j = 0;
	    int last_used = 8 - (dataSource[dataOffset+0] & 0xff);
	
	    for (i=1; i<count-1; i++)
		for (j=0; j<8; j++)
		    bits.append((dataSource[dataOffset+i] & mask[j])!=0?"y":"n");
	    for (j=0; j<last_used; j++)
		bits.append((dataSource[dataOffset+i] & mask[j])!=0?"y":"n");
	    return bits.toString();
	}

/**
* Attach one directory to another.
* @param newdir directory to be added
*/
	public final DataDir daddDir(DataDir newdir) {
	    return daddDir(newdir, count);
	}

/**
 * Attach one directory to another at a specified offset.
 *
 * @param newdir directory to be added
 * @param offset 0=first child; >0 = position; >number of children = last
 */
	public final DataDir daddDir(DataDir newdir, int offset) {
	    DataDir pchild = null;

	    if (form == PRIMITIVE)
		return null;

	    if (child != null)
	    {
		if (offset == 0)
		{
		    newdir.next = child;
		    child.prev = newdir;
		    child = newdir;
		}
		else if (offset >= count)
		{
		    last_child.next = newdir;
		    newdir.prev = last_child;
		    last_child = newdir;
		}
		else
		{
		    for (pchild = child; offset > 0; 
			offset--, pchild = pchild.next())
		        ; // empty loop
		    pchild.prev.next = newdir;
		    newdir.prev = pchild.prev;
		    pchild.prev = newdir;
		    newdir.next = pchild;
		}
	    }
	    else
	    {
		last_child = child = newdir;
		newdir.prev = null;
	    }
	    count++;
	    newdir.parent = this;
	    return newdir;
	}

/**
* Remove a node and its children from a directory.
*/
	public final boolean ddelDir() { // delete a non-root dir entry
	    if (parent == null)
		return false;

	    parent.count--;
	    if (parent.last_child == this)
		parent.last_child = prev;

	    if (parent.child == this)
	    {
		parent.child = next;
		return true;
	    }

	    DataDir sibling = parent.child;
	    while (sibling.next != this)
		sibling = sibling.next;
	    sibling.next = next;
	    if (sibling.next != null)
	        sibling.next.prev = sibling;

	    return true;
	}

/**
* Checks for existence of a particular node in a directory.
* @param fldid tag of node to be found
* @param asn1class class of node to be found
* @return true if found, false if not found
*/
	public final boolean dtagFound(int fldid, byte asn1class) {
	    if (child == null)
		return false;
	
	    for (DataDir pchild=child; pchild != null; pchild=pchild.next)
		if (pchild.fldid==fldid && pchild.asn1class == asn1class)
		    return true;
	    return false;
	}

/**
* Clone the DataDir and all it's children and siblings. It will clone all
* data referenced by the DataDirs.
* @return cloned DataDir
*/
        public final Object clone() {
            return clone(null, true);
        }
 
/**
 * Clone the DataDir and all it's children. doSibs indicates whether 
 * to do the siblings of the DataDir.
 * 
 * @param doSibs true = clone siblings; false = do not clone siblings
 * @return cloned DataDir
 */
	public final Object clone(boolean doSibs) {
	    return clone(null, doSibs);
	}

        private final Object clone(DataDir parent, boolean doSibs) {
	    DataDir newdir, pchild, tmpParent;
            
            if (form == CONSTRUCTED)
            {   
                newdir = new DataDir(parent, fldid, asn1class);
                for (pchild = child; pchild != null; pchild = pchild.next)      
                    pchild.clone(newdir, doSibs);

		if (parent == null && next != null && doSibs)
		{
		    tmpParent = new DataDir(fldid, asn1class);
		    tmpParent.daddDir(newdir);
		    // Add siblings
		    for (pchild=next; pchild != null; pchild=pchild.next)
			pchild.clone(tmpParent, doSibs);
		    // remove artificial parent
		    for (pchild = newdir; pchild != null; pchild = pchild.next)
			pchild.parent = null;
		}
            }
            else
            {
                if (dataSource == null)
                    if (object == null)
                        newdir = parent.daddNum(fldid, asn1class, dgetNum());
                    else
                        newdir = parent.daddObj(fldid, asn1class, 
			    (DataDirObject)object.clone());
                else
		    newdir = parent.daddChar(fldid, asn1class, data(),
			0, count);
            }
	    return newdir;
        }
}	

