/*  AboutDlg.java
**
**  by Bryan Wilhelm, Olivet Nazarene University
**  September 11, 1998
**
**  Displays information about the ONU-ILL program.
*/

import java.awt.*;
import java.awt.event.*;


public class AboutDlg extends Dialog implements ActionListener
{
    Button ok;

    Toolkit sys_metrics = Toolkit.getDefaultToolkit( );

    public AboutDlg( Frame parent )
    {
        super( parent, "About ONU-ILL", true );

        setSize( 284, 140 );
        setResizable( false );
        setLayout( null );
        setFont( new Font( "Sans Serif", Font.PLAIN, 11 ) );
        addWindowListener( new CloseWindow( ) );

        Panel pnl_main = new Panel( );
        pnl_main.setLayout( null );
            Label appTitle = new Label( "ONU-ILL, version 3.1", Label.CENTER );
            appTitle.setFont( new Font( "Serif", Font.BOLD, 18 ) );
            appTitle.setBounds( 0, 0, 200, 18 );
            Label university = new Label( "Olivet Nazarene University", Label.CENTER );
            university.setBounds( 0, 26, 200, 12 );
            Label programmer = new Label( "Programmed by Bryan Wilhelm", Label.CENTER );
            programmer.setBounds( 0, 40, 200, 12 );
            Label copyright_date = new Label( "September 11, 1998", Label.CENTER );
            copyright_date.setBounds( 0, 54, 200, 12 );
            ok = new Button( "OK" );
            ok.addActionListener( this );
            ok.setBounds( 76, 74, 48, 24 );
        pnl_main.add( appTitle );
        pnl_main.add( programmer );
        pnl_main.add( university );
        pnl_main.add( copyright_date );
        pnl_main.add( ok );
        pnl_main.setBounds( 72, 32, 200, 100 );
        add( pnl_main );

        int x = (int)( ( ( sys_metrics.getScreenSize( ) ).width - 284 ) / 2 );
        int y = (int)( ( ( sys_metrics.getScreenSize( ) ).height - 140 ) / 2 );
        setLocation( x, y );
        setVisible( true );

    }

    public void paint( Graphics g )
    {
        Image seal = sys_metrics.getImage( "smseal.gif" );
        g.drawImage( seal, 8, 32, this );
    }

    public void actionPerformed( ActionEvent event )
    {
        setVisible( false );
        dispose( );
    }

}