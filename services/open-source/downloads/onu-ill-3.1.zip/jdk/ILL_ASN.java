/* ILL_ASN.java
**
** Bryan Wilhelm, Olivet Nazarene University
** September 11, 1998
**
** Provides data for ASN.1/BER encoding
*/


public interface ILL_ASN
{

    // ASN.1 Constants
    public static final byte 
        ASN1_UNIVERSAL   = (byte) 0,
        ASN1_APPLICATION = (byte) 1,
        ASN1_CONTEXT     = (byte) 2,
        ASN1_PRIVATE     = (byte) 3,
        ASN1_PRIMITIVE   = (byte) 0,
        ASN1_CONSTRUCTED = (byte) 1;

    public static final short
        //ASN1_UNIVERSAL        = 0,
        //ASN1_APPLICATION      = 1,
        //ASN1_CONTEXT          = 2,
        //ASN1_PRIVATE          = 3,
        //ASN1_PRIMITIVE        = 0,
        //ASN1_CONSTRUCTED      = 1,
        ASN1_BOOLEAN          = 1,
        ASN1_INTEGER          = 2,
        ASN1_BITSTRING        = 3,
        ASN1_OCTETSTRING      = 4,
        ASN1_NULL             = 5,
        ASN1_OBJECTIDENTIFIER = 6,
        ASN1_OBJECTDESCRIPTOR = 7,
        ASN1_EXTERNAL         = 8,
        ASN1_SEQUENCE         = 16,
        ASN1_SET              = 17,
        ASN1_VISIBLESTRING    = 26,
        ASN1_GENERALSTRING    = 27;

    public static final short
        ASN1_single_ASN1_type = 0,
        ASN1_octet_aligned    = 1,
        ASN1_arbitrary        = 2;

    // byte order values
    public static final short
        HIGHTOLOW = 1,
        LOWTOHIGH = 2,
        PDP_ORDER = 4;

}

///////////////////////////////////////////////////////////////////////////////
// (c)1996 OCLC Online Computer Library Center, Inc., 6565 Frantz Road, Dublin,
// Ohio 43017-0702.  OCLC is a registered trademark of OCLC Online Computer
// Library Center, Inc.
//
// NOTICE TO USERS:  The BER Utilities ("Software") has been developed by OCLC
// Online Computer Library Center, Inc.  Subject to the terms and conditions set
// forth below, OCLC grants to user a perpetual, non-exclusive, royalty-free
// license to use, reproduce, alter, modify, and create derivative works from
// Software, and to sublicense Software subject to the following terms and
// conditions:
//
// SOFTWARE IS PROVIDED AS IS.  OCLC MAKES NO WARRANTIES, REPRESENTATIONS, OR
// GUARANTEES WHETHER EXPRESS OR IMPLIED REGARDING SOFTWARE, ITS FITNESS FOR ANY
// PARTICULAR PURPOSE, OR THE ACCURACY OF THE INFORMATION CONTAINED THEREIN.
//
// User agrees that OCLC shall have no liability to user arising therefrom,
// regardless of the basis of the action, including liability for special,
// consequential, exemplary, or incidental damages, including lost profits,
// even if it has been advised of the possibility thereof.
//
// User shall cause the copyright notice of OCLC to appear on all copies of
// Software, including derivative works made therefrom.