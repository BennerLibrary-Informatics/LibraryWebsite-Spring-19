ONU_ILL
Version 3.1 (Java 2.1/Applet)

October 2, 1998


--------------------------------------------------------------------------
INTRODUCTION
--------------------------------------------------------------------------
The ONU_ILL Java application is designed to automate the interlibrary loan
patron request process.  It provides a graphical user interface for entry
of the request data, and compiles the data into proper format (ISO 10161) 
for submission through OCLC's Direct Request program.


--------------------------------------------------------------------------
VERSION INFORMATION
--------------------------------------------------------------------------
ONU_ILL version 3.1 is a Java application that requires the Java
Virtual Machine running on the local computer.

Version 3.0 was intended for use with OCLC's IPT request method but
was never released.  Previous versions (2.x and before) were CGI programs
written in C and intended for UNIX (System V) platforms.

Version 3.2 is the applet edition of this application.


--------------------------------------------------------------------------
DISTRIBUTION
--------------------------------------------------------------------------
This archive file (onu-ill-3.2.zip) contains the following:

README        -- This document.

In addition there are two directories that contain both revisions of this
program.

jdk           -- The standard Java revision requiring the Java Development
                 Kit, version 1.1.6 from Sun Microsystems 
                 (http://java.sun.com).
visualj       -- The WFC (Windows Foundation Class) revision requiring
                 Visual J++ 6.0 from Microsoft (http://msdn.microft.com/
                 visualj).


--------------------------------------------------------------------------
INSTALLATION
--------------------------------------------------------------------------
Before installing either application revision to a computer, the
ONU_ILL_CONST.java file must be edited to match your own institutions
passwords and requirements.

After editing ONU_ILL_CONST.java use the following installation
instructions.

    ----------------------------------------------------------------------
    JAVA DEVELOPMENT KIT (JDK) 1.1.6
    ----------------------------------------------------------------------
    Compile the JAVA files with the JDK 1.1.6 by use the command line
    statement:

        javac -O *.java

    This will compile all JAVA files using [O]ptimization.

    To install it to a another computer, you will need to install the
    Java Runtime Environment (JRE), also available from Sun Microsystems,
    and run the program with the command:

        jview ONU_ILL

    You may wish to put this in a batch file.


    ----------------------------------------------------------------------
    VISUAL J++ 6.0
    ----------------------------------------------------------------------
    Open up the project file (ONU_ILL.sln) not the JAVA files in Visual
    J++ 6.0.  Choose the menu item "Projects | ONU_ILL Properties" and
    select the "Output Files" tab.  Create a "Self-Extracting Executable"
    and under "Package Contents" select all the files.  Also use the
    "Advanced" features of the self-extracting executable to setup the
    installation program the way you want it.  After this simply "Build"
    the project and install on another computer.

    NOTE:  Visual J++ 6.0 programs require Internet Explorer 4.0 and will
    only run on 32-bit Windows platforms.
    
    
    **********************************************************************
    IMPORTANT NOTE
    **********************************************************************
    This program will not function properly until the OCLC Direct Request 
    planning guide has been completed.  OCLC will supply the address and 
    port of their interlibrary loan production server.

    The URL of the planning guide is:
    http://www.oclc.org/oclc/specs/dillspec.htm




