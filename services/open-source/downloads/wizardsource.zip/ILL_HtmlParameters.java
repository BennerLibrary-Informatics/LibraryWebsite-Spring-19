/*-----------------------------------------------------------------------------
ILL_HtmlParameters.java

Written by Bryan Wilhelm
Created on August 13, 1999

TODO:
=============================================================================

Known Bugs:
=============================================================================

Modification History
=============================================================================
08/13/1999  File created.
-----------------------------------------------------------------------------*/

import java.awt.Color ;

public class ILL_HtmlParameters
{
    public Color   mainBgColor ;
    public Color   mainFgColor ;
    public Color   menuBgColor ;
    public String  institutionName ;
    public String  libraryName ;
    public String  librarySymbol ;
    public String  authorization ;
    public String  password ;
    public String  validUsers ;
    public short   illServiceType ;
    public String  lenderList ;
    public int     maxRequests ;
    public String  deliveryName ;
    public String  deliveryExtension ;
    public String  deliveryStreet ;
    public String  deliveryPOBox ;
    public String  deliveryCity ;
    public String  deliveryState ;
    public String  deliveryCountry ;
    public String  deliveryZipCode ;
    public String  deliveryService ;
    public String  electronicService ;
    public String  libraryPhone ;
    public String  libraryFax ;
    public String  libraryEmail ;
    public String  maxCost ;
    public boolean allowNonmemberRequests ;
    public String  bookNote ;
    public String  periodicalNote ;
    public String  cancelURL ;
    public String  submitURL ;
    public String  onlineCatalogURL ;
    public String  periodicalHoldingsURL ;
    public String  illServerAddress ;
    public int     illServerPort ;
    
    public ILL_HtmlParameters( )
    {
        // TODO: Initialize member variables.
    }
}