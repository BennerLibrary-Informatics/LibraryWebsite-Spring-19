/*-----------------------------------------------------------------------------
RequestInformation.java

Written by Bryan Wilhelm
Created on July 7, 1999

Modification History
=============================================================================
07/07/1999  File opened.
-----------------------------------------------------------------------------*/

public class RequestInformation implements ILL_Constants
{
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Fields
    //
    public String
        need_before_date,                   // YYYYMMDD format
        held_medium_type,                   // TITLE
        call_number,                        // BORROWING NOTES
        author,                             // AUTHOR
        title,                              // TITLE
        sub_title,                          // TITLE
        sponsoring_body,                    // TITLE
        place_of_publication,               // IMPRINT
        publisher,                          // PUBLISHER
        series_title_number,                // SERIES NOTE
        volume,                             // VOLUME
        issue,                              // ISSUE
        affiliations,                       // DILL
        source,                             // PATRON NOTES
        source_details,                     // PATRON NOTES
        edition,                            // EDITION
        publication_date,                   // IMPRINT
        title_of_article,                   // ARTICLE
        pagination,                         // PAGES
        isbn,                               // VERIFIED
        issn,                               // VERIFIED
        oclc_no,                            // OCLC
        eric_no,                            // PATRON_NOTES
        verification_reference_source,      // VERIFIED
        uniform_title,                      // UNIFORM TITLE
        patron_notes ;                      // PATRON NOTES
    
    public boolean
        dissertation,                       // DISSERTATION
        conference ;                        // PATRON NOTES
    
    public short
        request_type ;
    
    public boolean
        requestMade ;
        
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Constructor
    //
    public RequestInformation( )
    {
        need_before_date = new String( ) ;
        held_medium_type = new String( ) ;
        call_number = new String( ) ;
        author = new String( ) ;
        title = new String( ) ;
        sub_title = new String( ) ;
        sponsoring_body = new String( ) ;
        place_of_publication = new String( ) ;
        publisher = new String( ) ;
        series_title_number = new String( ) ;
        volume = new String( ) ;
        issue = new String( ) ;
        affiliations = new String( ) ;
        source = new String( ) ;
        source_details = new String( ) ;
        edition = new String( ) ;
        publication_date = new String( ) ;
        title_of_article = new String( ) ;
        pagination = new String( ) ;
        isbn = new String( ) ;
        issn = new String( ) ;
        oclc_no = new String( ) ;
        eric_no = new String( ) ;
        verification_reference_source = new String( ) ;
        uniform_title = new String( ) ;
        patron_notes = new String( ) ;
        dissertation = false ;
        conference = false ;
        request_type = INVALID_REQUEST_TYPE ;
        requestMade = false ;
    }
}