/*-----------------------------------------------------------------------------
ILL_Constants.java

Written by Bryan Wilhelm
Created on June 30, 1999

This interface contains constant values needed throughout the lifetime of the
program. The primary purpose for consolidating all values here in a single file
is for convenience.
-----------------------------------------------------------------------------*/

import java.util.Date ;

public interface ILL_Constants
{
    // Graphical user interface constants
    public static final int BUTTON_HEIGHT = 24 ;
    public static final int TEXTFIELD_HEIGHT = 20 ;
    public static final int CHECKBOX_HEIGHT = 20 ;
    public static final int LABEL_HEIGHT = 14 ;
    public static final int BOUNDARY_WIDTH = 8 ;
    public static final int MENU_BAR_WIDTH = 120 ;
    public static final int APPLET_WIDTH = 600 ;
    public static final int APPLET_HEIGHT = 800 ;
    
    // Constants required for calculations
    public static final int  DEFAULT_NEEDBEFORE_DAYS = 25 ;
    public static final Date 
        DEFAULT_NEEDBEFORE_DATE = new Date( System.currentTimeMillis( ) +
                                            ( long )( DEFAULT_NEEDBEFORE_DAYS * 8.64e7 ) ) ;
    
    // Request types
    public static final short INVALID_REQUEST_TYPE = -1 ;
    public static final short BOOK_REQUEST = 1 ;
    public static final short PERIODICAL_REQUEST = 2 ;
    
    // Applet constants
    public static final String ILL_FORM_VERSION = new String( "1.0 Beta 2" ) ;
    public static final String JAVA_VERSION = new String( "1.2.1" ) ;
    public static final String DEVELOPERS_EMAIL = new String( "bryan_wilhelm@hotmail.com" ) ;
    
    // Buttons
    public static final short USERPROFILE_BUTTON = 1 ;
    public static final short BOOKREQUEST_BUTTON = 2 ;
    public static final short ARTICLEREQUEST_BUTTON = 3 ;
    public static final short VIEWREQUESTS_BUTTON = 4 ;
    public static final short DELETEREQUESTS_BUTTON = 5 ;
    public static final short SUBMISSION_BUTTON = 6 ;
    public static final short ABOUT_BUTTON = 7 ;
    public static final short UPDATE_APPLET = 8 ;
    
    // Submission States
    public static final short STATUS_OK = 0 ;
    public static final short STATUS_WARNING = 1 ;
    public static final short STATUS_ERROR = 2 ;
}