/*-----------------------------------------------------------------------------
ILL_Date.java

Written by Bryan Wilhelm
Created on June 30, 1999

This correct string format used in interlibrary loan transactions is YYYYMMDD.
In this format 19991101 represents November 1, 1999.

Modification History
=============================================================================
06/30/1999  Filed opened.
-----------------------------------------------------------------------------*/

import java.util.Calendar ;
import java.util.Date ;
import java.text.DateFormat ;
import java.text.ParseException ;

public class ILL_Date
{
    ///////////////////////////////////////////////////////////////////////////
    //
    //  getFormattedDate( ) - returns the current date in the correct string 
    //      format.
    //
    public static String getFormattedDate( )
    {
        return getFormattedDate( new Date( ) ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  getFormattedDate( Date date ) - returns the specific date in the
    //      correct string format.
    //
    public static String getFormattedDate( Date date )
    {
        // Initialize the temporary calendar.
        Calendar calendar = Calendar.getInstance( ) ;
        calendar.clear( ) ;
        calendar.setTime( date ) ;
        
        // Get the necessary parts of the calendar.
        int year = calendar.get( Calendar.YEAR ) ;
        int month = calendar.get( Calendar.MONTH ) + 1 ;
        int day = calendar.get( Calendar.DAY_OF_MONTH ) ;
        
        // Construct the date in the correct string format.
        String s = new String( "" + year +
            ( month < 10 ? "0" : "" ) + month +
            ( day < 10 ? "0" : "" ) + day ) ;

        return new String( s ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  getFormattedDate( String date ) - converts a normal string date into a
    //      properly formatted date string.
    //
    public static String getFormattedDate( String date )
    {
        DateFormat dateFormat = DateFormat.getDateInstance( DateFormat.LONG ) ;
        
        try 
        {
            return getFormattedDate( dateFormat.parse( date ) ) ;
        }
        catch ( ParseException parseException )
        {
            return getFormattedDate( ILL_Constants.DEFAULT_NEEDBEFORE_DATE ) ;
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  getDate( String date ) - converts a formatted date string into a 
    //      normal date format.
    //
    public static String getStringDate( String date ) 
    {
        // Local variables
        Calendar calendar = getCalendarDate( date ) ;
        DateFormat dateFormat = DateFormat.getDateInstance( DateFormat.LONG ) ;
        
        // Set the calendar to the date formatter and return the value.
        return dateFormat.format( calendar.getTime( ) ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  getDate( String date ) - returns a date object based on a formatted
    //      string.  If the string is invalid then null is returned.
    //
    public static Calendar getCalendarDate( String date )
    {
        Calendar calendar = Calendar.getInstance( ) ;
        
        try 
        {
            // Parse the elements of the formatted string.
            int year = Integer.parseInt( date.substring( 0, 4 ) ) ;
            int month = Integer.parseInt( date.substring( 4, 6 ) ) ;
            int day = Integer.parseInt( date.substring( 6 ) ) ;
            
            // Set the calendar date.
            calendar.clear( ) ;
            calendar.set( year, month, day ) ;
        }
        catch ( NumberFormatException numberFormatException )
        {
            return null ;
        }
        
        return calendar ;
    }
}