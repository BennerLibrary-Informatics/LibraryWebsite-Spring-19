/*-----------------------------------------------------------------------------
UserProfile.java

Written by Bryan Wilhelm
Created on July 5, 1999

Modification History
=============================================================================
07/05/1999  File opened.
-----------------------------------------------------------------------------*/

public class UserProfile
{
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Fields
    //
    public String 
        id,                     // PATRON ID
        full_name,              // PATRON
        first_name,             // PATRON
        last_name,              // PATRON
        initials,               // PATRON
        title,                  // PATRON
        suffix,                 // PATRON
        ssn,                    // PATRON ID
        home_street_address,    // PATRON ADDR
        home_po_box,            // PATRON ADDR
        home_city,              // PATRON ADDR
        home_state,             // PATRON ADDR
        home_country,           // PATRON ADDR
        home_postal_code,       // PATRON ADDR
        work_extension,         // PATRON ADDR   
        work_street_no,         // PATRON ADDR
        work_po_box,            // PATRON ADDR
        work_city,              // PATRON ADDR
        work_region,            // PATRON ADDR 
        work_country,           // PATRON ADDR
        work_postal_code,       // PATRON ADDR
        phone,                  // PATRON PHONE
        email,                  // PATRON EMAIL
        fax,                    // PATRON FAX
        pager,                  // PATRON PHONE
        status,                 // PSTATUS
        department,             // PDEPT
        notes,                  // PATRON NOTES
        monetary_value ;        // PATRON MAXCOST
        
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Constructor
    //
    public UserProfile( )
    {
        id = new String( ) ;
        full_name = new String( ) ;
        first_name = new String( ) ;
        last_name = new String( ) ;
        initials = new String( ) ;
        title = new String( ) ;
        suffix = new String( ) ;
        ssn = new String( ) ;
        home_street_address = new String( ) ;
        home_po_box = new String( ) ;
        home_city = new String( ) ;
        home_state = new String( ) ;
        home_country = new String( ) ;
        home_postal_code = new String( ) ;
        work_extension = new String( ) ;
        work_street_no = new String( ) ;
        work_po_box = new String( ) ;
        work_city = new String( ) ;
        work_region = new String( ) ;
        work_country = new String( ) ;
        work_postal_code = new String( ) ;
        phone = new String( ) ;
        email = new String( ) ;
        fax = new String( ) ;
        pager = new String( ) ;
        status = new String( ) ;
        department = new String( ) ;
        notes = new String( ) ;
        monetary_value = new String( ) ;
    }
}
