/*-----------------------------------------------------------------------------
ImageCanvas.java

Written by Bryan Wilhelm (bryan_wilhelm@hotmail.com)
Created on September 06, 1999

TODO:
===============================================================================

KNOWN ISSUES:
===============================================================================

MODIFICATION HISTORY:
===============================================================================
-----------------------------------------------------------------------------*/

import java.awt.Canvas ;
import java.awt.Image ;
import java.awt.Graphics ;
import java.awt.image.ImageObserver ;

public class ImageCanvas 
       extends Canvas
       implements ImageObserver
{
    Image image ; 
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Constructor
    //
    public ImageCanvas( Image image )
    {
        this.image = image ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Paint
    //
    public void paint( Graphics g )
    {
        g.drawImage( image, 0, 0, this ) ;
    }
    
    public void update( Graphics g )
    {
        g.drawImage( image, 0, 0, this ) ;
    }
}