/*-----------------------------------------------------------------------------
IsoIllAnswer.java

Written by Bryan Wilhelm
Created on August 29, 1999

TODO:
=============================================================================

Known Bugs:
=============================================================================

Modification History
=============================================================================
08/29/1999  File created.
-----------------------------------------------------------------------------*/


import java.util.Vector ;public class IsoIllAnswer implements ILL_API, ILL_ASN
{
    String transaction_qualifier;
    String transaction_group_qualifier;
    String requester_id;
    int transaction_results;
    int results_explanation;
    int reasons_in_review_count; /* number of entries in reasons in review */
    Vector reasons_in_review; /* array of stings to reasons text strings */
    String ill_no;        ///////////////////////////////////////////////////////////////////////////    //    //  Constructor    //    public IsoIllAnswer( DataDir dir )    {
        DataDir datadir = null ;
        DataDir extdir  = null ;
        DataDir sindir  = null ;

        long i = 0 ;
        boolean found = false ;

       /*
       ** get institution symbol
       */

        if ( ( datadir = finddir( finddir( finddir( finddir( finddir( finddir( dir,
                                                                               ASN1_SEQUENCE,
                                                                               ASN1_UNIVERSAL,                                                                                0 ),
                                                                      TRANSACTION_ID,                                                                       ASN1_CONTEXT,                                                                       0 ),
                                                             INITIAL_REQUESTER_ID,                                                              ASN1_CONTEXT,                                                              0 ),
                                                    PERSON_OR_INSTITUTION_SYMBOL,                                                     ASN1_CONTEXT,                                                     0 ),
                                           INSTITUTION_SYMBOL,                                            ASN1_CONTEXT,                                            0 ),
                                  ASN1_GENERALSTRING,                                   ASN1_UNIVERSAL,                                   0 ) ) != null )        {
            requester_id = new String( datadir.data( ) ) ;
        }

       /*
       ** get transaction qualifier
       */

        if ( ( datadir = finddir( finddir( finddir( finddir( dir,
                                                             ASN1_SEQUENCE,                                                              ASN1_UNIVERSAL,                                                              0 ),
                                                    TRANSACTION_ID,                                                     ASN1_CONTEXT,                                                     0 ),
                                           TRANSACTION_QUALIFIER,                                            ASN1_CONTEXT,                                            0 ),
                                  ASN1_GENERALSTRING,                                   ASN1_UNIVERSAL,                                   0 ) ) != null )        {
            transaction_qualifier = new String( datadir.data( ) ) ;
        }

       /*
       ** get transaction group qualifier
       */

        if ( ( datadir = finddir( finddir( finddir( finddir( dir,
                                                             ASN1_SEQUENCE,                                                              ASN1_UNIVERSAL,                                                              0 ),
                                                    TRANSACTION_ID,                                                     ASN1_CONTEXT,                                                     0 ),
                                           TRANSACTION_GROUP_QUALIFIER,                                            ASN1_CONTEXT,                                            0 ),
                                  ASN1_GENERALSTRING,                                   ASN1_UNIVERSAL,                                   0 ) ) != null )        {
            transaction_group_qualifier = new String( datadir.data( ) ) ;        }

       /*
       ** get transaction results
       */

        if ( ( datadir = finddir( finddir( dir,
                                           ASN1_SEQUENCE,                                            ASN1_UNIVERSAL,                                            0 ),
                                  TRANSACTION_RESULTS,                                   ASN1_CONTEXT,                                   0 ) ) != null )        {
            transaction_results = (int) datadir.dgetNum( ) ;

           /*
           ** get reason unfilled
           */

            if ( transaction_results == UNFILLED_TR )
            {
                if ( ( datadir = finddir( finddir( finddir( finddir( finddir( dir,
                                                                              ASN1_SEQUENCE,                                                                               ASN1_UNIVERSAL,                                                                               0 ),
                                                                     RESULTS_EXPLANATION,                                                                      ASN1_CONTEXT,                                                                      0 ),
                                                            UNFILLED_RESULTS,                                                             ASN1_CONTEXT,                                                             0 ),
                                                   ASN1_SEQUENCE,                                                    ASN1_UNIVERSAL,                                                    0 ),
                                          REASON_UNFILLED,                                           ASN1_CONTEXT,                                           0 ) ) != null )                {
                    results_explanation = ( int ) datadir.dgetNum( ) ;                }
            }
        }

       /*
       ** get reasons in review if present
       */

        if ( ( extdir = finddir( finddir( finddir( dir,
                                                   ASN1_SEQUENCE,                                                    ASN1_UNIVERSAL,                                                    0 ),
                                          RESPONDER_SPECIFIC_RESULTS,                                           ASN1_CONTEXT,                                           0 ),
                                 ASN1_EXTERNAL,                                  ASN1_UNIVERSAL,                                  0 ) ) != null )
        {
            //DataDir sindir ;
            DataDir reasondir ;
            //long i ;

            if ( ( datadir = finddir( extdir, ASN1_OBJECTIDENTIFIER, ASN1_UNIVERSAL, 0 ) ) != null &&                 datadir.dgetoid( ).equals( OID_OCLC_SPECIFIC_RESULTS ) &&                 ( sindir = finddir( extdir, SINGLE_ASN1_TYPE, ASN1_CONTEXT, 0 ) ) != null )
            {                reasons_in_review = new Vector( ) ;                
                for ( i = 0 ;                       ( datadir = finddir( finddir( finddir( finddir( sindir,
                                                                      ASN1_SEQUENCE,                                                                       ASN1_UNIVERSAL,                                                                       0 ),
                                                             REASON_IN_REVIEW_LIST,                                                              ASN1_CONTEXT,                                                              0 ),
                                                    ASN1_SEQUENCE,                                                     ASN1_UNIVERSAL,                                                     i ),
                                           REASON_IN_REVIEW_TEXT,                                            ASN1_CONTEXT,                                            0 ) ) != null ;
                      ++i )
                {
                    if ( ( reasondir = finddir( datadir, ASN1_GENERALSTRING, ASN1_UNIVERSAL, 0 ) ) != null )                    {                        reasons_in_review.addElement( new String( reasondir.data( ) ) ) ;
                    }
                }                                reasons_in_review_count = reasons_in_review.size( ) ;
            }
        }

        i = 0 ;
        do
        {
            if ( ( extdir = finddir( finddir( finddir( finddir( finddir( dir,
                                                                         SEQUENCE,                                                                          ASN1_UNIVERSAL,                                                                          0 ),
                                                                EXTENSIONS,                                                                 ASN1_CONTEXT,                                                                 0 ),
                                                       SEQUENCE,                                                        ASN1_UNIVERSAL,                                                        i++ ),
                                              EXTENSION_ITEM,                                               ASN1_CONTEXT,                                               0 ),
                                     ASN1_EXTERNAL,                                      ASN1_UNIVERSAL,                                      0 ) ) != null )
            {
                if ( ( datadir = finddir( extdir, ASN1_OBJECTIDENTIFIER, ASN1_UNIVERSAL, 0 ) ) != null &&                     datadir.dgetoid( ).equals( OID_SUPPLIERSREFERENCE ) &&
                     ( sindir = finddir( extdir, SINGLE_ASN1_TYPE, ASN1_CONTEXT, 0 ) ) != null )
                {
                    datadir = finddir( finddir( finddir( sindir,
                                                         ASN1_SEQUENCE,                                                          ASN1_UNIVERSAL,                                                          0 ),
                                                SUPPLIER_AUTHORITY,                                                 ASN1_CONTEXT,                                                 0 ),
                                       ASN1_GENERALSTRING,                                        ASN1_UNIVERSAL,                                        0 ) ;

                    if ( datadir != null && ( new String( datadir.data( ) ) ).equals( "OCLC" ) )
                    {
                        datadir = finddir( finddir( finddir( sindir,
                                                             ASN1_SEQUENCE,                                                              ASN1_UNIVERSAL,                                                              0 ),
                                                    SUPPLIER_REFERENCE,                                                     ASN1_CONTEXT,                                                     0 ),
                                           ASN1_GENERALSTRING,                                            ASN1_UNIVERSAL,                                            0 ) ;

                        if ( datadir != null )                        {
                            ill_no = new String( datadir.data( ) ) ;
                        }

                        found = true ;
                    }
                }
            }            
        } while ( ( extdir != null ) && !found ) ;
    }
    private DataDir finddir( DataDir dir,
                             int fldid,
                             byte asn1class,
                             long occurence )
    {
        DataDir subdir;

        if ( dir == null )        {
            return null ;        }        
        for ( subdir = dir.child( ) ; subdir != null ; subdir = subdir.next( ) )        {            if ( subdir.fldid( ) == fldid &&                 subdir.asn1class( ) == asn1class &&                 occurence-- <= 0 )
            {                return subdir ;
            }        }        
        return null ;
    }
}
