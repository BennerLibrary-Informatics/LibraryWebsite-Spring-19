/*-----------------------------------------------------------------------------
ErrorMessageDialog.java

Written by Bryan Wilhelm
Created on June 30, 1999

TODO:
=============================================================================
* Currently is compiling under deprecation. Toolkit has FontMetrics under
  1.1 and Graphics has FontMetrics under 1.2. There may be no good solution
  in the immediate future.

Known Bugs:
=============================================================================
* Netscape 4.51 (WinNT 4.0 SP4) truncates the lower 18 pixels of the message
  box.

Modification History
=============================================================================
07/09/1999  File created.
-----------------------------------------------------------------------------*/

import java.awt.Button ;
import java.awt.Dialog ;
import java.awt.Font ;
import java.awt.FontMetrics ;
import java.awt.Frame ;
import java.awt.Label ;
import java.awt.Panel ;
import java.awt.Toolkit ;
import java.awt.event.ActionEvent ;
import java.awt.event.ActionListener ;
import java.awt.event.WindowAdapter ;
import java.awt.event.WindowEvent ;

public class ErrorMessageDialog 
       extends Dialog
       implements ActionListener
{
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Class variables
    //
    Toolkit defaultToolkit = Toolkit.getDefaultToolkit( ) ;
    Button okButton ;
    Label messageLabel ;
    Panel messagePanel ;
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Constructor
    //
    public ErrorMessageDialog( Frame owner, String message )
    {
        // Call to the super class
        super( owner, "ILL Wizard Warning", true ) ;
        addWindowListener( new CloseWindow( ) ) ;

        // Remove the layout manager so the component can be placed
        // manually on the dialog.
        setLayout( null ) ;
        
        Font messageFont = new Font( "SansSerif", Font.PLAIN, 11 ) ;
        
        // Calculate window dimensions.
        int screenHeight = defaultToolkit.getScreenSize( ).height ;
        int screenWidth = defaultToolkit.getScreenSize( ).width ;
        
        //
        // The Toolkit getFontMetrics method has been deprecated as of JDK 1.2.
        // IE and Netscape should both support it for some time in the future,
        // but this should be changed to Graphics getFontMetrics method as soon
        // as both support the Java 2 Platform (Netscape scheduled to support 
        // Java 2 in version 5).
        //
        int messageWidth = defaultToolkit.getFontMetrics( messageFont ).stringWidth( message ) ;
        
        // Add the message label to the dialog
        messagePanel = new Panel( null ) ;
        messagePanel.add( messageLabel = new Label( message, Label.CENTER ) ) ;
        messageLabel.setFont( new Font( "SansSerif", Font.PLAIN, 11 ) ) ;
        messageLabel.setBounds( 0, 0, messageWidth, 14 ) ;
        
        // Add the OK button to the dialog
        messagePanel.add( okButton = new Button( "OK" ) ) ;
        okButton.addActionListener( this ) ;
        okButton.setBounds( messageWidth / 2 - 32, 22, 64, 24 ) ;
        
        // Add panel to the dialog
        add( messagePanel ) ;
        messagePanel.setBounds( 10, 32, messageWidth, 46 ) ;
        
        int dialogWidth = 20 + messageWidth ;
        int dialogHeight = 82 + messagePanel.getSize( ).height ;
        
        // Resize the dialog
        setBounds( ( screenWidth - dialogWidth ) / 2, ( screenHeight - dialogHeight ) / 2,
                   dialogWidth, dialogHeight ) ;
        setResizable( false ) ;
        
        // Display the dialog
        setVisible( true ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Event handler
    //
    public void actionPerformed( ActionEvent actionEvent )
    {
        setVisible( false ) ;
        dispose( ) ;
    }
}


class CloseWindow extends WindowAdapter
{
    public void windowClosing( WindowEvent windowEvent )
    {
        windowEvent.getWindow( ).setVisible( false ) ;
    }
}
