/*-----------------------------------------------------------------------------IsoIllStatusOrErrorReport.javaWritten by Bryan Wilhelm (bryan_wilhelm@hotmail.com)Created on August 29, 1999Based on C utilities written by OCLC.
-----------------------------------------------------------------------------*/

import java.util.Vector ;public class IsoIllStatusOrErrorReport implements ILL_API, ILL_ASN
{
    String transaction_qualifier ;
    String transaction_group_qualifier ;
    String requester_id ;
    int current_state ;       // only set if no error occurred
    String note ;
    boolean error_occurred ;      // flag which indicates if an error occurred 
    int errors_count ;        // number of entries in errors 
    Vector errors ;             // array of strings to error text strings
    String ill_no ;    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Constructor - initializes the report.
    //    public IsoIllStatusOrErrorReport( DataDir dir )    {        DataDir datadir = null ;
        DataDir sindir  = null ;
        DataDir extdir  = null ;
        DataDir errdir  = null ;

        boolean found = false ;
        long  i ;

       /*
       ** get institution symbol
       */

        if ( ( datadir = finddir( finddir( finddir( finddir( finddir( finddir( dir,
                                                                               ASN1_SEQUENCE,
                                                                               ASN1_UNIVERSAL,                                                                                0 ),
                                                                      TRANSACTION_ID,                                                                       ASN1_CONTEXT,                                                                       0 ),
                                                             INITIAL_REQUESTER_ID,                                                              ASN1_CONTEXT,                                                              0 ),
                                                    PERSON_OR_INSTITUTION_SYMBOL,                                                     ASN1_CONTEXT,                                                     0 ),
                                           INSTITUTION_SYMBOL,                                            ASN1_CONTEXT,                                            0 ),
                                  ASN1_GENERALSTRING,                                   ASN1_UNIVERSAL,                                   0 ) ) != null )        {
            requester_id = new String( datadir.data( ) ) ;
        }

       /*
       ** get transaction qualifier
       */

        if ( ( datadir = finddir( finddir( finddir( finddir( dir,
                                                             ASN1_SEQUENCE,                                                              ASN1_UNIVERSAL,                                                             0 ),
                                                    TRANSACTION_ID,                                                     ASN1_CONTEXT,                                                     0 ),
                                           TRANSACTION_QUALIFIER,                                            ASN1_CONTEXT,                                            0 ),
                                  ASN1_GENERALSTRING,                                   ASN1_UNIVERSAL,                                   0 ) ) != null )        {
            transaction_qualifier = new String( datadir.data( ) ) ;
        }

       /*
       ** get transaction group qualifier
       */

        if ( ( datadir = finddir( finddir( finddir( finddir( dir,
                                                             ASN1_SEQUENCE,                                                              ASN1_UNIVERSAL,                                                              0 ),
                                                    TRANSACTION_ID,                                                     ASN1_CONTEXT,                                                     0 ),
                                           TRANSACTION_GROUP_QUALIFIER,                                            ASN1_CONTEXT,                                            0 ),
                                  ASN1_GENERALSTRING,                                   ASN1_UNIVERSAL,                                   0 ) ) != null )        {
            transaction_group_qualifier = new String( datadir.data( ) ) ;
        }        
       /*
       ** get note
       */

        if ( ( datadir = finddir( finddir( finddir( dir,
                                                    ASN1_SEQUENCE,                                                     ASN1_UNIVERSAL,                                                     0 ),
                                           REQUESTER_NOTE,                                            ASN1_CONTEXT,                                            0 ),
                                  ASN1_GENERALSTRING,                                   ASN1_UNIVERSAL,                                   0 ) ) != null )        {
            note = new String( datadir.data( ) ) ;        }


       /*
       ** if status report, get current state
       */

        if ( ( datadir = finddir( finddir( finddir( dir,
                                                    ASN1_SEQUENCE,                                                     ASN1_UNIVERSAL,                                                    0 ),
                                           STATUS_REPORT,                                            ASN1_CONTEXT,                                            0 ),
                                  PROVIDER_STATUS_REPORT,                                   ASN1_CONTEXT,                                   0 ) ) != null )        {
            current_state = ( int ) datadir.dgetNum( ) ;        }

       /*
       ** get error report if present
       */

        if ( ( datadir = finddir( finddir( dir,
                                           ASN1_SEQUENCE,                                            ASN1_UNIVERSAL,                                            0 ),
                                  ERROR_REPORT,                                   ASN1_CONTEXT,                                   0 ) ) != null )        {
            error_occurred = true ;        }
        else        {
            error_occurred = false ;        }               /*
       ** get extensions
       */

        i = 0 ;
        do
        {
            if ( ( extdir = finddir( finddir( finddir( finddir( finddir( dir,
                                                                         SEQUENCE,                                                                          ASN1_UNIVERSAL,                                                                          0 ),
                                                                EXTENSIONS,                                                                 ASN1_CONTEXT,                                                                 0 ),
                                                       SEQUENCE,                                                        ASN1_UNIVERSAL,                                                        i++ ),
                                              EXTENSION_ITEM,                                               ASN1_CONTEXT,                                               0 ),
                                     ASN1_EXTERNAL,                                      ASN1_UNIVERSAL,                                      0 ) ) != null )
            {
                if ( ( datadir = finddir( extdir, ASN1_OBJECTIDENTIFIER, ASN1_UNIVERSAL, 0) ) != null &&                     datadir.dgetoid( ).equals( OID_SUPPLIERSREFERENCE ) &&
                     ( sindir = finddir( extdir, SINGLE_ASN1_TYPE, ASN1_CONTEXT, 0 ) ) != null )
               {
                    datadir = finddir( finddir( finddir( sindir,
                                                         ASN1_SEQUENCE,                                                          ASN1_UNIVERSAL,                                                         0 ),
                                                SUPPLIER_AUTHORITY,                                                 ASN1_CONTEXT,                                                 0 ),
                                       ASN1_GENERALSTRING,                                       ASN1_UNIVERSAL,                                        0 ) ;

                    if ( datadir != null &&                         ( new String( datadir.data( ) ) ).equals( "OCLC" ) )
                    {
                        datadir = finddir( finddir( finddir( sindir,
                                                             ASN1_SEQUENCE,                                                              ASN1_UNIVERSAL,                                                              0 ),
                                                    SUPPLIER_REFERENCE,                                                     ASN1_CONTEXT,                                                     0 ),
                                           ASN1_GENERALSTRING,                                            ASN1_UNIVERSAL,                                           0 ) ;

                        if ( datadir != null )                        {
                            ill_no = new String( datadir.data( ) ) ;                        }

                        found = true ;
                    }
                }
            }
        } while ( extdir != null && !found ) ;

        if ( ( extdir = finddir( finddir( finddir( finddir( finddir( dir,
                                                                     SEQUENCE,                                                                      ASN1_UNIVERSAL,                                                                     0 ),
                                                            EXTENSIONS,                                                             ASN1_CONTEXT,                                                             0 ),
                                                   SEQUENCE,                                                    ASN1_UNIVERSAL,                                                    0 ),
                                          EXTENSION_ITEM,                                           ASN1_CONTEXT,                                           0 ),
                                 ASN1_EXTERNAL,                                 ASN1_UNIVERSAL,                                  0 ) ) != null )
        {
            if ( ( datadir = finddir( extdir, ASN1_OBJECTIDENTIFIER, ASN1_UNIVERSAL, 0 ) ) != null &&                 datadir.dgetoid( ).equals( OID_OCLC_ILL_ERROR_LIST ) &&
                 ( sindir = finddir( extdir, SINGLE_ASN1_TYPE, ASN1_CONTEXT, 0 ) ) != null )
            {                errors = new Vector( ) ;                
                for ( i = 0 ;
                      ( datadir = finddir( finddir( finddir( sindir,
                                                             ASN1_SEQUENCE,                                                              ASN1_UNIVERSAL,                                                              0 ),
                                                    ASN1_SEQUENCE,                                                     ASN1_UNIVERSAL,                                                     i ),
                                           OCLC_ILL_ERROR_TEXT,                                            ASN1_CONTEXT,                                            0 ) ) != null ;
                      ++i )
                {
                    errdir = finddir( datadir, ASN1_GENERALSTRING, ASN1_UNIVERSAL, 0 ) ;
                    if ( errdir != null )
                    {                        errors.addElement( new String( errdir.data( ) ) ) ;
                    }
                }                                errors_count = errors.size( ) ;
            }
        }
    }            private DataDir finddir( DataDir dir,
                             int fldid,
                             byte asn1class,
                             long occurence )
    {
        DataDir subdir;

        if ( dir == null )        {
            return null ;        }        
        for ( subdir = dir.child( ) ; subdir != null ; subdir = subdir.next( ) )        {            if ( subdir.fldid( ) == fldid &&                 subdir.asn1class( ) == asn1class &&                 occurence-- <= 0 )
            {                return subdir ;
            }        }        
        return null ;
    }
    
} 
