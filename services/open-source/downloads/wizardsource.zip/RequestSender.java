/*-----------------------------------------------------------------------------
RequestSender.java

Written by Bryan Wilhelm
Created on August 5, 1999

TODO:
=============================================================================

Known Bugs:
=============================================================================

Modification History
=============================================================================
09/14/1999  Adjusted the messages and icons to correspond to the new OCLC
            server changes.
-----------------------------------------------------------------------------*/

import java.io.DataInputStream ;
import java.io.DataOutputStream ;
import java.io.EOFException ;
import java.io.FileNotFoundException ;
import java.io.IOException ;
import java.net.Socket ;
//import java.net.SocketPermission ;
import java.net.UnknownHostException ;
import java.util.Date ;
import java.util.Vector ;
//import sun.net.smtp.SmtpClient ;


public class RequestSender 
       implements ILL_Constants,
                  ILL_API
{
    private ILL_HtmlParameters htmlParams ;
    private UserProfile userProfile ;
    private Vector requestList ;
    
    private String msg ;
    private short status ;
    
    private Socket connection ;
    private DataInputStream input ;
    private DataOutputStream output ;
    private IsoIllRequest request ;
    private BerString berRequest ;
    private BerString berResponse ;
    private IsoIllApdu apdu ;
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Constructor
    //
    public RequestSender( ILL_HtmlParameters params,
                          UserProfile profile,
                          Vector list )
    {
        htmlParams = params ;
        requestList = list ;
        userProfile = profile ;
        msg = new String( ) ;
        status = STATUS_OK ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Accessor methods
    //
    public String getMessage( )
    {
        return msg ;
    }
    
    public short getStatus( )
    {
        return status ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Submit the request.
    //
    public void send( )
    {
        // Obtain security permission to use the system network facilities.
        //
        // The following code fragment is based on the Java 1.2 class library.
        // For compatibility with web browser, Java 1.1 code will be used until
        // such time both Microsoft and Netscape have implemented the new JVM.
        //
        //SocketPermission permission = new SocketPermission( host, "accept,connect,listen,resolve" ) ;
        //try {
        //    java.security.AccessController.checkPermission( permission ) ;
        //}
        //catch ( java.security.AccessControlException ace )
        //{
        //    // TODO: Handle permissions denied.
        //}
        #if COMPILE_FOR_MICROSOFT
        #else
        try 
        {
            netscape.security.PrivilegeManager.enablePrivilege( "TerminalEmulator" ) ;
            netscape.security.AppletSecurity.enablePrivilege( "TerminalEmulator" ) ;
        }
        catch ( netscape.security.ForbiddenTargetException fte1 )
        {
            msg = new String( fte1.toString( ) ) ; 
            status = STATUS_ERROR ;
            return ;
        }
        #endif
        
        /*
        #if COMPILE_FOR_MICROSOFT
        SecurityManager security = System.getSecurityManager( ) ;
        if ( security != null )
        {
            try 
            {
                security.checkConnect( htmlParams.illServerAddress, htmlParams.illServerPort ) ;
            }
            catch ( SecurityException se )
            {
                msg = new String( "Socket permission denied: " + se.toString( ) + "\n" ) ;
                status = STATUS_ERROR ;
                return ;
            }
        }
        else
        {
            msg = new String( "The security manager for the client computer could not be obtained; the request could not be send.\n" ) ;
            status = STATUS_ERROR ;
            return ;
        }
        #endif
        */

        // Establish connection to host server. Failure to connect is considered
        // a fatal error; no transaction can take place. If this occurs, terminate
        // request with status 2.
        try 
        {
            connection = new Socket( htmlParams.illServerAddress, htmlParams.illServerPort ) ;
            input = new DataInputStream( connection.getInputStream( ) ) ;
            output = new DataOutputStream( connection.getOutputStream( ) ) ;
        }
        catch ( UnknownHostException openUHE )
        {
            msg = new String( "An error occurred while establishing the network connection: " + openUHE.toString( ) ) ;
            status = STATUS_ERROR ;
            return ;
        }
        catch ( IOException openIOE )
        {
            msg = new String( "An error occurred while establishing the network connection: " + openIOE.toString( ) ) ;
            status = STATUS_ERROR ;
            return ;
        }
        catch ( Exception fatal )
        {
            msg = new String( "An error occurred while establishing the network connection: " + fatal.toString( ) ) ;
            status = STATUS_ERROR ;
            return ;
        }
        
        
        //
        // Loop through the requests until all items have been submitted.
        //
        
        for ( int requestNumber = 0 ; requestNumber < requestList.size( ) ; requestNumber++ )
        {            
            RequestInformation item = ( RequestInformation ) requestList.elementAt( requestNumber ) ;
            if ( item.request_type == BOOK_REQUEST )
            {
                msg += new String( "\"" + item.title + "\"" + ( !isEmpty( item.author ) ? " by " + item.author : "" ) + ":  " ) ;
            }
            else
            {
                msg += new String( "\"" + item.title_of_article + "\" in " + item.title + ( !isEmpty( item.author ) ? " by " + item.author : "" ) + ":  " ) ;
            }

            
            // Create a new ISO ILL request record with the input data.
            request = new IsoIllRequest( ) ;
            request.service_date = ILL_Date.getFormattedDate( ) ;
            request.transaction_qualifier = new String( htmlParams.librarySymbol + ( new Date( ) ).getTime( ) ) ;
            request.transaction_group_qualifier = new String( htmlParams.librarySymbol + "-ILL-APPLET" ) ;
            request.user_pid = new String( "AppletUser" ) ;
            request.requester_id = htmlParams.librarySymbol ;
            request.authorization = htmlParams.authorization ;
            request.password = htmlParams.password ;
            request.delivery_name = htmlParams.deliveryName ;
            request.delivery_extension = htmlParams.deliveryExtension ;
            request.delivery_street_no = htmlParams.deliveryStreet ;
            request.delivery_po_box = htmlParams.deliveryPOBox ;
            request.delivery_city = htmlParams.deliveryCity ;
            request.delivery_region = htmlParams.deliveryState ;
            request.delivery_country = htmlParams.deliveryCountry ;
            request.delivery_postal_code = htmlParams.deliveryZipCode ;
            request.delivery_service = htmlParams.deliveryService ;
            request.electronic_delivery_description = htmlParams.electronicService ;
            
            // The fax and email addresses are not included if it is a book request.
            // This is due to OCLC including these values in other fields, not specified
            // by the standard.
            request.fax_address = item.request_type == BOOK_REQUEST ? "" : htmlParams.libraryFax ;
            request.email_address = item.request_type == BOOK_REQUEST ? "" : htmlParams.libraryEmail ;
            //request.billing_name ;
            //request.billing_extension ;
            //request.billing_street_no ;
            //request.billing_po_box ;
            //request.billing_city ;
            //request.billing_region ;
            //request.billing_country ;
            //request.billing_postal_code ;
            request.need_before_date = item.need_before_date ;
            request.client_name = userProfile.full_name ;
            request.client_status = userProfile.status ;
            request.client_identifier = userProfile.id ;
            request.client_department = userProfile.department ;
            request.patron_id = userProfile.id ;
            request.patron_full_name = userProfile.full_name ;
            //request.patron_first_name ;
            //request.patron_last_name ;
            //request.patron_initials ;
            //request.patron_title ;
            //request.patron_suffix ;
            //request.patron_ssn ;
            //request.p_home_extension ;
            request.p_home_street_no = userProfile.home_street_address ;
            request.p_home_po_box = userProfile.home_po_box ;
            request.p_home_city = userProfile.home_city ;
            request.p_home_region = userProfile.home_state ;
            request.p_home_country = userProfile.home_country ;
            request.p_home_postal_code = userProfile.home_postal_code ;
            //request.p_work_extension ;
            //request.p_work_street_no ;
            //request.p_work_po_box ;
            //request.p_work_city ;
            //request.p_work_region ;
            //request.p_work_country ;
            //request.p_work_postal_code ;
            request.patron_phone = userProfile.phone ;
            request.patron_email = userProfile.email ;
            request.patron_fax = userProfile.fax ;
            //request.patron_pager ;
            request.patron_status = userProfile.status ;
            request.patron_department = userProfile.department ;
            request.patron_notes = item.patron_notes + "; " + item.source + "; " + item.source_details ;
            //request.patron_monetary_value ;
            request.held_medium_type = item.held_medium_type ;
            request.call_number = item.call_number ;
            request.author = item.request_type == BOOK_REQUEST ? item.author : "" ;
            request.title = item.title ;
            request.sub_title = item.sub_title ;
            //request.sponsoring_body ;
            request.place_of_publication = item.place_of_publication ;
            request.publisher = item.publisher ;
            //request.series_title_number ;
            request.volume = item.volume ;
            request.issue = item.issue ;
            //request.affiliations ;
            request.source = new String( "BWilhelm" ) ;
            request.edition = item.edition ;
            request.publication_date = item.request_type == BOOK_REQUEST ? item.publication_date : "" ;
            request.publication_date_of_component = item.request_type == PERIODICAL_REQUEST ? item.publication_date : "" ;
            request.author_of_article = item.request_type == PERIODICAL_REQUEST ? item.author : "" ;
            request.title_of_article = item.request_type == PERIODICAL_REQUEST ? item.title_of_article : "" ;
            request.pagination = item.pagination ;
            request.isbn = item.isbn ;
            request.issn = item.issn ;
            request.oclc_no = item.oclc_no ;
            request.verification_reference_source = item.verification_reference_source ;
            request.uniform_title = item.uniform_title ;
            request.dissertation = item.dissertation ? "YES" : "NO" ;
            //request.account_number ;
            request.currency_code = "USD" ;
            request.monetary_value = htmlParams.maxCost ;
            //request.payment_method ;
            request.copyright_compliance = new String( "ccg" ) ;
            request.send_to_list = htmlParams.lenderList ;
            request.requester_note = item.request_type == BOOK_REQUEST ? htmlParams.bookNote : htmlParams.periodicalNote ;
            request.oclc_ill_service_type = htmlParams.illServiceType ;
            request.ill_service_type = item.request_type == BOOK_REQUEST ? LOAN_ST : COPY_NON_RETURNABLE_ST ;
            request.preference = ORDERED ;
            request.change_send_to = 1 ;
            
            // Build the encoded ISO10161 request.
            berRequest = request.BuildIsoIllRequest( ) ;
            
            
            // Send the request to the output connection.
            try 
            {
                berRequest.writeBerString( output ) ;
            }
            catch ( IOException requestIOE )
            {
                msg += new String( "An error occurred while sending the item:  " + requestIOE.toString( ) ) ;
                msg += new String( "\n\n" ) ;
                status = STATUS_ERROR ;
                continue ;
            }
            
            // Get the request response.
            try 
            {
                berResponse = new BerString( input ) ;
            }
            catch ( Exception responseException )
            {
                msg += new String( "An internal error occurred while receiving the request response:  " +
                                   responseException.toString( ) ) ;
                msg += new String( "\n\n" ) ;
                status = STATUS_ERROR ;
                continue ;
            }
            
            // Create the APDU for the request response.
            apdu = new IsoIllApdu( berResponse ) ;
            
            // Decipher the APDU response.
            switch ( apdu.type )
            {
            // If the request is sent to the first lender, then ILL Direct Request responds with an 
            // ISO 10161 Status-or-Error Report that contains statusReport. If the request is
            // rejected, then ILL Direct Request responds with an ISO 10161 Status-or-Error Report
            // that contains errorReport. The content of errorReport depends on why the request was
            // rejected.
            case STATUS_OR_ERROR_REPORT_APDU :
                if ( apdu.status_or_error_report.error_occurred == true )
                {
                    msg += new String( "Your request could not be processed. Please try again later. " ) ;
                    status = ( status != STATUS_ERROR ? STATUS_WARNING : STATUS_ERROR ) ;
                }
                else
                {
                    //msg += new String( "The host issued a status report while processing. " ) ;
                    msg += new String( "Your request was received and is being processed. " ) ;
                }
                
                /*
                switch ( apdu.status_or_error_report.current_state )
                {
                case NOT_SUPPLIED_CS :                    msg += new String( "The host indicates that the item is not supplied. " ) ;                    break ;                    
                case PENDING_CS :                    msg += new String( "The host indicates that the item is pending. " ) ;                    break ;                    
                case IN_PROCESS_CS :                    msg += new String( "The host indicates that the item is in process. " ) ;                    break ;                    
                case FORWARD_CS :                    msg += new String( "The host indicates that the item is being forwarded to the first available lender. " ) ;                    break ;                    
                case CONDITIONAL_CS :                    msg += new String( "The host indicates that the item is being conditionally filled. " ) ;                    break ;                    
                case CANCEL_PENDING_CS :                    msg += new String( "The host indicates that the item is pending cancellation. " ) ;                    break ;                    
                case CANCELLED_CS :                    msg += new String( "The host indicates that the item has been cancelled. " ) ;                    break ;                    
                case SHIPPED_CS :                    msg += new String( "The host indicates that the item is being shipped. " ) ;                    break ;                    
                case RECEIVED_CS :                    msg += new String( "The host indicates that the item has been received. " ) ;                    break ;                    
                case RENEW_PENDING_CS :                    msg += new String( "The host indicates that the item is pending renewal. " ) ;                    break ;                    
                case NOT_RECEIVED_OVERDUE_CS :                    msg += new String( "The host indicates that the item is overdue and has not been received. " ) ;                    break ;                    
                case RENEW_OVERDUE_CS :                    msg += new String( "The host indicates that the item is overdue and has been renewed. " ) ;                    break ;                    
                case OVERDUE_CS :                    msg += new String( "The host indicates that the item is overdue. " ) ;                    break ;                    
                case RETURNED_CS :                    msg += new String( "The host indicates that the item has been returned. " ) ;                    break ;                    
                case CHECKED_IN_CS :                    msg += new String( "The host indicates that the item has been checked in. " ) ;                    break ;                    
                case RECALL_CS :                    msg += new String( "The host indicates that the item has been recalled. " ) ;                    break ;                    
                case LOST_CS :                    msg += new String( "The host indicates that the item has been lost. " ) ;                    break ;                    
                case UNKNOWN_CS :
                default :                    msg += new String( "The host response is unknown. " ) ;                    break ;
                }
                
                if ( !apdu.status_or_error_report.errors.isEmpty( ) )
                {
                    msg += new String( "REPORTED ERRORS: " ) ;
                    for ( int errorsIndex = 0 ; errorsIndex < apdu.status_or_error_report.errors_count ; errorsIndex++ )
                    {
                        msg += new String( ( String ) apdu.status_or_error_report.errors.elementAt( errorsIndex ) ) ;
                        if ( ++errorsIndex != apdu.status_or_error_report.errors_count - 1 )
                        {
                            msg += new String( "; " ) ;
                        }
                        else
                        {
                            msg += new String( "." ) ;
                        }
                    }
                }
                
                break ;
                */
                
            // If the request is put in the Review File, then ILL Direct Request responds with an ISO 10161
            // ILL Answer.
            case ILL_ANSWER_APDU :
                msg += new String( "Your request was received and is being processed. " ) ;
                /*
                switch ( apdu.ill_answer.transaction_results )
                {
                case CONDITIONAL_TR :                    msg += new String( "The request has been conditionally accepted.  " ) ;                    break ;                    
                case RETRY_TR :
                    // TODO: Handle a retry message.                    break ;                    
                case UNFILLED_TR : 
                    //msg += new String( "The host indicates that the request is unfilled:  " ) ;
                    msg += new String( "The host indicates that " ) ;
                                        switch ( apdu.ill_answer.results_explanation )                    {                    case IN_USE_ON_LOAN_RU :
                        msg += new String( "the item is on loan.  " ) ;                        break ;                        
                    case IN_PROCESS_RU :                        msg += new String( "the item is in processing.  " ) ;                        break ;                        
                    case LOST_RU :                        msg += new String( "the item has been lost.  " ) ;                        break ;                        
                    case NON_CIRCULATING_RU :                        msg += new String( "the item is non-circulating.  " ) ;                        break ;                        
                    case NOT_OWNED_RU :                        msg += new String( "the item is not owned.  " ) ;                        break ;                        
                    case ON_ORDER_RU :                        msg += new String( "the item is on order.  " ) ;                        break ;                        
                    case VOLUME_ISSUE_NOT_YET_AVAILABLE_RU :                        msg += new String( "the volume/issue is not yet available.  " ) ;                        break ;                        
                    case AT_BINDERY_RU :                        msg += new String( "the item is at the bindery.  " ) ;                        break ;                        
                    case LACKING_RU :                        msg += new String( "the target lender is lacking the item.  " ) ;                        break ;                        
                    case NOT_ON_SHELF_RU :                        msg += new String( "the item is not on the shelf.  " ) ;                        break ;                        
                    case ON_RESERVE_RU :                        msg += new String( "the item is on reserve.  " ) ;                        break ;                        
                    case POOR_CONDITION_RU :                        msg += new String( "the item is in poor condition.  " ) ;                        break ;                        
                    case COST_EXCEEDS_LIMIT_RU :                        msg += new String( "the cost for the item exceeds the specified limit.  " ) ;                        break ;                        
                    case CHARGES_RU :                        msg += new String( "there are charges for this item.  " ) ;                        break ;                        
                    case PREPAYMENT_REQUIRED_RU :                        msg += new String( "prepayment for this item is required.  " ) ;                        break ;                        
                    case LACKS_COPYRIGHT_COMPLIANCE_RU :                        msg += new String( "copyright compliance for this item is lacking.  " ) ;                        break ;                        
                    case NOT_FOUND_AS_CITED_RU :                        msg += new String( "the item is not found as cited.  " ) ;                        break ;                        
                    case LOCATIONS_NOT_FOUND_RU :                        msg += new String( "the specified locations are not found.  " ) ;                        break ;                        
                    case ON_HOLD_RU :                        msg += new String( "the item is on hold.  " ) ;                        break ;                        
                    case POLICY_PROBLEM_RU :                        msg += new String( "a policy problem exists in lending this item.  " ) ;                        break ;                        
                    case MANDATORY_MESSAGING_NOT_SUPPORTED_RU :                        msg += new String( "mandatory messaging is not supported.  " ) ;                        break ;                        
                    case EXPIRY_NOT_SUPPORTED_RU :                        msg += new String( "expiry is not supported.  " ) ;                        break ;                        
                    case REQUESTED_DELIVERY_SERVICES_NOT_SUPPORTED_RU :                        msg += new String( "requested delivery services are not supported.  " ) ;                        break ;                        
                    case PREFERRED_DELIVERY_TIME_NOT_POSSIBLE_RU :                        msg += new String( "preferred delivery time is not possible.  " ) ;                        break ;                        
                    case OTHER_RU :                        msg += new String( "an uncertain response message was received.  " ) ;                        break ;                        
                    case RESPONDER_SPECIFIC_RU :
                        msg += new String( "a responder specific message was received.  " ) ;
                        break ;
                        
                    default :
                        msg += new String( "no reason is given.  " ) ;
                        break ;
                    }                    
                    if ( request.oclc_ill_service_type != DIRECT_TO_REVIEW_SERVICE )
                    {                        status = ( status != STATUS_ERROR ? STATUS_WARNING : STATUS_ERROR ) ;
                    }
                    break ;                    
                case LOCATIONS_PROVIDED_TR :                    msg += new String( "The host indicates that locations have been provided for the item.  " ) ;                    break ;                    
                case WILL_SUPPLY_TR :                    msg += new String( "The host indicates that the item will be supplied.  " ) ;                    break ;                    
                case HOLD_PLACED_TR :                    msg += new String( "The host indicates that a hold has been placed on the item.  " ) ;                    break ;                    
                case ESTIMATE_TR :
                    // TODO: Find out what this means.
                    break ;
                                    default :                    msg += new String( "The request was successfully submitted, but the host did not indicate any condition.  " ) ;                    break ;
                }
                
                if ( !apdu.ill_answer.reasons_in_review.isEmpty( ) )
                {
                    msg += new String( "REASONS IN REVIEW:  " ) ;
                    for ( int reasonsIndex = 0 ; reasonsIndex < apdu.ill_answer.reasons_in_review_count ; reasonsIndex++ )
                    {
                        msg += new String( ( String ) apdu.ill_answer.reasons_in_review.elementAt( reasonsIndex ) ) ;
                        if ( reasonsIndex != apdu.ill_answer.reasons_in_review_count - 1 )
                        {
                            msg += new String( "; " ) ;
                        }
                        else
                        {
                            msg += new String( "." ) ;
                        }
                    }
                }
                
                break ;
                */
                
            default :
                msg += new String( "The request was successfully submitted, but the host did not properly indicate its condition.  Contact your local library. " ) ;
                break ;
            }
            
            msg += new String( "\n\n" ) ;
        }

        // Close the network and i/o connections.
        try 
        {
            input.close( ) ;
            output.close( ) ;
            connection.close( ) ;
        }
        catch ( IOException closeIOE )
        {
            // TODO: Close gracefully.
        }
        
        #if COMPILE_FOR_MICROSOFT
        #else
        try 
        {
            netscape.security.AppletSecurity.enablePrivilege( "SuperUser" ) ;
            netscape.security.PrivilegeManager.disablePrivilege( "SuperUser" ) ;
        }
        catch ( netscape.security.ForbiddenTargetException fte2 )
        {
            // do nothing.
        }
        #endif
        
    }
    
    private boolean isEmpty( String s )
    { return ( s == null || s.equals( "" ) ) ; }
}
