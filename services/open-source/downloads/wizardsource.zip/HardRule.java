/*-----------------------------------------------------------------------------
HardRule.java

Written by Bryan Wilhelm (bryan_wilhelm@hotmail.com)
Created on September 06, 1999

TODO:
===============================================================================

KNOWN ISSUES:
===============================================================================

MODIFICATION HISTORY:
===============================================================================
-----------------------------------------------------------------------------*/

import java.awt.Canvas ;
import java.awt.Color ;
import java.awt.Graphics ;

public class HardRule 
       extends Canvas
{
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Constructor
    //
    public HardRule( )
    {
        super( ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Paint and Update
    //
    public void paint( Graphics g )
    {
        g.setColor( Color.gray ) ;
        g.drawLine( 0, 0, 600, 0 ) ;
        g.setColor( Color.white ) ;
        g.drawLine( 0, 1, 600, 1 ) ;
    }
    
    public void update( Graphics g )
    {
        g.setColor( Color.gray ) ;
        g.drawLine( 0, 0, 600, 0 ) ;
        g.setColor( Color.white ) ;
        g.drawLine( 0, 1, 600, 1 ) ;
    }
}
