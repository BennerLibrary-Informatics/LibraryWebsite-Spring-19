/*
I had to make this class because some people insist on using inferior operating
systems. The Linux GDI is limited and doesn't have provide a default 
implementation for buttons.
*/

import java.awt.* ;

public class LinuxSafeButton
    extends Button
{
    public LinuxSafeButton( String str )
    {
        super( str ) ;
        setBackground( Color.gray ) ;
    }
}