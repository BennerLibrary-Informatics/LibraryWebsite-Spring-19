/*-----------------------------------------------------------------------------
IsoIllApdu.java

Written by Bryan Wilhelm
Created on August 29, 1999

Represents the response from the ILL server.

TODO:
=============================================================================

Known Bugs:
=============================================================================

Modification History
=============================================================================
-----------------------------------------------------------------------------*/
public class IsoIllApdu implements ILL_API, ILL_ASN
{
    int type;    IsoIllStatusOrErrorReport status_or_error_report ;    IsoIllAnswer ill_answer ;    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Constructor
    //
    //  this function returns a structure which contains the relevant information
    //  from the ISO ILL APDU received as a response; the ber data and length are
    //  passed to the function
    //
    //  the ISO ILL APDU will either be an ISO Status-Or-Error-Report or an
    //  ISO ILL-Answer:
    //
    //  Condition                             ISO ILL APDU
    //  --------------------------------      -----------------------------
    //  Request was sent to first lender      ISO Status-Or-Error-Report
    //  Request was put in Review File        ISO ILL-Answer
    //  Request was rejected                  ISO Status-Or-Error-Report
    //    public IsoIllApdu( BerString berString )    {        DataDir dir = new DataDir( berString ) ;
        type = dir.fldid( ) ;

        if ( type == STATUS_OR_ERROR_REPORT_APDU )
            status_or_error_report = new IsoIllStatusOrErrorReport( dir ) ;
        else if ( type == ILL_ANSWER_APDU )            ill_answer = new IsoIllAnswer( dir ) ;
        else
        {            // TODO: Find an appropriate solution for this condition.
        }
    }
}

