/*-----------------------------------------------------------------------------
ILL_Main.java

Written by Bryan Wilhelm
Created on June 30, 1999

This is the main applet class for a web client for request interlibrary loan
materials through OCLC.

TODO:
=============================================================================
* Create a method for billing library or customer. Right now applet assumes
  no incured costs for the requested transaction.
* Find a suitable method for enforcing maximum field lengths. Currently no
  such limits are enforced by the applet.
* Currently when the ViewListBox is emptied, the View Requests and Submit
  Requests buttons are disabled. However the view stays at the View Requests
  page. Decide whether this is right, or if it should go to the interim page.
* Disable the page if the user does not have an address specified by the
  Valid-User applet parameter. Send them to the Cancel-Page parameter.

Known Bugs:
=============================================================================

Modification History
=============================================================================
06/30/1999  File opened.
07/05/1999  Redesigned the applet interface with a menu panel and a main panel.
07/06/1999  Finished with first draft of user profile panel.
07/07/1999  Finished with first draft of book request panel.
            Added the four URL applet parameters.
07/15/1999  Finished with first draft of About and View Requests panel.
08/04/1999  Created the security signature and certificates with keytool and
            jarsigner.
08/06/1999  All principle code is completed.
08/12/1999  Changed security tools from jarsigner to signcode.
08/17/1999  Version 1.0 (BETA 1) completed. Testing to begin during Fall
            Semester. Security issues remain with applet security. Only 
            Microsoft Internet Explorer is responding correctly to the 
            security signature.
08/23/1999  Authorization and Password applet parameters were removed from 
            the parameter list and replaced by Access-Security-Matrix.
08/26/1999  Minimum system requirements established: IE 4.01 SP1 and 
            Netscape 4.51.
09/01/1999  Still no successful networking test. John Rutherford had his test
            hang which suggests a down server.
09/03/1999  Changed compilers from Sun's javac to Microsoft's jvc. This change
            was made since there will need to be two separate applet archives
            for Microsoft Internet Explorer and Netscape Navigator, which now
            allows me to utilize browser specific features. Jvc allows me to
            make separate compilation for each browser.
-----------------------------------------------------------------------------*/

import java.applet.Applet ;
import java.applet.AppletContext ;
import java.awt.Checkbox ;
import java.awt.CheckboxGroup ;
import java.awt.Choice ;
import java.awt.Color ;
import java.awt.Cursor ;
import java.awt.Font ;
import java.awt.Frame ;
import java.awt.Graphics ;
import java.awt.Image ;
import java.awt.Label ;
import java.awt.List ;
import java.awt.Panel ;
import java.awt.TextArea ;
import java.awt.TextField ;
import java.awt.Toolkit ;
import java.awt.event.ActionEvent ;
import java.awt.event.ActionListener ;
import java.awt.event.ItemEvent ;
import java.awt.event.ItemListener ;
import java.awt.event.MouseEvent ;
import java.awt.event.MouseListener ;
import java.io.IOException ;
import java.net.InetAddress ;
import java.net.MalformedURLException ;
import java.net.UnknownHostException ;
import java.net.URL ;
import java.text.DateFormat ;
import java.util.Calendar ;
import java.util.Date ;
import java.util.StringTokenizer ;
import java.util.Vector ;

#if COMPILE_FOR_MICROSOFT
import com.ms.wfc.ui.DialogResult ;
import com.ms.wfc.ui.MessageBox ;
#endif

public class ILL_Main 
       extends Applet 
       implements ActionListener, MouseListener, ItemListener,
                  ILL_API, ILL_Constants
{
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Class variables
    //
    
    //  HTML parameters
    private ILL_HtmlParameters htmlParams ;
    
    // Applet panels
    private Panel   menuPanel ;
    private Panel   mainPanel ;
    
    // Menu components
    private LinuxSafeButton  userProfileButton ;
    private LinuxSafeButton  bookRequestButton ;
    private LinuxSafeButton  periodicalRequestButton ;
    private LinuxSafeButton  viewRequestsButton ;
    private LinuxSafeButton  submissionButton ;
    private LinuxSafeButton  aboutButton ;
    private LinuxSafeButton  cancelButton ;
    
    // User profile components
    private TextField   userFullNameField ;
    private TextField   userIDField ;
    private TextField   userStreetAddressField ;
    private TextField   userPOBoxAddressField ;
    private TextField   userCityField ;
    private TextField   userStateField ;
    private TextField   userZIPField ;
    private TextField   userEmailField ;
    private TextField   userPhoneField ;
    private TextField   userFaxField ;
    private CheckboxGroup userStatus = new CheckboxGroup( ) ;
    private Checkbox    userStatusFaculty ;
    private Checkbox    userStatusStaff ;
    private Checkbox    userStatusUndergraduate ;
    private Checkbox    userStatusGraduate ;
    private Checkbox    userStatusOther ;
    private TextField   userStatusOtherField ;
    private TextField   userDepartmentField ;
    private LinuxSafeButton      userSaveProfileButton ;
    
    // Shared book and periodical request components
    private TextField   requestAuthorField ;            
    private TextField   requestTitleField ;             
    private TextField   requestVolumeField ;
    private TextField   requestPublicationDateField ;
    private CheckboxGroup requestVerified = new CheckboxGroup( ) ;
    private Checkbox    requestVerifiedYes ;
    private Checkbox    requestVerifiedNo ;
    private TextField   requestNeedBeforeField ;
    private Choice      requestSourceOfCitationChoice ;
    private Label       requestDetailsOfCitationLabel ;
    private TextField   requestDetailsOfCitationField ;
    private TextArea    requestPatronNotesTextArea ;
    private RequestInformation requestInformation ;
    
    // Book request components
    private TextField   bookSubTitleField ;
    private TextField   bookUniformTitleField ;
    private TextField   bookPlaceOfPublicationField ;
    private TextField   bookPublisherField ;
    private TextField   bookEditionField ;
    private TextField   bookISBNField ;
    private TextField   bookOCLCNumberField ;
    private TextField   bookERICNumberField ;
    private TextField   bookCallNumberField ;
    private Checkbox    bookDissertationCheckbox ;
    private Checkbox    bookConferenceCheckbox ;
    private LinuxSafeButton      bookOnlineCatalogButton ;
    private LinuxSafeButton      bookSaveRequestButton ;
    
    // Periodical request components
    private TextField   perArticleTitleField ;
    private TextField   perISSNField ;
    private TextField   perIssueField ;
    private TextField   perPaginationField ;
    private LinuxSafeButton      perHoldingsButton ;
    private CheckboxGroup perCopyAgree = new CheckboxGroup( ) ;
    private Checkbox    perCopyAgreeYes ;
    private Checkbox    perCopyAgreeNo ;
    private LinuxSafeButton      perSaveRequestButton ;
    
    // View request components
    private LinuxSafeButton      viewDeleteAllButton ;
    private LinuxSafeButton      viewDeleteButton ;
    private LinuxSafeButton      viewEditButton ;
    private List        viewListBox ;
    
    // Submit request components
    private TextArea    submitResults ;
    private LinuxSafeButton      submitSubmissionComplete ;
    
    // About components
    private Label       aboutEmailLabel ;
    
    // Request information list
    public  UserProfile userProfile = new UserProfile( ) ;
    public  Vector      requestInformationList = new Vector( ) ; 
    
    // Internal applet variables
    private String  errorMessage ;
    private int     numRequests ;
                        
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Applet init( ) - This is the entry point to the applet.
    //
    public void init( )
    {
        // Remove all layout managers from the applet; components are placed
        // on the applet manually.
        setLayout( null ) ;
        
        // Get the parameters from the HTML document.
        if ( !getHTMLParameters( ) )
        {
            //
            // If an error occurs, the list of missing parameters will be
            // in the errorMessage variable.
            //

            // Set the background and foreground colors.
            setBackground( htmlParams.mainBgColor ) ;
            setForeground( htmlParams.mainFgColor ) ;
            
            // Create the error message title.
            Font titleFont = new Font( "Serif", Font.BOLD, 32 ) ;
            Label titleLabel = new Label( "Error Occurred" ) ;
            titleLabel.setFont( titleFont ) ;
            add( titleLabel ) ;
            titleLabel.setBounds( BOUNDARY_WIDTH, 
                                  0, 
                                  APPLET_WIDTH - 2 * BOUNDARY_WIDTH, 
                                  36 ) ;
            
            // Create the error message. Use the default font.
            Label errorLabel = new Label( "An error occurred while loading the Java applet." ) ;
            add( errorLabel ) ;
            errorLabel.setBounds( BOUNDARY_WIDTH, 
                                  48, 
                                  APPLET_WIDTH - 2 * BOUNDARY_WIDTH, 
                                  LABEL_HEIGHT ) ;
            Label problemLabel = new Label( "The following required information is missing:" ) ;
            add( problemLabel ) ;
            problemLabel.setBounds( BOUNDARY_WIDTH, 
                                    64, 
                                    APPLET_WIDTH - 2 * BOUNDARY_WIDTH, 
                                    LABEL_HEIGHT ) ;
            Label missingLabel = new Label( errorMessage ) ;
            add( missingLabel ) ;
            missingLabel.setBounds( 3 * BOUNDARY_WIDTH, 
                                    84, 
                                    APPLET_WIDTH - 2 * BOUNDARY_WIDTH, 
                                    LABEL_HEIGHT ) ;
            Label actionLabel = new Label( "Report this problem to a librarian as soon as possible." ) ;
            add( actionLabel ) ;
            actionLabel.setBounds( BOUNDARY_WIDTH, 
                                   116, 
                                   APPLET_WIDTH - 2 * BOUNDARY_WIDTH, 
                                   LABEL_HEIGHT ) ;
            
            // Display the message
            setVisible( true ) ;
            
            return ;
        }

        // Validate the user to use this program.
        if ( !isUserValid( ) )
        {
            /*
            #if COMPILE_FOR_MICROSOFT
            MessageBox.show(
                "Access to this program has been denied.\n" +
                "The following explanation has been given:\n\n" +
                errorMessage,
                "Access Denied",
                MessageBox.ICONHAND | MessageBox.OK
            ) ;
            #endif
            
            // Try to go to the return location given by the HTML document.
            try
            {
                getAppletContext( ).showDocument( new URL( htmlParams.cancelURL ) ) ;
            }
            
            // If failed to show new document, hide the applet from the user.
            // TODO: Find a better exception recovery method.
            catch ( MalformedURLException malformedURLException1 )
            {
                #if COMPILE_FOR_MICROSOFT
                MessageBox.show(
                    "The specified URL is not valid. The following explanation was given:" +
                    malformedURLException1,
                    "Malformed URL Exception",
                    MessageBox.ICONERROR | MessageBox.OK
                ) ;
                #endif
                setVisible( false ) ;
            }
            
            return ;
            */
        }
        
        // Set the background and foreground colors.
        setBackground( htmlParams.mainBgColor ) ;
        setForeground( htmlParams.mainFgColor ) ;
        
        // 
        // Create the menu bar panel.
        //
        
        // Instantiate the menu panel.
        menuPanel = new Panel( null ) ;
        createMenuPanel( ) ;
        
        // Add the menu panel to the applet
        add( menuPanel ) ;

        //
        // Create the main panel; initially contains the user profile format.
        //
        
        // Instantiate the menu panel.
        mainPanel = new Panel( null ) ;
        
        // Initialize the menu panel properties.
        mainPanel.setBounds( MENU_BAR_WIDTH, 0, 
                             APPLET_WIDTH - MENU_BAR_WIDTH, 
                             APPLET_HEIGHT ) ;
        mainPanel.setBackground( htmlParams.mainBgColor ) ;
        mainPanel.setForeground( htmlParams.mainFgColor ) ;
        
        // Add the main panel to the applet
        add( mainPanel ) ;
        
        // Create the main panel components and add to the listeners.
        createUserProfilePanel( ) ;
        
        // Initially give the focus to the text field for the user's name.
        userFullNameField.requestFocus( ) ;

        // Display the applet on the page.
        setVisible( true ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  paint - used to draw imaged on the applet surface; this is the only
    //  method where that can be done.
    //
    public void paint( Graphics g )
    {
        Graphics mainPanelGraphics = mainPanel.getGraphics( ) ;
        mainPanel.update( mainPanelGraphics ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  The action event procedure that processes all events.
    //
    public void actionPerformed( ActionEvent actionEvent )
    {
        //
        // Local variables
        //
        boolean errorOccurred = false ;
        
        #if COMPILE_FOR_MICROSOFT
        #else
        ErrorMessageDialog errorMessageDialog ;
        #endif
        
        //
        // Handle the menu bar buttons
        //
        
        // User Profile Button
        if ( actionEvent.getSource( ) == userProfileButton )
        {
            createUserProfilePanel( ) ;
        }
        
        // Book Request Button
        else if ( actionEvent.getSource( ) == bookRequestButton )
        {
            createBookRequestPanel( requestInformation = new RequestInformation( ) ) ;
            // Note that requestInformation is passed by reference.
        }
        
        // Periodical Request Button
        else if ( actionEvent.getSource( ) == periodicalRequestButton )
        {
            createPeriodicalRequestPanel( requestInformation = new RequestInformation( ) ) ;
            // Note that requestInformation is passed by reference.
        }
        
        // View Requests Button
        else if ( actionEvent.getSource( ) == viewRequestsButton )
        {
            createViewRequestsPanel( ) ;
        }
        
        // Submit Requests Button
        else if ( actionEvent.getSource( ) == submissionButton )
        {
            createSubmissionPanel( ) ;
        }
        
        // About Button
        else if ( actionEvent.getSource( ) == aboutButton )
        {
            createAboutPanel( ) ;
        }
        
        // Cancel Button
        else if ( actionEvent.getSource( ) == cancelButton )
        {
            // Try to go to the return location given by the HTML document.
            try
            {
                getAppletContext( ).showDocument( new URL( htmlParams.cancelURL ) ) ;
            }
            
            // If failed to show new document, hide the applet from the user.
            // TODO: Find a better exception recovery method.
            catch ( MalformedURLException malformedURLException1 )
            {
                setVisible( false ) ;
            }
        }
        
        //
        // Handle the main panel buttons
        //
        
        // User Profile Save Settings Button
        else if ( actionEvent.getSource( ) == userSaveProfileButton )
        {
            // Check for required fields. If a required field is missing then
            // post an error message. 
            // Each field must be check one at a time. If the individual field
            // is missing color it yellow and set the error flag. If not the
            // field must be reset to white since the user may not be on their
            // first time around.
            errorMessage = null ;

            // State
            if ( userStatus.getSelectedCheckbox( ) == null )
            {
                errorOccurred = true ;
                if ( isEmpty( errorMessage ) )
                {
                    errorMessage = new String( "Status at " + htmlParams.institutionName + "\n" ) ;
                }
                else
                {
                    errorMessage += "Status at " + htmlParams.institutionName + "\n" ;
                }
                userStatusFaculty.requestFocus( ) ;
            }
            
            // Phone
            if ( isEmpty( userPhoneField.getText( ) ) )
            {
                errorOccurred = true ;
                if ( isEmpty( errorMessage ) )
                {
                    errorMessage = new String( "Phone Number\n" ) ;
                }
                else
                {
                    errorMessage += "Phone Number\n" ;
                }
                userPhoneField.setBackground( Color.yellow ) ;
                userPhoneField.requestFocus( ) ;
            }
            else
            {
                userPhoneField.setBackground( Color.white ) ;
            }
            
            // Email
            if ( isEmpty( userEmailField.getText( ) ) )
            {
                errorOccurred = true ;
                if ( isEmpty( errorMessage ) )
                {
                    errorMessage = new String( "Email Address\n" ) ;
                }
                else
                {
                    errorMessage += "Email Address\n" ;
                }
                userEmailField.setBackground( Color.yellow ) ;
                userEmailField.requestFocus( ) ;
            }
            else
            {
                userEmailField.setBackground( Color.white ) ;
            }
            
            // Address
            if ( isEmpty( userStreetAddressField.getText( ) ) &&
                 isEmpty( userPOBoxAddressField.getText( ) ) )
            {
                errorOccurred = true ;
                if ( isEmpty( errorMessage ) )
                {
                    errorMessage = new String( "Street Address or P.O. Box Address\n" ) ;
                }
                else
                {
                    errorMessage += "Street Address or P.O. Box Address\n" ;
                }
                userStreetAddressField.setBackground( Color.yellow ) ;
                userPOBoxAddressField.setBackground( Color.yellow ) ;
                userStreetAddressField.requestFocus( ) ;
            }
            else
            {
                userStreetAddressField.setBackground( Color.white ) ;
                userPOBoxAddressField.setBackground( Color.white ) ;
            }

            /*
            // User ID
            if ( isEmpty( userIDField.getText( ) ) )
            {
                errorOccurred = true ;
                userIDField.setBackground( Color.yellow ) ;
                userIDField.requestFocus( ) ;
            }
            else
            {
                userIDField.setBackground( Color.white ) ;
            }
            */
            
            // Full name
            if ( isEmpty( userFullNameField.getText( ) ) )
            {
                errorOccurred = true ;
                if ( isEmpty( errorMessage ) )
                {
                    errorMessage = new String( "Full Name\n" ) ;
                }
                else
                {
                    errorMessage += "Full Name\n" ;
                }
                userFullNameField.setBackground( Color.yellow ) ;
                userFullNameField.requestFocus( ) ;
            }
            else 
            {
                userFullNameField.setBackground( Color.white ) ;
            }
            
            //
            // If an error occurred then post the error dialog box
            // with the appropriate error message string.
            //
            if ( errorOccurred )
            {
                #if COMPILE_FOR_MICROSOFT
                MessageBox.show( 
                    "Fields marked with bold text are required.\nThe following items are missing:\n\n" + errorMessage, 
                    "User Profile Warning",
                    MessageBox.ICONWARNING | MessageBox.OK
                ) ;
                #else
                errorMessageDialog = new ErrorMessageDialog( new Frame( ), "Fields marked with bold text are required." ) ;
                #endif
                errorMessage = null ;
                return ;
            }
            
            // Check for the optional nonmember request.
            if ( !htmlParams.allowNonmemberRequests && userStatusOther.getState( ) )
            {
                #if COMPILE_FOR_MICROSOFT
                MessageBox.show(
                    "Nonmembers of the library may not use this program.",
                    "User Profile Warning",
                    MessageBox.ICONWARNING | MessageBox.OK
                ) ;
                #else
                errorMessageDialog = new ErrorMessageDialog( new Frame( ), "Nonmembers of the library may not use this program." ) ;
                #endif
                return ;
            }
            
            // If all required are filled in, then retreive the contents
            // of the text fields and fill in the user profile.
            userProfile.full_name = userFullNameField.getText( ) ;
            userProfile.id = userIDField.getText( ) ;
            userProfile.home_street_address = userStreetAddressField.getText( ) ;
            userProfile.home_po_box = userPOBoxAddressField.getText( ) ;
            userProfile.home_city = userCityField.getText( ) ;
            userProfile.home_state = userStateField.getText( ) ;
            userProfile.home_postal_code = userZIPField.getText( ) ;
            userProfile.email = userEmailField.getText( ) ;
            userProfile.phone = userPhoneField.getText( ) ;
            userProfile.fax = userFaxField.getText( ) ;
            if ( userStatus.getSelectedCheckbox( ) == userStatusOther )
            {
                if ( isEmpty( userStatusOtherField.getText( ) ) )
                {
                    userProfile.status = new String( "Other" ) ;
                }
                else
                {
                    userProfile.status = userStatusOtherField.getText( ) ;
                }
            }
            else
            {
                userProfile.status = userStatus.getSelectedCheckbox( ).getLabel( ) ;
            }
            userProfile.department = userDepartmentField.getText( ) ;

            // Create the interim message on the main panel.
            createInterimMessage( ) ;
        }
        
        // Online Book Catalog Button
        else if ( actionEvent.getSource( ) == bookOnlineCatalogButton )
        {
            try 
            {
                getAppletContext( ).showDocument( new URL( htmlParams.onlineCatalogURL ) ) ;
            }
            catch ( MalformedURLException malformedURLException2 )
            {
                // TODO: Handle bad URL.
            }
        }
        
        // Save Book Request Button
        else if ( actionEvent.getSource( ) == bookSaveRequestButton )
        {
            // Check for required fields. If a required field is missing then
            // post an error message.
            // Each field must be check one at a time. If the individual field
            // is missing color it yellow and set the error flag. If not the
            // field must be reset to white since the user may not be on their
            // first time around.
            errorMessage = null ;
            
            // Need before date
            if ( isEmpty( requestNeedBeforeField.getText( ) ) )
            {
                errorOccurred = true ;
                if ( isEmpty( errorMessage ) )
                {
                    errorMessage = new String( "The date this item is needed by\n" ) ;
                }
                else
                {
                    errorMessage += "The date this item is needed by\n" ;
                }
                requestNeedBeforeField.setBackground( Color.yellow ) ;
                requestNeedBeforeField.requestFocus( ) ;
            }
            else
            {
                requestNeedBeforeField.setBackground( Color.white ) ;
            }
            
            // Title
            if ( isEmpty( requestTitleField.getText( ) ) )
            {
                errorOccurred = true ;
                if ( isEmpty( errorMessage ) )
                {
                    errorMessage = new String( "Title of Book\n" ) ;
                }
                else
                {
                    errorMessage += "Title of Book\n" ;
                }
                requestTitleField.setBackground( Color.yellow ) ;
                requestTitleField.requestFocus( ) ;
            }
            else
            {
                requestTitleField.setBackground( Color.white ) ;
            }
            
            // Author
            if ( isEmpty( requestAuthorField.getText( ) ) )
            {
                errorOccurred = true ;
                if ( isEmpty( errorMessage ) )
                {
                    errorMessage = new String( "Author or Editor\n" ) ;
                }
                else
                {
                    errorMessage += "Author or Editor\n" ;
                }
                requestAuthorField.setBackground( Color.yellow ) ;
                requestAuthorField.requestFocus( ) ;
            }
            else
            {
                requestAuthorField.setBackground( Color.white ) ;
            }
            
            if ( errorOccurred )
            {
                #if COMPILE_FOR_MICROSOFT
                MessageBox.show(
                    "Fields marked in bold are required.\nThe following items are missing:\n\n" + errorMessage,
                    "Book Request Warning",
                    MessageBox.ICONWARNING | MessageBox.OK
                ) ;
                #else
                errorMessageDialog = new ErrorMessageDialog( new Frame( ), "Fields marked in bold are required" ) ;
                #endif
                errorMessage = null ;
                return ;
            }
            
            // Check that local catalog was checked.
            if ( requestVerified.getSelectedCheckbox( ) != requestVerifiedYes )
            {
                #if COMPILE_FOR_MICROSOFT
                MessageBox.show(
                    "You must check " + htmlParams.libraryName + " for this item.",
                    "Book Request Warning",
                    MessageBox.ICONWARNING | MessageBox.OK
                ) ;
                #else
                errorMessageDialog = new ErrorMessageDialog( new Frame( ), "You must check " + htmlParams.libraryName + " for this item." ) ;
                #endif
                return ;
            }
            
            //
            // Put the fields into the RequestInformation
            //
            requestInformation.request_type = BOOK_REQUEST ;
            requestInformation.author = requestAuthorField.getText( ) ;
            requestInformation.call_number = bookCallNumberField.getText( ) ;
            requestInformation.conference = bookConferenceCheckbox.getState( ) ;
            requestInformation.dissertation = bookDissertationCheckbox.getState( ) ;
            requestInformation.edition = bookEditionField.getText( ) ;
            requestInformation.eric_no = bookERICNumberField.getText( ) ;
            requestInformation.held_medium_type = new String( "" + PRINTED_HMT ) ;
            requestInformation.isbn = bookISBNField.getText( ) ;
            requestInformation.need_before_date = ILL_Date.getFormattedDate( requestNeedBeforeField.getText( ) ) ;
            requestInformation.oclc_no = bookOCLCNumberField.getText( ) ;
            requestInformation.patron_notes = requestPatronNotesTextArea.getText( ) ;
            requestInformation.place_of_publication = bookPlaceOfPublicationField.getText( ) ;
            requestInformation.publication_date = requestPublicationDateField.getText( ) ;
            requestInformation.publisher = bookPublisherField.getText( ) ;
            requestInformation.source = requestSourceOfCitationChoice.getSelectedItem( ) ;
            requestInformation.source_details = requestDetailsOfCitationField.getText( ) ;
            requestInformation.sub_title = bookSubTitleField.getText( ) ;
            requestInformation.verification_reference_source = new String( "YES" ) ;
            requestInformation.title = requestTitleField.getText( ) ;
            requestInformation.uniform_title = bookUniformTitleField.getText( ) ;
            requestInformation.volume = requestVolumeField.getText( ) ;
            
            // Assign the RequestInformation object to the next element of the list.
            if ( !requestInformation.requestMade )
            {
                requestInformation.requestMade = true ;
                requestInformationList.addElement( requestInformation ) ;
            }
            
            // Create the interim message on the main panel.
            createInterimMessage( ) ;
        }
        
        // Periodical Holdings Button
        else if ( actionEvent.getSource( ) == perHoldingsButton )
        {
            try 
            {
                getAppletContext( ).showDocument( new URL( htmlParams.periodicalHoldingsURL ) ) ;
            }
            catch ( MalformedURLException malformedURLException2 )
            {
                // TODO: Handle bad URL.
            }
        }
        
        // Save Periodical Request Button
        else if ( actionEvent.getSource( ) == perSaveRequestButton )
        {
            // Check for required fields. If a required field is missing then
            // post an error message.
            // Each field must be check one at a time. If the individual field
            // is missing color it yellow and set the error flag. If not the
            // field must be reset to white since the user may not be on their
            // first time around.
            errorMessage = null ;
            
            // Need before date
            if ( isEmpty( requestNeedBeforeField.getText( ) ) )
            {
                errorOccurred = true ;
                if ( isEmpty( errorMessage ) )
                {
                    errorMessage = new String( "The date this item is needed by\n" ) ;
                }
                else
                {
                    errorMessage += "The date this item is needed by\n" ;
                }
                requestNeedBeforeField.setBackground( Color.yellow ) ;
                requestNeedBeforeField.requestFocus( ) ;
            }
            else
            {
                requestNeedBeforeField.setBackground( Color.white ) ;
            }
            
            // Pagination
            if ( isEmpty( perPaginationField.getText( ) ) )
            {
                errorOccurred = true ;
                if ( isEmpty( errorMessage ) )
                {
                    errorMessage = new String( "Pages of the Article\n" ) ;
                }
                else
                {
                    errorMessage += "Pages of the Article\n" ;
                }
                perPaginationField.setBackground( Color.yellow ) ;
                perPaginationField.requestFocus( ) ;
            }
            else
            {
                perPaginationField.setBackground( Color.white ) ;
            }
            
            // Publication date
            if ( isEmpty( requestPublicationDateField.getText( ) ) )
            {
                errorOccurred = true ;
                if ( isEmpty( errorMessage ) )
                {
                    errorMessage = new String( "Publication Date\n" ) ;
                }
                else
                {
                    errorMessage += "Publication Date\n" ;
                }
                requestPublicationDateField.setBackground( Color.yellow ) ;
                requestPublicationDateField.requestFocus( ) ;
            }
            else
            {
                requestPublicationDateField.setBackground( Color.white ) ;
            }
            
            // Periodical Title
            if ( isEmpty( requestTitleField.getText( ) ) )
            {
                errorOccurred = true ;
                if ( isEmpty( errorMessage ) )
                {
                    errorMessage = new String( "Title of Periodical or Journal\n" ) ;
                }
                else
                {
                    errorMessage += "Title of Periodical or Journal\n" ;
                }
                requestTitleField.setBackground( Color.yellow ) ;
                requestTitleField.requestFocus( ) ;
            }
            else
            {
                requestTitleField.setBackground( Color.white ) ;
            }
            
            // Article Title
            if ( isEmpty( perArticleTitleField.getText( ) ) )
            {
                errorOccurred = true ;
                if ( isEmpty( errorMessage ) )
                {
                    errorMessage = new String( "Title of Article\n" ) ;
                }
                else
                {
                    errorMessage += "Title of Article\n" ;
                }
                perArticleTitleField.setBackground( Color.yellow ) ;
                perArticleTitleField.requestFocus( ) ;
            }
            else
            {
                perArticleTitleField.setBackground( Color.white ) ;
            }
            
            if ( errorOccurred )
            {
                #if COMPILE_FOR_MICROSOFT
                MessageBox.show(
                    "Fields marked in bold are required.\nThe following items are missing:\n\n" + errorMessage,
                    "Periodical Request Warning",
                    MessageBox.ICONWARNING | MessageBox.OK
                ) ;
                #else
                errorMessageDialog = new ErrorMessageDialog( new Frame( ), "Fields marked in bold are required." ) ;
                #endif
                errorMessage = null ;
                return ;
            }
            
            // Check that local catalog was checked.
            if ( requestVerified.getSelectedCheckbox( ) != requestVerifiedYes )
            {
                #if COMPILE_FOR_MICROSOFT
                MessageBox.show(
                    "You must check " + htmlParams.libraryName + " for this item.",
                    "Periodical Request Warning",
                    MessageBox.ICONWARNING | MessageBox.OK
                ) ;
                #else
                errorMessageDialog = new ErrorMessageDialog( new Frame( ), "You must check " + htmlParams.libraryName + " for this item." ) ;
                #endif
                return ;
            }
            
            // Check that the copyright agreement was agreed to.
            // Check that local catalog was checked.
            if ( perCopyAgree.getSelectedCheckbox( ) != perCopyAgreeYes )
            {
                #if COMPILE_FOR_MICROSOFT
                MessageBox.show(
                    "You must accept the copyright agreement to continue.",
                    "Periodical Request Warning",
                    MessageBox.ICONWARNING | MessageBox.OK
                ) ;
                #else
                errorMessageDialog = new ErrorMessageDialog( new Frame( ), "You must accept the copyright agreement to continue." ) ;
                #endif
                return ;
            }
            
            //
            // Put the fields into the RequestInformation
            //
            requestInformation.request_type = PERIODICAL_REQUEST ;
            requestInformation.held_medium_type = new String( "" + PRINTED_HMT ) ;
            requestInformation.need_before_date = ILL_Date.getFormattedDate( requestNeedBeforeField.getText( ) ) ;
            requestInformation.patron_notes = requestPatronNotesTextArea.getText( ) ;
            requestInformation.publication_date = requestPublicationDateField.getText( ) ;
            requestInformation.source = requestSourceOfCitationChoice.getSelectedItem( ) ;
            requestInformation.source_details = requestDetailsOfCitationField.getText( ) ;
            requestInformation.verification_reference_source = new String( "YES" ) ;
            requestInformation.title = requestTitleField.getText( ) ;
            requestInformation.volume = requestVolumeField.getText( ) ;
            requestInformation.author = requestAuthorField.getText( ) ;
            requestInformation.issn = perISSNField.getText( ) ;
            requestInformation.issue = perIssueField.getText( ) ;
            requestInformation.pagination = perPaginationField.getText( ) ;
            requestInformation.title_of_article = perArticleTitleField.getText( ) ;
            
            // Assign the RequestInformation object to the next element of the list.
            if ( !requestInformation.requestMade )
            {
                requestInformation.requestMade = true ;
                requestInformationList.addElement( requestInformation ) ;
            }
            
            // Create the interim message on the main panel.
            createInterimMessage( ) ;
        }
        
        // Delete All Button
        else if ( actionEvent.getSource( ) == viewDeleteAllButton )
        {
            requestInformationList.removeAllElements( ) ;
            numRequests = 0 ;
            viewDeleteButton.setEnabled( false ) ;
            viewEditButton.setEnabled( false ) ;
            bookRequestButton.setEnabled( true ) ;
            periodicalRequestButton.setEnabled( true ) ;
            viewRequestsButton.setEnabled( false ) ;
            submissionButton.setEnabled( false ) ;
            drawViewListBox( ) ;
        }
        
        // Delete Button
        else if ( actionEvent.getSource( ) == viewDeleteButton )
        {
            if ( viewListBox.getSelectedIndex( ) == -1 ) 
            {
                #if COMPILE_FOR_MICROSOFT
                MessageBox.show(
                    "An item must be selected to delete.",
                    "Delete Item Warning",
                    MessageBox.ICONWARNING | MessageBox.OK
                ) ;
                #else
                errorMessageDialog = new ErrorMessageDialog( new Frame( ), "An item must be selected to delete." ) ;
                #endif
                return ;
            }
            
            requestInformationList.removeElementAt( viewListBox.getSelectedIndex( ) ) ;
            
            if ( --numRequests == 0 )
            {
                viewDeleteButton.setEnabled( false ) ;
                viewEditButton.setEnabled( false ) ;
                bookRequestButton.setEnabled( true ) ;
                periodicalRequestButton.setEnabled( true ) ;
                viewRequestsButton.setEnabled( false ) ;
                submissionButton.setEnabled( false ) ;
            }
            else
            {
                bookRequestButton.setEnabled( true ) ;
                periodicalRequestButton.setEnabled( true ) ;
            }
            drawViewListBox( ) ;
        }
        
        // Edit Button or Double-click on the list box.
        else if ( actionEvent.getSource( ) == viewEditButton || 
                  actionEvent.getSource( ) == viewListBox ) 
        {
            if ( viewListBox.getSelectedIndex( ) == -1 ) 
            {
                #if COMPILE_FOR_MICROSOFT
                MessageBox.show(
                    "An item must be selected to view or edit.",
                    "View Item Warning",
                    MessageBox.ICONWARNING | MessageBox.OK
                ) ;
                #else
                errorMessageDialog = new ErrorMessageDialog( new Frame( ), "An item must be selected to view." ) ;
                #endif
                return ;
            }
            
            requestInformation = ( RequestInformation ) requestInformationList.elementAt( viewListBox.getSelectedIndex( ) ) ;
            
            if ( requestInformation.request_type == BOOK_REQUEST )
            {
                createBookRequestPanel( requestInformation ) ;
            }
            else
            {
                createPeriodicalRequestPanel( requestInformation ) ;
            }
        }
        
        // Request Submission Completed
        else if ( actionEvent.getSource( ) == submitSubmissionComplete )
        {
            try 
            {
                getAppletContext( ).showDocument( new URL( htmlParams.submitURL ) ) ;
            }
            catch ( MalformedURLException malformedURLException )
            {
                // TODO: Handle malformed URL exception.
            }
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  The mouse event procedure to process a MOUSE_CLICKED event on the
    //  Internet link.
    //
    public void mouseClicked( MouseEvent mouseClicked ) 
    {  
        // Attempt to email the developer on a mouse click. If this fails then
        // do not do anything.
        if ( mouseClicked.getSource( ) == aboutEmailLabel )
        {
            try 
            {
                getAppletContext( ).showDocument( new URL( "mailto:" + DEVELOPERS_EMAIL ) ) ;
            }
            catch ( MalformedURLException malformedURLException )
            {
                // TODO: Handle bad url
            }
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  The mouse event procedure to process a MOUSE_ENTERED event on the
    //  buttons.
    //
    public void mouseEntered( MouseEvent mouseEntered )
    {
        //
        // Handle the menu bar buttons
        //
        
        // User Profile Button
        if ( mouseEntered.getSource( ) == userProfileButton )
        {
            getAppletContext( ).showStatus( "User information necessary to complete the request(s)." ) ;
        }
    
        // Book Request Button
        else if ( mouseEntered.getSource( ) == bookRequestButton )
        {
            getAppletContext( ).showStatus( "Information about a book being requested." ) ;
        }
    
        // Periodical Request Button
        else if ( mouseEntered.getSource( ) == periodicalRequestButton )
        {
            getAppletContext( ).showStatus( "Information about an article being requested." ) ;
        }
    
        // View Requests Button
        else if ( mouseEntered.getSource( ) == viewRequestsButton )
        {
            getAppletContext( ).showStatus( "Summary of all requested items." ) ;
        }
    
        // Submit Requests Button
        else if ( mouseEntered.getSource( ) == submissionButton )
        {
            getAppletContext( ).showStatus( "Submit the list of requested items to the library." ) ;
        }
    
        // About Button
        else if ( mouseEntered.getSource( ) == aboutButton )
        {
            getAppletContext( ).showStatus( "View information about this Java applet." ) ;
        }
    
        // Cancel Button
        else if ( mouseEntered.getSource( ) == cancelButton )
        {
            getAppletContext( ).showStatus( "Quit this interlibrary loan request session." ) ;
        }
        
        //
        // Handle the main panel buttons.
        //
        
        // Save User Profile Button
        else if ( mouseEntered.getSource( ) == userSaveProfileButton )
        {
            getAppletContext( ).showStatus( "Save the user profile and continue the interlibrary loan process." ) ;
        }
        
        // Save Book Request Button
        else if ( mouseEntered.getSource( ) == bookSaveRequestButton )
        {
            getAppletContext( ).showStatus( "Save the book request and continue the interlibrary loan process." ) ;
        }
        
        // Online Catalog Button
        else if ( mouseEntered.getSource( ) == bookOnlineCatalogButton )
        {
            getAppletContext( ).showStatus( "View " + htmlParams.libraryName + "\'s online catalog to determine if the item is present locally." ) ;
        }
        
        // Save Periodical Request Button
        else if ( mouseEntered.getSource( ) == perSaveRequestButton )
        {
            getAppletContext( ).showStatus( "Save the article request and continue the interlibrary loan process." ) ;
        }
        
        // Periodical Holdings Button
        else if ( mouseEntered.getSource( ) == perHoldingsButton )
        {
            getAppletContext( ).showStatus( "View " + htmlParams.libraryName + "\'s periodical holdings to determine if the item is present locally." ) ;
        }
        
        // Delete All Button
        else if ( mouseEntered.getSource( ) == viewDeleteAllButton )
        {
            getAppletContext( ).showStatus( "Delete all requests shown in the list box." ) ;
        }
        
        // Delete Button
        else if ( mouseEntered.getSource( ) == viewDeleteButton )
        {
            getAppletContext( ).showStatus( "Delete the request selected in the list box." ) ;
        }
        
        // View Details / Edit Button
        else if ( mouseEntered.getSource( ) == viewEditButton )
        {
            getAppletContext( ).showStatus( "View and edit the details of the request selected in the list box." ) ;
        }
        
        // Request Submission Complete Button
        else if ( mouseEntered.getSource( ) == submitSubmissionComplete )
        {
            getAppletContext( ).showStatus( "The request application has been completed and submitted. Results are posted in the text area." ) ;
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  The mouse event procedure to process a MOUSE_EXITED event on the
    //  menu bar buttons.
    //
    public void mouseExited( MouseEvent mouseExited )
    {
        getAppletContext( ).showStatus( "" ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  The event procedure to process item state changes.
    //
    public void itemStateChanged( ItemEvent itemEvent )
    {
        //
        // Status of "Other" in the user profile will cause a text field to
        // appear so the user can entered specific details.
        //
        
        // Other is selected
        if ( itemEvent.getSource( ) == userStatus.getSelectedCheckbox( ) )
        {
            if ( userStatusOther.getState( ) )
            {
                userStatusOther.setLabel( "Other, be specific:" ) ;
                userStatusOtherField.setVisible( true ) ;
                userStatusOtherField.requestFocus( ) ;
            }
        
            // Other is not selected
            else 
            {
                userStatusOther.setLabel( "Other" ) ;
                userStatusOtherField.setVisible( false ) ;
            }
        }
        
        // 
        // Status of "Citation Source" in the request forms will cause
        // a label and text field to change text or disappear.
        //
        
        else if ( itemEvent.getSource( ) == requestSourceOfCitationChoice )
        {
            // No source selected
            if ( requestSourceOfCitationChoice.getSelectedItem( ).equals( "" ) )
            {
                requestDetailsOfCitationLabel.setVisible( false ) ;
                requestDetailsOfCitationField.setVisible( false ) ;
            }
        
            // Print source selected
            else if ( requestSourceOfCitationChoice.getSelectedItem( ).equals( "Printed Source" ) )
            {
                requestDetailsOfCitationLabel.setText( "Enter title and pages of source" ) ;
                requestDetailsOfCitationLabel.setVisible( true ) ;
                requestDetailsOfCitationField.setVisible( true ) ;
            }
        
            // Online source selected
            else if ( requestSourceOfCitationChoice.getSelectedItem( ).equals( "Online Source" ) )
            {
                requestDetailsOfCitationLabel.setText( "Enter program, website and/or keywords used" ) ;
                requestDetailsOfCitationLabel.setVisible( true ) ;
                requestDetailsOfCitationField.setVisible( true ) ;
            }
        }
        
        //
        // Status of the viewing list box has changed. Determine was the change
        // was and if there are any items still selected after the change.
        //
        
        else if ( itemEvent.getSource( ) == viewListBox )
        {
            if ( viewListBox.getSelectedIndex( ) != -1 )
            {
                viewDeleteButton.setEnabled( true ) ;
                viewEditButton.setEnabled( true ) ;
            }
            else
            {
                viewDeleteButton.setEnabled( false ) ;
                viewEditButton.setEnabled( false ) ;
            }
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  GetHTMLParameters( ) - This method retrieves all the parameters from 
    //  the parent HTML page and puts them in class variables. If this returns
    //  false, then one or more required parameters are missing. The variable
    //  errorMessage will contain the list of missing parameters.
    //
    private boolean getHTMLParameters( )
    {
        boolean status = true ;
        String param ;
        
        htmlParams = new ILL_HtmlParameters( ) ;
        errorMessage = null ;
        
        //
        // Get the main background color parameter.
        //
        param = getParameter( "Main-Background-Color" ) ;
        
        // White is the default is nothing is given.
        if ( isEmpty( param ) )
        {
            htmlParams.mainBgColor = Color.white ;
        }
        // Look for color given in string or hex format.
        else 
        {
            htmlParams.mainBgColor = translateColorString( param, Color.white ) ;
        }

        //
        // Get the main foreground color parameter.
        //
        param = getParameter( "Main-Foreground-Color" ) ;
        
        // Black is the default is nothing is given.
        if ( isEmpty( param ) )
        {
            htmlParams.mainFgColor = Color.black ;
        }
        // Look for color given in string or hex format.
        else 
        {
            htmlParams.mainFgColor = translateColorString( param, Color.black ) ;
        }

        //
        // Get the menu background color parameter.
        //
        param = getParameter( "Menu-Background-Color" ) ;
        
        // White is the default is nothing is given.
        if ( isEmpty( param ) )
        {
            htmlParams.menuBgColor = Color.white ;
        }
        // Look for color given in string or hex format.
        else 
        {
            htmlParams.menuBgColor = translateColorString( param, Color.white ) ;
        }
        
        //
        // Get the institution name parameter.
        //
        htmlParams.institutionName = getParameter( "Institution-Name" ) ;
        if ( isEmpty( htmlParams.institutionName ) )
        {
            status = false ;
            if ( isEmpty( errorMessage ) )
                errorMessage = new String( "Institution-Name" ) ;
            else
                errorMessage += ", Institution-Name" ;
        }
        
        //
        // Get the library name parameter.
        //
        htmlParams.libraryName = getParameter( "Library-Name" ) ;
        if ( isEmpty( htmlParams.libraryName ) )
        {
            status = false ;
            if ( isEmpty( errorMessage ) )
                errorMessage = new String( "Library-Name" ) ;
            else
                errorMessage += ", Library-Name" ;
        }
        
        //
        // Get the library symbol parameter.
        //
        htmlParams.librarySymbol = getParameter( "Library-Symbol" ) ;
        if ( isEmpty( htmlParams.librarySymbol ) )
        {
            status = false ;
            if ( isEmpty( errorMessage ) )
                errorMessage = new String( "Library-Symbol" ) ;
            else
                errorMessage += ", Library-Symbol" ;
        }
        
        //
        //  Get the Access-Security-Matrix
        //
        param = getParameter( "Access-Security-Matrix" ) ;
        if ( isEmpty( param ) )
        {
            status = false ;
            if ( isEmpty( errorMessage ) )
                errorMessage = new String( "Access-Security-Matrix" ) ;
            else
                errorMessage += ", Access-Security-Matrix" ;
        }
        
        //
        //  Convert the Access-Security-Matrix parameter into an authorization and password
        //
        else if ( isValidSecurityMatrix( param ) )
        {
            //
            // The result is trimmed because the return value is padded with zeroes for
            // some reason. The cause has not been determine and is currently not being
            // research since the String's trim method resolves the issue.
            //
            htmlParams.authorization = extractAuthorizationFromMatrix( param ) ;
            htmlParams.password = extractPasswordFromMatrix( param ) ;
            
            if ( isEmpty( htmlParams.authorization ) || isEmpty( htmlParams.password ) )
            {
                status = false ;
                if ( isEmpty( errorMessage ) )
                    errorMessage = new String( "Access-Security-Matrix (INVALID)" ) ;
                else
                    errorMessage += ", Access-Security-Matrix (INVALID)" ;
            }
        }
        else
        {
            status = false ;
            if ( isEmpty( errorMessage ) )
                errorMessage = new String( "Access-Security-Matrix (INVALID)" ) ;
            else
                errorMessage += ", Access-Security-Matrix (INVALID)" ;
        }
        
        /*
        //
        // Get the ILL Authorization code.
        //
        htmlParams.authorization = getParameter( "Authorization" ) ;
        if ( isEmpty( htmlParams.authorization ) )
        {
            status = false ;
            if ( isEmpty( errorMessage ) )
                errorMessage = new String( "Authorization" ) ;
            else
                errorMessage += ", Authorization" ;
        }
        
        //
        // Get the ILL Password.
        //
        htmlParams.password = getParameter( "Password" ) ;
        if ( isEmpty( htmlParams.password ) )
        {
            status = false ;
            if ( isEmpty( errorMessage ) )
                errorMessage = new String( "Password" ) ;
            else
                errorMessage += ", Password" ;
        }
        */
        
        //
        // Get the Valid Users.
        //
        htmlParams.validUsers = getParameter( "Valid-Users" ) ;
        // TODO: Validate Valid-Users.
        
        //
        // Get the ILL service type parameter.
        //
        param = getParameter( "ILL-Service-Type" ) ;
        
        // Convert the string parameter into an integral value. The default
        // service is to the review file.
        if ( isEmpty( param ) || param.toUpperCase( ).equals( "REVIEW FILE" ) )
            htmlParams.illServiceType = DIRECT_TO_REVIEW_SERVICE ;
        else if ( param.toUpperCase( ).equals( "PROFILE" ) )
            htmlParams.illServiceType = DIRECT_TO_PROFILE_SERVICE ;
        else if ( param.toUpperCase( ).equals( "LENDER" ) )
            htmlParams.illServiceType = DIRECT_TO_LENDER_SERVICE ;
        else
            htmlParams.illServiceType = DIRECT_TO_REVIEW_SERVICE ;
        
        //
        // Get the lender list parameter.
        //
        htmlParams.lenderList = getParameter( "Lender-List" ) ;
        
        //
        // Get the max requests parameter.
        //
        param = getParameter( "Max-Requests" ) ;
        
        // Convert the max requests string into an integer.
        try
        {
            htmlParams.maxRequests = Integer.parseInt( param ) ;
            if ( htmlParams.maxRequests == 0 )
                htmlParams.maxRequests = Integer.MAX_VALUE ;
        }
        catch ( NumberFormatException formatException1 )
        {
            htmlParams.maxRequests = Integer.MAX_VALUE ;
        }
        
        //
        // Get the delivery name parameter.
        //
        htmlParams.deliveryName = getParameter( "Delivery-Name" ) ;
        if ( isEmpty( htmlParams.deliveryName ) )
        {
            status = false ;
            if ( isEmpty( errorMessage ) )
                errorMessage = new String( "Delivery-Name" ) ;
            else
                errorMessage += ", Delivery-Name" ;
        }
        
        //
        // Get the delivery extension parameter.
        //
        htmlParams.deliveryExtension = getParameter( "Delivery-Extension" ) ;
        
        //
        // Get the delivery street address or the delivery P.O. Box number 
        // parameter.
        //
        htmlParams.deliveryStreet = getParameter( "Delivery-Street" ) ;
        htmlParams.deliveryPOBox = getParameter( "Delivery-POBox" ) ;
        
        // Confirm that either the street or box address address is given.
        if ( isEmpty( htmlParams.deliveryStreet ) && isEmpty( htmlParams.deliveryPOBox ) )
        {
            status = false ;
            if ( isEmpty( errorMessage ) )
                errorMessage = new String( "A Delivery Address" ) ;
            else
                errorMessage += ", a Delivery Address" ;
        }
        
        //
        // Get the delivery city parameter.
        //
        htmlParams.deliveryCity = getParameter( "Delivery-City" ) ;
        if ( isEmpty( htmlParams.deliveryCity ) )
        {
            status = false ;
            if ( isEmpty( errorMessage ) )
                errorMessage = new String( "Delivery-City" ) ;
            else
                errorMessage += ", Delivery-City" ;
        }
        
        //
        // Get the delivery state parameter.
        //
        htmlParams.deliveryState = getParameter( "Delivery-State" ) ;
        if ( isEmpty( htmlParams.deliveryState ) )
        {
            status = false ;
            if ( isEmpty( errorMessage ) )
                errorMessage = new String( "Delivery-State" ) ;
            else
                errorMessage += ", Delivery-State" ;
        }
        
        //
        // Get the delivery zip code parameter.
        //
        htmlParams.deliveryZipCode = getParameter( "Delivery-ZIP-Code" ) ;
        if ( isEmpty( htmlParams.deliveryZipCode ) )
        {
            status = false ;
            if ( isEmpty( errorMessage ) )
                errorMessage = new String( "Delivery-ZIP-Code" ) ;
            else
                errorMessage += ", Delivery-ZIP-Code" ;
        }
        
        //
        // Get the delivery service parameter.
        //
        htmlParams.deliveryService = getParameter( "Delivery-Service" ) ;
        
        //
        // Get the electronic delivery service parameter.
        //
        htmlParams.electronicService = getParameter( "Electronic-Service" ) ;
        
        //
        //  Get the library phone parameter.
        //
        htmlParams.libraryPhone = getParameter( "Library-Phone" ) ;
        
        //
        // Get the library fax parameter.
        //
        htmlParams.libraryFax = getParameter( "Library-Fax" ) ;
        
        //
        // Get the library email parameter.
        //
        htmlParams.libraryEmail = getParameter( "Library-Email" ) ;
        
        //
        // Get the max cost parameter.
        //
        htmlParams.maxCost = getParameter( "Max-Cost" ) ;
        if ( isEmpty( htmlParams.maxCost ) )
        {
            status = false ;
            if ( isEmpty( errorMessage ) )
                errorMessage = new String( "Max-Cost" ) ;
            else
                errorMessage += ", Max-Cost" ;
        }
        
        //
        // Get the allow-nonmember-requests parameter.
        //
        param = getParameter( "Nonmember-Requests" ) ;
        if ( isEmpty( param ) || param.toUpperCase( ).equals( "NO" ) )
        {
            htmlParams.allowNonmemberRequests = false ;
        }
        else if ( param.toUpperCase( ).equals( "YES" ) )
        {
            htmlParams.allowNonmemberRequests = true ;
        }
        
        //
        // Get the book note parameter.
        //
        htmlParams.bookNote = getParameter( "Book-Note" ) ;
        
        //
        // Get the periodical note parameter.
        //
        htmlParams.periodicalNote = getParameter( "Periodical-Note" ) ;
        
        //
        // Get the cancel URL parameter.
        //
        htmlParams.cancelURL = getParameter( "Cancel-Page" ) ;
        if ( isEmpty( htmlParams.cancelURL ) )
        {
            status = false ;
            if ( isEmpty( errorMessage ) )
                errorMessage = new String( "Cancel-Page" ) ;
            else
                errorMessage += ", Cancel-Page" ;
        }
        
        //
        // Get the submit URL parameter.
        //
        htmlParams.submitURL = getParameter( "Submit-Page" ) ;
        if ( isEmpty( htmlParams.submitURL ) )
        {
            status = false ;
            if ( isEmpty( errorMessage ) )
                errorMessage = new String( "Submit-Page" ) ;
            else
                errorMessage += ", Submit-Page" ;
        }
        
        //
        // Get the online catalog and periodical holdings URL parameters.
        //
        htmlParams.onlineCatalogURL = getParameter( "Online-Catalog-Page" ) ;
        htmlParams.periodicalHoldingsURL = getParameter( "Periodical-Holdings-Page" ) ;
        
        //
        // Get the target server address and port.
        //
        htmlParams.illServerAddress = getParameter( "ILL-Server-Address" ) ;
        param = getParameter( "ILL-Server-Port" ) ;
        
        // Check for errors.
        if ( isEmpty( htmlParams.illServerAddress ) ) 
        {
            status = false ;
            if ( isEmpty( errorMessage ) )
                errorMessage = new String( "ILL-Server-Address" ) ;
            else
                errorMessage += ", ILL-Server-Address" ;
        }

        // Convert the port number and check for errors.
        try 
        {
            htmlParams.illServerPort = Integer.parseInt( param ) ;
        }
        catch ( NumberFormatException formatException2 )
        {
            status = false ;
            if ( isEmpty( errorMessage ) )
                errorMessage = new String( "ILL-Server-Port" ) ;
            else
                errorMessage += ", ILL-Server-Port" ;
        }
        
        // 
        // Return the success status of the method.
        //
        return status ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  IsUserValid
    //
    private boolean isUserValid( )
    {
        errorMessage = null ;
        
        if ( isEmpty( htmlParams.validUsers ) )
            return true ;
        
        byte localAddress[ ] ;

        // Obtain security permission to use the system network facilities.
        //
        // The following code fragment is based on the Java 1.2 class library.
        // For compatibility with web browser, Java 1.1 code will be used until
        // such time both Microsoft and Netscape have implemented the new JVM.
        //
        //SocketPermission permission = new SocketPermission( htmlParams.illServerAddress, "accept,connect,listen,resolve" ) ;
        //try {
        //    java.security.AccessController.checkPermission( permission ) ;
        //}
        //catch ( java.security.AccessControlException ace )
        //{
        //    // TODO: Handle permissions denied.
        //}
        SecurityManager security = System.getSecurityManager( ) ;
        if ( security != null )
        {
            try 
            {
                security.checkConnect( htmlParams.illServerAddress, htmlParams.illServerPort ) ;
            }
            catch ( SecurityException se )
            {
                errorMessage = new String( "An error occurred while getting the network security permissions. " ) ;
                errorMessage += se.toString( ) ;
                return false ;
            }
        }
        else
        {
            errorMessage = new String( "An error occurred while getting the network security permissions. " ) ;
            return false ;
        }
        
        // Try to get the local address. If it fails do not validate the user.
        try 
        {
            localAddress = InetAddress.getLocalHost( ).getAddress( ) ;
        }
        catch ( UnknownHostException uhe )
        {
            errorMessage = new String( "An error occurred while detecting the local address. " ) ;
            errorMessage += uhe.toString( ) ;
            return false ;
        }
        catch ( Exception e )
        {
            errorMessage = new String( "An error occurred while detecting the local address. " ) ;
            errorMessage += e.toString( ) ;
            return false ;
        }
        
        // Assume that the user is not valid until proven otherwise.
        boolean valid = false ;
        int index = 0 ;
        
        // Loop through address tokens until there are no more address values to 
        // check or the user has been validated to use the applet.
        StringTokenizer addrTokens = new StringTokenizer( htmlParams.validUsers, ";", false ) ;
        while ( addrTokens.hasMoreTokens( ) && !valid )
        {
            valid = true ;
            index = 0 ;
            StringTokenizer byteTokens = new StringTokenizer( addrTokens.nextToken( ), ".", false ) ;
            
            while ( byteTokens.hasMoreTokens( ) && valid )
            {
                try 
                {
                    valid = ( localAddress[ index++ ] == Byte.parseByte( byteTokens.nextToken( ) ) ) ;
                }
                catch ( NumberFormatException nfe )
                {
                    valid = false ;
                    errorMessage = new String( "An error occurred while parsing the address string. " ) ;
                    errorMessage += nfe.toString( ) ;
                    break ;
                }
            }
        }
        
        if ( !valid )
        {
            errorMessage = new String( "Requests cannot be sent from this local host: " ) ;
            try
            {
                errorMessage += InetAddress.getLocalHost( ).getHostAddress( ) ;
            }
            catch ( UnknownHostException uheExtra )
            {
                errorMessage += uheExtra.toString( ) ;
            }
            catch ( Exception e )
            {
                errorMessage += e.toString( ) ;
            }
        }
        
        return valid ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Menu Bar Panel - creates the menu bar and button in their initial state.
    //
    private void createMenuPanel( ) 
    {
        // Local variables
        int y, width ;
        int buttonOffset = BUTTON_HEIGHT + 4 ;
        
        // Initialize the menu panel properties.
        menuPanel.setBounds( 0, 0, MENU_BAR_WIDTH, APPLET_HEIGHT ) ;
        menuPanel.setBackground( htmlParams.menuBgColor ) ;
     
        //
        // Create the menu buttons.
        //
        
        // Calculate location and dimension variables
        y = BOUNDARY_WIDTH ;
        width = MENU_BAR_WIDTH - 2 * BOUNDARY_WIDTH ;

        // User profile button.
        menuPanel.add( userProfileButton = new LinuxSafeButton( "User Profile" ) ) ;
        userProfileButton.setBounds( BOUNDARY_WIDTH, 
                                     y, 
                                     width, 
                                     BUTTON_HEIGHT ) ;
        userProfileButton.addActionListener( this ) ;
        userProfileButton.addMouseListener( this ) ;
        
        // Book request button.
        menuPanel.add( bookRequestButton = new LinuxSafeButton( "Book Request" ) ) ;
        y += buttonOffset ;
        bookRequestButton.setBounds( BOUNDARY_WIDTH, 
                                     y, 
                                     width, 
                                     BUTTON_HEIGHT ) ;
        bookRequestButton.addActionListener( this ) ;
        bookRequestButton.addMouseListener( this ) ;
        bookRequestButton.setEnabled( false ) ;
        
        // Periodical request button.
        menuPanel.add( periodicalRequestButton = new LinuxSafeButton( "Article Request" ) ) ;
        y += buttonOffset ;
        periodicalRequestButton.setBounds( BOUNDARY_WIDTH, 
                                           y, 
                                           width, 
                                           BUTTON_HEIGHT ) ;
        periodicalRequestButton.addActionListener( this ) ;
        periodicalRequestButton.addMouseListener( this ) ;
        periodicalRequestButton.setEnabled( false ) ;
        
        // View requests button.
        menuPanel.add( viewRequestsButton = new LinuxSafeButton( "View Requests" ) ) ;
        y += buttonOffset ;
        viewRequestsButton.setBounds( BOUNDARY_WIDTH, 
                                      y, 
                                      width, 
                                      BUTTON_HEIGHT ) ;
        viewRequestsButton.addActionListener( this ) ;
        viewRequestsButton.addMouseListener( this ) ;
        viewRequestsButton.setEnabled( false ) ;
        
        // Submit requests button.
        menuPanel.add( submissionButton = new LinuxSafeButton( "Submit Requests" ) ) ;
        y += buttonOffset ;
        submissionButton.setBounds( BOUNDARY_WIDTH, 
                                    y, 
                                    width, 
                                    BUTTON_HEIGHT ) ;
        submissionButton.addActionListener( this ) ;
        submissionButton.addMouseListener( this ) ;
        submissionButton.setEnabled( false ) ;
        
        // About button.
        menuPanel.add( aboutButton = new LinuxSafeButton( "About" ) ) ;
        y += buttonOffset ;
        aboutButton.setBounds( BOUNDARY_WIDTH, 
                               y, 
                               width, 
                               BUTTON_HEIGHT ) ;
        aboutButton.addActionListener( this ) ;
        aboutButton.addMouseListener( this ) ;
        
        // Cancel button.
        menuPanel.add( cancelButton = new LinuxSafeButton( "Cancel" ) ) ;
        y += buttonOffset ;
        cancelButton.setBounds( BOUNDARY_WIDTH, 
                                y, 
                                width, 
                                BUTTON_HEIGHT ) ;
        cancelButton.addActionListener( this ) ;
        cancelButton.addMouseListener( this ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  User Profile Panel 
    //
    private void createUserProfilePanel( )
    {
        //
        // Local variables
        //
        int x, y, width ;
        Font requiredFont = new Font( "SansSerif", Font.BOLD, 12 ) ;
        Label userProfileTitle ;
        Label userFullNameLabel ;
        Label userIDLabel ;
        Label userStreetAddressLabel ;
        Label userPOBoxAddressLabel ;
        Label userCityLabel ;
        Label userStateLabel ;
        Label userZIPLabel ;
        Label userEmailLabel ;
        Label userPhoneLabel ;
        Label userFaxLabel ;
        Label userStatusLabel ;
        Label userDepartmentLabel ;
        
        //
        // Remove all components from the main panel.
        //
        mainPanel.removeAll( ) ;
        
        //
        // Create and add the user profile components.
        //
        
        // Add the page title.
        mainPanel.add( userProfileTitle = new Label( "User Profile" ) ) ;
        userProfileTitle.setFont( new Font( "Serif", Font.BOLD, 24 ) ) ;
        userProfileTitle.setAlignment( Label.CENTER ) ;
        userProfileTitle.setBounds( 0,
                                    0,
                                    APPLET_WIDTH - MENU_BAR_WIDTH,
                                    28 ) ;
        
        // Prepare the next row.
        width = ( APPLET_WIDTH - MENU_BAR_WIDTH - 3 * BOUNDARY_WIDTH ) / 2 ;
        x = width + 2 * BOUNDARY_WIDTH ;
        y = 28 + BOUNDARY_WIDTH ;
        
        // Add label and text field for the user name.
        mainPanel.add( userFullNameLabel = new Label( "Full Name" ) ) ;
        userFullNameLabel.setFont( requiredFont ) ;
        userFullNameLabel.setBounds( BOUNDARY_WIDTH,
                                     y,
                                     width,
                                     LABEL_HEIGHT ) ;
        mainPanel.add( userFullNameField = new TextField( userProfile.full_name ) ) ;
        userFullNameField.setBounds( BOUNDARY_WIDTH,
                                     y + LABEL_HEIGHT,
                                     width,
                                     userFullNameField.getPreferredSize( ).height ) ;
        
        // Add label and text field for the user id.
        mainPanel.add( userIDLabel = new Label( "Student ID or SSN" ) ) ;
        //userIDLabel.setFont( requiredFont ) ;
        userIDLabel.setBounds( x, 
                               y, 
                               width, 
                               LABEL_HEIGHT ) ;
        mainPanel.add( userIDField = new TextField( userProfile.id ) ) ;
        userIDField.setBounds( x, 
                               y + LABEL_HEIGHT, 
                               width, 
                               userIDField.getPreferredSize( ).height ) ;
        
        // Prepare the next row.
        y += LABEL_HEIGHT + userIDField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        
        // Add label and text field for the street address.
        mainPanel.add( userStreetAddressLabel = new Label( "Street Address,      OR" ) ) ;
        userStreetAddressLabel.setFont( requiredFont ) ;
        userStreetAddressLabel.setBounds( BOUNDARY_WIDTH,
                                          y,
                                          width,
                                          LABEL_HEIGHT ) ;
        mainPanel.add( userStreetAddressField = new TextField( userProfile.home_street_address ) ) ;
        userStreetAddressField.setBounds( BOUNDARY_WIDTH,
                                          y + LABEL_HEIGHT,
                                          width,
                                          userStreetAddressField.getPreferredSize( ).height ) ;
        
        // Add label and text field of the P.O. box address.
        mainPanel.add( userPOBoxAddressLabel = new Label( "P.O. Box Address" ) ) ;
        userPOBoxAddressLabel.setFont( requiredFont ) ;
        userPOBoxAddressLabel.setBounds( x,
                                         y,
                                         width,
                                         LABEL_HEIGHT ) ;
        mainPanel.add( userPOBoxAddressField = new TextField( userProfile.home_po_box ) ) ;
        userPOBoxAddressField.setBounds( x, 
                                         y + LABEL_HEIGHT,
                                         width,
                                         userPOBoxAddressField.getPreferredSize( ).height ) ;
        
        // Prepare the next row.
        y += LABEL_HEIGHT + userPOBoxAddressField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        
        // Add label and text field for the user city.
        mainPanel.add( userCityLabel = new Label( "City" ) ) ;
        userCityLabel.setBounds( BOUNDARY_WIDTH,
                                 y,
                                 width,
                                 LABEL_HEIGHT ) ;
        mainPanel.add( userCityField = new TextField( userProfile.home_city ) ) ;
        userCityField.setBounds( BOUNDARY_WIDTH,
                                 y + LABEL_HEIGHT,
                                 width,
                                 userCityField.getPreferredSize( ).height ) ;
        
        // Recalculate width.
        width = ( width - BOUNDARY_WIDTH ) / 2 ;
        
        // Add label and text field for the state.
        mainPanel.add( userStateLabel = new Label( "State" ) ) ;
        userStateLabel.setBounds( x,
                                  y,
                                  width,
                                  LABEL_HEIGHT ) ;
        mainPanel.add( userStateField = new TextField( userProfile.home_state ) ) ;
        userStateField.setBounds( x,
                                  y + LABEL_HEIGHT,
                                  width,
                                  userStateField.getPreferredSize( ).height ) ;
        
        // Recalcuate x.
        x += width + BOUNDARY_WIDTH ;
        
        // Add label and text field for the ZIP code.
        mainPanel.add( userZIPLabel = new Label( "ZIP Code" ) ) ;
        userZIPLabel.setBounds( x,
                                y,
                                width,
                                LABEL_HEIGHT ) ;
        mainPanel.add( userZIPField = new TextField( userProfile.home_postal_code ) ) ;
        userZIPField.setBounds( x,
                                y + LABEL_HEIGHT,
                                width,
                                userZIPField.getPreferredSize( ).height ) ;
        
        // Prepare the next row.
        width = ( APPLET_WIDTH - MENU_BAR_WIDTH - 4 * BOUNDARY_WIDTH ) / 3 ;
        x = width + 2 * BOUNDARY_WIDTH ;
        y += LABEL_HEIGHT + userZIPField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        
        // Add label and text field for the user email.
        mainPanel.add( userEmailLabel = new Label( "Email Address" ) ) ;
        userEmailLabel.setFont( requiredFont ) ;
        userEmailLabel.setBounds( BOUNDARY_WIDTH,
                                  y,
                                  width,
                                  LABEL_HEIGHT ) ;
        mainPanel.add( userEmailField = new TextField( userProfile.email ) ) ;
        userEmailField.setBounds( BOUNDARY_WIDTH,
                                  y + LABEL_HEIGHT,
                                  width,
                                  userEmailField.getPreferredSize( ).height ) ;
        
        // Add label and text field for the user phone.
        mainPanel.add( userPhoneLabel = new Label( "Phone Number" ) ) ;
        userPhoneLabel.setFont( requiredFont ) ;
        userPhoneLabel.setBounds( x,
                                  y,
                                  width,
                                  LABEL_HEIGHT ) ;
        mainPanel.add( userPhoneField = new TextField( userProfile.phone ) ) ;
        userPhoneField.setBounds( x,
                                  y + LABEL_HEIGHT,
                                  width,
                                  userPhoneField.getPreferredSize( ).height ) ;
        
        // Add label and text field for the user fax.
        x += width + BOUNDARY_WIDTH ;
        mainPanel.add( userFaxLabel = new Label( "Fax Number" ) ) ;
        userFaxLabel.setBounds( x,
                                y,
                                width,
                                LABEL_HEIGHT ) ;
        mainPanel.add( userFaxField = new TextField( userProfile.fax ) ) ;
        userFaxField.setBounds( x,
                                y + LABEL_HEIGHT,
                                width,
                                userFaxField.getPreferredSize( ).height ) ;
        
        // Prepare the next row.
        x = width + 2 * BOUNDARY_WIDTH ;
        y += LABEL_HEIGHT + userFaxField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        
        //
        // Add label and checkboxes for the user status.
        //
        
        // Status label.
        mainPanel.add( userStatusLabel = new Label( "Status at " + htmlParams.institutionName ) ) ;
        userStatusLabel.setFont( requiredFont ) ;
        userStatusLabel.setBounds( BOUNDARY_WIDTH,
                                   y,
                                   APPLET_WIDTH - MENU_BAR_WIDTH - 2 * BOUNDARY_WIDTH,
                                   LABEL_HEIGHT ) ;
        
        // Faculty
        y += LABEL_HEIGHT ;
        mainPanel.add( userStatusFaculty = new Checkbox( "Faculty", userStatus, false ) ) ;
        userStatusFaculty.addItemListener( this ) ;
        userStatusFaculty.setBounds( BOUNDARY_WIDTH,
                                     y,
                                     width,
                                     CHECKBOX_HEIGHT ) ;
        
        // Staff
        mainPanel.add( userStatusStaff = new Checkbox( "Staff", userStatus, false ) ) ;
        userStatusStaff.addItemListener( this ) ;
        userStatusStaff.setBounds( x,
                                   y,
                                   width,
                                   CHECKBOX_HEIGHT ) ;
        
        // Undergraduate
        mainPanel.add( userStatusUndergraduate = new Checkbox( "Undergraduate", userStatus, false ) ) ;
        userStatusUndergraduate.addItemListener( this ) ;
        userStatusUndergraduate.setBounds( x + width + BOUNDARY_WIDTH,
                                           y,
                                           width,
                                           CHECKBOX_HEIGHT ) ;
        
        // Graduate
        y += userFaxField.getPreferredSize( ).height ;
        mainPanel.add( userStatusGraduate = new Checkbox( "Graduate", userStatus, false ) ) ;
        userStatusGraduate.addItemListener( this ) ;
        userStatusGraduate.setBounds( BOUNDARY_WIDTH,
                                      y,
                                      width,
                                      CHECKBOX_HEIGHT ) ;
        
        // Other
        mainPanel.add( userStatusOther = new Checkbox( "Other", userStatus, false ) ) ;
        userStatusOther.addItemListener( this ) ;
        userStatusOther.setBounds( x,
                                   y,
                                   width,
                                   CHECKBOX_HEIGHT ) ;
        mainPanel.add( userStatusOtherField = new TextField( ) ) ;
        userStatusOtherField.setBounds( x + width + BOUNDARY_WIDTH,
                                        y,
                                        width,
                                        userStatusOtherField.getPreferredSize( ).height ) ;
        userStatusOtherField.setVisible( false ) ;
        
        // Determine which user status button should be selected.
        if ( userProfile.status.equals( "Faculty" ) )
        {
            userStatus.setSelectedCheckbox( userStatusFaculty ) ;
        }
        else if ( userProfile.status.equals( "Staff" ) )
        {
            userStatus.setSelectedCheckbox( userStatusStaff ) ;
        }
        else if ( userProfile.status.equals( "Undergraduate" ) )
        {
            userStatus.setSelectedCheckbox( userStatusUndergraduate ) ;
        }
        else if ( userProfile.status.equals( "Graduate" ) )
        {
            userStatus.setSelectedCheckbox( userStatusGraduate ) ;
        }
        else if ( !isEmpty( userProfile.status ) )
        {
            userStatus.setSelectedCheckbox( userStatusOther ) ;
            userStatusOtherField.setVisible( true ) ;
            if ( !userProfile.status.equals( "Other" ) )
                userStatusOtherField.setText( userProfile.status ) ;
        }

        // Prepare the next row.
        y += userStatusOtherField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        width = ( APPLET_WIDTH - MENU_BAR_WIDTH - 3 * BOUNDARY_WIDTH ) / 2 ;
        
        // Add label and text field for the user department.
        mainPanel.add( userDepartmentLabel = new Label( "Department at " + htmlParams.institutionName ) ) ;
        userDepartmentLabel.setBounds( BOUNDARY_WIDTH,
                                       y,
                                       width,
                                       LABEL_HEIGHT ) ;
        mainPanel.add( userDepartmentField = new TextField( userProfile.department ) ) ;
        userDepartmentField.setBounds( BOUNDARY_WIDTH,
                                       y + LABEL_HEIGHT,
                                       width,
                                       userDepartmentField.getPreferredSize( ).height ) ;
        
        // Prepare final component positions.
        y += LABEL_HEIGHT + userDepartmentField.getPreferredSize( ).height + 2 * BOUNDARY_WIDTH ;
        width = APPLET_WIDTH - MENU_BAR_WIDTH - 2 * BOUNDARY_WIDTH ;
        
        // Add the user profile save button.
        mainPanel.add( userSaveProfileButton = new LinuxSafeButton( "Save User Profile" ) ) ;
        userSaveProfileButton.setFont( requiredFont ) ;
        userSaveProfileButton.setBounds( BOUNDARY_WIDTH,
                                         y,
                                         width,
                                         BUTTON_HEIGHT ) ;
        userSaveProfileButton.addActionListener( this ) ;
        userSaveProfileButton.addMouseListener( this ) ;
        
        //
        // Redraw the applet.
        //
        repaint( ) ;
        
        //
        // Set the initial focus to the user full name field.
        //
        userFullNameField.requestFocus( ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Book Request Panel
    //
    private void createBookRequestPanel( RequestInformation request )
    {
        //
        // Local variables
        //
        int x, y, width ;
        Font requiredFont = new Font( "SansSerif", Font.BOLD, 12 ) ;
        Label bookRequestTitle ;
        Label bookAuthorLabel ;
        Label bookTitleLabel ;
        Label bookSubTitleLabel ;
        Label bookUniformTitleLabel ;
        Label bookPlaceOfPublicationLabel ;
        Label bookPublisherLabel ;
        Label bookPublicationDateLabel ;
        Label bookEditionLabel ;
        Label bookVolumeLabel ;
        Label bookISBNLabel ;
        Label bookOCLCNumberLabel ;
        Label bookERICNumberLabel ;
        Label bookCallNumberLabel ;
        Label bookVerifiedLabel ;
        Label bookNeedBeforeLabel ;
        Label bookSourceOfCitationLabel ;
        Label bookPatronNotesLabel ;
        
        //
        // Remove all components from the main panel.
        //
        mainPanel.removeAll( ) ;
        
        //
        // Create and add the book request components.
        //
        mainPanel.add( bookRequestTitle = new Label( "Book Request Form" ) ) ;
        bookRequestTitle.setFont( new Font( "Serif", Font.BOLD, 24 ) ) ;
        bookRequestTitle.setAlignment( Label.CENTER ) ;
        bookRequestTitle.setBounds( 0,
                                    0,
                                    APPLET_WIDTH - MENU_BAR_WIDTH,
                                    28 ) ;
        
        // Author
        width = APPLET_WIDTH - MENU_BAR_WIDTH - 2 * BOUNDARY_WIDTH ;
        y = 28 + BOUNDARY_WIDTH ;
        mainPanel.add( bookAuthorLabel = new Label( "Author or Editor" ) ) ;
        bookAuthorLabel.setFont( requiredFont ) ;
        bookAuthorLabel.setBounds( BOUNDARY_WIDTH,
                                   y,
                                   width,
                                   LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( requestAuthorField = new TextField( request.author ) ) ;
        requestAuthorField.setBounds( BOUNDARY_WIDTH,
                                      y,
                                      width,
                                      requestAuthorField.getPreferredSize( ).height ) ;
        
        // Title
        y += requestAuthorField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        mainPanel.add( bookTitleLabel = new Label( "Title of Book (Do not abbreviate)" ) ) ;
        bookTitleLabel.setFont( requiredFont ) ;
        bookTitleLabel.setBounds( BOUNDARY_WIDTH,
                                  y,
                                  width,
                                  LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( requestTitleField = new TextField( request.title ) ) ;
        requestTitleField.setBounds( BOUNDARY_WIDTH,
                                     y,
                                     width,
                                     requestTitleField.getPreferredSize( ).height ) ;
        
        // Subtitle
        y += requestTitleField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        width = ( APPLET_WIDTH - MENU_BAR_WIDTH - 3 * BOUNDARY_WIDTH ) / 2 ;
        mainPanel.add( bookSubTitleLabel = new Label( "Subtitle" ) ) ;
        bookSubTitleLabel.setBounds( BOUNDARY_WIDTH,
                                     y,
                                     width,
                                     LABEL_HEIGHT ) ;
        mainPanel.add( bookSubTitleField = new TextField( request.sub_title ) ) ;
        bookSubTitleField.setBounds( BOUNDARY_WIDTH,
                                     y + LABEL_HEIGHT,
                                     width,
                                     bookSubTitleField.getPreferredSize( ).height ) ;
        
        // Uniform title
        x = width + 2 * BOUNDARY_WIDTH ;
        mainPanel.add( bookUniformTitleLabel = new Label( "Uniform Title" ) ) ;
        bookUniformTitleLabel.setBounds( x, y,
                                         width,
                                         LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( bookUniformTitleField = new TextField( request.uniform_title ) ) ;
        bookUniformTitleField.setBounds( x, y,
                                         width,
                                         bookUniformTitleField.getPreferredSize( ).height ) ;
        
        // Place of publication
        y += bookUniformTitleField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        mainPanel.add( bookPlaceOfPublicationLabel = new Label( "Place of Publication" ) ) ;
        bookPlaceOfPublicationLabel.setBounds( BOUNDARY_WIDTH,
                                               y,
                                               width,
                                               LABEL_HEIGHT ) ;
        mainPanel.add( bookPlaceOfPublicationField = new TextField( request.place_of_publication ) ) ;
        bookPlaceOfPublicationField.setBounds( BOUNDARY_WIDTH,
                                               y + LABEL_HEIGHT,
                                               width,
                                               bookPlaceOfPublicationField.getPreferredSize( ).height ) ;
        
        // Publisher
        mainPanel.add( bookPublisherLabel = new Label( "Publisher" ) ) ;
        bookPublisherLabel.setBounds( x, y,
                                      width,
                                      LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( bookPublisherField = new TextField( request.publisher ) ) ;
        bookPublisherField.setBounds( x, y,
                                      width,
                                      bookPublisherField.getPreferredSize( ).height ) ;
        
        // Publication year
        width = ( APPLET_WIDTH - MENU_BAR_WIDTH - 4 * BOUNDARY_WIDTH ) / 3 ;
        x = width + 2 * BOUNDARY_WIDTH ;
        y += bookPublisherField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        mainPanel.add( bookPublicationDateLabel = new Label( "Year" ) ) ;
        bookPublicationDateLabel.setBounds( BOUNDARY_WIDTH,
                                            y,
                                            width,
                                            LABEL_HEIGHT ) ;
        mainPanel.add( requestPublicationDateField = new TextField( request.publication_date ) ) ;
        requestPublicationDateField.setBounds( BOUNDARY_WIDTH,
                                               y + LABEL_HEIGHT,
                                               width,
                                               requestPublicationDateField.getPreferredSize( ).height ) ;
        
        // Edition
        mainPanel.add( bookEditionLabel = new Label( "Edition" ) ) ;
        bookEditionLabel.setBounds( x, y,
                                    width,
                                    LABEL_HEIGHT ) ;
        mainPanel.add( bookEditionField = new TextField( isEmpty( request.edition ) ? "ANY" : request.edition ) ) ;
        bookEditionField.setBounds( x,
                                       y + LABEL_HEIGHT,
                                       width,
                                       bookEditionField.getPreferredSize( ).height ) ;
        
        // Volume
        x += width + BOUNDARY_WIDTH ;
        mainPanel.add( bookVolumeLabel = new Label( "Volume" ) ) ;
        bookVolumeLabel.setBounds( x,
                                   y,
                                   width,
                                   LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( requestVolumeField = new TextField( request.volume ) ) ;
        requestVolumeField.setBounds( x,
                                      y,
                                      width,
                                      requestVolumeField.getPreferredSize( ).height ) ;
        // ISBN
        width = ( APPLET_WIDTH - MENU_BAR_WIDTH - 5 * BOUNDARY_WIDTH ) / 4 ;
        x = width + 2 * BOUNDARY_WIDTH ;
        y += requestVolumeField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        mainPanel.add( bookISBNLabel = new Label( "ISBN (Recommended)" ) ) ;
        bookISBNLabel.setBounds( BOUNDARY_WIDTH,
                                 y,
                                 width,
                                 LABEL_HEIGHT ) ;
        mainPanel.add( bookISBNField = new TextField( request.isbn ) ) ;
        bookISBNField.setBounds( BOUNDARY_WIDTH,
                                 y + LABEL_HEIGHT,
                                 width,
                                 bookISBNField.getPreferredSize( ).height ) ;
        
        // OCLC Number
        mainPanel.add( bookOCLCNumberLabel = new Label( "OCLC Number" ) ) ;
        bookOCLCNumberLabel.setBounds( x, y,
                                       width,
                                       LABEL_HEIGHT ) ;
        mainPanel.add( bookOCLCNumberField = new TextField( request.oclc_no ) ) ;
        bookOCLCNumberField.setBounds( x, y + LABEL_HEIGHT,
                                       width,
                                       bookOCLCNumberField.getPreferredSize( ).height ) ;

        // ERIC Number
        x += width + BOUNDARY_WIDTH ;
        mainPanel.add( bookERICNumberLabel = new Label( "ERIC Number" ) ) ;
        bookERICNumberLabel.setBounds( x, y,
                                       width,
                                       LABEL_HEIGHT ) ;
        mainPanel.add( bookERICNumberField = new TextField( request.eric_no ) ) ;
        bookERICNumberField.setBounds( x, y + LABEL_HEIGHT,
                                       width,
                                       bookERICNumberField.getPreferredSize( ).height ) ;
        
        // Call Number
        x += width + BOUNDARY_WIDTH ;
        mainPanel.add( bookCallNumberLabel = new Label( "Call Number" ) ) ;
        bookCallNumberLabel.setBounds( x, y,
                                       width,
                                       LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( bookCallNumberField = new TextField( request.call_number ) ) ;
        bookCallNumberField.setBounds( x, y,
                                       width,
                                       bookCallNumberField.getPreferredSize( ).height ) ;

        // Dissertation
        x = width + 2 * BOUNDARY_WIDTH ;
        y += bookCallNumberField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        mainPanel.add( bookDissertationCheckbox = new Checkbox( "Dissertation", request.dissertation ) ) ;
        bookDissertationCheckbox.setBounds( BOUNDARY_WIDTH, y, width, CHECKBOX_HEIGHT ) ;
        
        // Conference
        mainPanel.add( bookConferenceCheckbox = new Checkbox( "Proceedings", request.conference ) ) ;
        bookConferenceCheckbox.setBounds( x, y, width, CHECKBOX_HEIGHT ) ;
        
        // Library check verification
        y += CHECKBOX_HEIGHT + BOUNDARY_WIDTH ;
        mainPanel.add( bookVerifiedLabel = new Label( "Have you checked " + htmlParams.libraryName + " for this item?" ) ) ;
        bookVerifiedLabel.setFont( requiredFont ) ;
        bookVerifiedLabel.setBounds( BOUNDARY_WIDTH,
                                     y,
                                     APPLET_WIDTH - MENU_BAR_WIDTH - 2 * BOUNDARY_WIDTH,
                                     LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( requestVerifiedYes = new Checkbox( "Yes", requestVerified, false ) ) ;
        requestVerifiedYes.setBounds( BOUNDARY_WIDTH,
                                      y,
                                      width,
                                      CHECKBOX_HEIGHT ) ;
        mainPanel.add( requestVerifiedNo = new Checkbox( "No", requestVerified, false ) ) ;
        requestVerifiedNo.setBounds( x, y,
                                     width,
                                     CHECKBOX_HEIGHT ) ;
        
        // If the online catalog URL is available, provide a button link to it.
        if ( !isEmpty( htmlParams.onlineCatalogURL ) )
        {
            mainPanel.add( bookOnlineCatalogButton = new LinuxSafeButton( htmlParams.libraryName + " Online Catalog" ) ) ;
            bookOnlineCatalogButton.addActionListener( this ) ;
            bookOnlineCatalogButton.addMouseListener( this ) ;
            bookOnlineCatalogButton.setBounds( x + width + BOUNDARY_WIDTH,
                                             y,
                                             2 * width + BOUNDARY_WIDTH,
                                             BUTTON_HEIGHT ) ;
            y += BUTTON_HEIGHT + 2 * BOUNDARY_WIDTH ;
        }
        else
        {
            y += CHECKBOX_HEIGHT + BOUNDARY_WIDTH ;
        }
        
        // Need-before date
        width = ( APPLET_WIDTH - MENU_BAR_WIDTH - 3 * BOUNDARY_WIDTH ) / 2 ;
        x = width + 2 * BOUNDARY_WIDTH ;
        mainPanel.add( bookNeedBeforeLabel = new Label( "Enter the date this item is needed by. The default date is pre-entered." ) ) ;
        bookNeedBeforeLabel.setFont( requiredFont ) ;
        bookNeedBeforeLabel.setBounds( BOUNDARY_WIDTH,
                                       y,
                                       APPLET_WIDTH - MENU_BAR_WIDTH - 2 * BOUNDARY_WIDTH,
                                       LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( requestNeedBeforeField = new TextField( ) ) ;
        requestNeedBeforeField.setText( getDefaultNeedBeforeString( request.need_before_date ) ) ;
        requestNeedBeforeField.setBounds( BOUNDARY_WIDTH,
                                          y,
                                          width,
                                          requestNeedBeforeField.getPreferredSize( ).height ) ;
        
        // Citation source
        y += requestNeedBeforeField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        mainPanel.add( bookSourceOfCitationLabel = new Label( "Source of Citation" ) ) ;
        bookSourceOfCitationLabel.setBounds( BOUNDARY_WIDTH,
                                             y,
                                             width,
                                             LABEL_HEIGHT ) ;
        mainPanel.add( requestSourceOfCitationChoice = new Choice( ) ) ;
        requestSourceOfCitationChoice.addItem( "" ) ;
        requestSourceOfCitationChoice.addItem( "Printed Source" ) ;
        requestSourceOfCitationChoice.addItem( "Online Source" ) ;
        requestSourceOfCitationChoice.select( request.source ) ;
        requestSourceOfCitationChoice.addItemListener( this ) ;
        requestSourceOfCitationChoice.setBounds( BOUNDARY_WIDTH,
                                                 y + LABEL_HEIGHT,
                                                 width,
                                                 requestSourceOfCitationChoice.getPreferredSize( ).height ) ;
        
        // Details of Citation
        mainPanel.add( requestDetailsOfCitationLabel = new Label( "Details of Citation" ) ) ;
        requestDetailsOfCitationLabel.setBounds( x, y,
                                                 width,
                                                 LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( requestDetailsOfCitationField = new TextField( request.source_details ) ) ;
        requestDetailsOfCitationField.setBounds( x, y,
                                                 width,
                                                 requestDetailsOfCitationField.getPreferredSize( ).height ) ;
        
        if ( isEmpty( request.source ) )
        {
            requestDetailsOfCitationLabel.setVisible( false ) ;
            requestDetailsOfCitationField.setVisible( false ) ;
        }
        
        // Patron notes
        y += requestDetailsOfCitationField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        width = APPLET_WIDTH - MENU_BAR_WIDTH - 2 * BOUNDARY_WIDTH ;
        mainPanel.add( bookPatronNotesLabel = new Label( "Enter any additional comments helpful to ordering this item." ) ) ;
        bookPatronNotesLabel.setBounds( BOUNDARY_WIDTH,
                                        y,
                                        width,
                                        LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( requestPatronNotesTextArea = new TextArea( request.patron_notes, width / 10, 5, TextArea.SCROLLBARS_VERTICAL_ONLY ) ) ;
        requestPatronNotesTextArea.setBounds( BOUNDARY_WIDTH,
                                              y,
                                              width,
                                              5 * LABEL_HEIGHT ) ;
        
        // Save Book Request Button
        y += 5 * LABEL_HEIGHT + 2 * BOUNDARY_WIDTH ;
        mainPanel.add( bookSaveRequestButton = new LinuxSafeButton( "Save Book Request" ) ) ;
        bookSaveRequestButton.setFont( requiredFont ) ;
        bookSaveRequestButton.setBounds( BOUNDARY_WIDTH,
                                         y,
                                         width,
                                         BUTTON_HEIGHT ) ;
        bookSaveRequestButton.addActionListener( this ) ;
        bookSaveRequestButton.addMouseListener( this ) ;
        
        //
        // Redraw the main panel.
        //
        repaint( ) ;
        
        //
        // Set the initial focus to the book author field.
        //
        requestAuthorField.requestFocus( ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Periodical Request Panel
    //
    private void createPeriodicalRequestPanel( RequestInformation request )
    {
        //
        // Local variables
        //
        int x, y, width ;
        Font requiredFont = new Font( "SansSerif", Font.BOLD, 12 ) ;
        Label perRequestTitle ;
        Label perAuthorLabel ;
        Label perArticleTitleLabel ;
        Label perTitleLabel ;
        Label perPublicationDateLabel ;
        Label perISSNLabel ;
        Label perVolumeLabel ;
        Label perIssueLabel ;
        Label perPaginationLabel ;
        Label perVerifiedLabel ;
        Label perNeedBeforeLabel ;
        Label perSourceOfCitationLabel ;
        Label perPatronNotesLabel ;
        Label copyrightWarningLabel ;
        Label copyrightAgreementLabel ;
        TextArea copyrightAgreementText ;

        //
        // Remove all components from the main panel.
        //
        mainPanel.removeAll( ) ;
    
        //
        // Create and add the book request components.
        //
        mainPanel.add( perRequestTitle = new Label( "Article Request Form" ) ) ;
        perRequestTitle.setFont( new Font( "Serif", Font.BOLD, 24 ) ) ;
        perRequestTitle.setAlignment( Label.CENTER ) ;
        perRequestTitle.setBounds( 0,
                                   0,
                                   APPLET_WIDTH - MENU_BAR_WIDTH,
                                   28 ) ;
        
        // Author
        width = APPLET_WIDTH - MENU_BAR_WIDTH - 2 * BOUNDARY_WIDTH ;
        y = 28 + BOUNDARY_WIDTH ;
        mainPanel.add( perAuthorLabel = new Label( "Author or Editor of Article" ) ) ;
        perAuthorLabel.setBounds( BOUNDARY_WIDTH,
                                  y,
                                  width,
                                  LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( requestAuthorField = new TextField( request.author ) ) ;
        requestAuthorField.setBounds( BOUNDARY_WIDTH,
                                      y,
                                      width,
                                      requestAuthorField.getPreferredSize( ).height ) ;

        // Title of article
        y += requestAuthorField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        mainPanel.add( perArticleTitleLabel = new Label( "Title of Article" ) ) ;
        perArticleTitleLabel.setFont( requiredFont ) ;
        perArticleTitleLabel.setBounds( BOUNDARY_WIDTH,
                                        y,
                                        width,
                                        LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( perArticleTitleField = new TextField( request.title_of_article ) ) ;
        perArticleTitleField.setBounds( BOUNDARY_WIDTH,
                                        y,
                                        width,
                                        perArticleTitleField.getPreferredSize( ).height ) ;
        
        // Title of periodical
        width = ( APPLET_WIDTH - MENU_BAR_WIDTH - 5 * BOUNDARY_WIDTH ) / 4 ;
        x = 3 * width + 4 * BOUNDARY_WIDTH ;
        y += perArticleTitleField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        mainPanel.add( perTitleLabel = new Label( "Title of Periodical or Journal (Do not abbreviate)" ) ) ;
        perTitleLabel.setFont( requiredFont ) ;
        perTitleLabel.setBounds( BOUNDARY_WIDTH,
                                 y,
                                 3 * width + 2 * BOUNDARY_WIDTH,
                                 LABEL_HEIGHT ) ;
        mainPanel.add( requestTitleField = new TextField( request.title ) ) ;
        requestTitleField.setBounds( BOUNDARY_WIDTH,
                                     y + LABEL_HEIGHT,
                                     3 * width + 2 * BOUNDARY_WIDTH,
                                     requestTitleField.getPreferredSize( ).height ) ;
        
        // Date of publication
        mainPanel.add( perPublicationDateLabel = new Label( "Date" ) ) ;
        perPublicationDateLabel.setFont( requiredFont ) ;
        perPublicationDateLabel.setBounds( x, y,
                                width,
                                LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( requestPublicationDateField = new TextField( request.publication_date ) ) ;
        requestPublicationDateField.setBounds( x, y,
                                               width,
                                               requestPublicationDateField.getPreferredSize( ).height ) ;
        
        // ISSN
        x = width + 2 * BOUNDARY_WIDTH ;
        y += requestPublicationDateField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        mainPanel.add( perISSNLabel = new Label( "ISSN (Recommended)" ) ) ;
        perISSNLabel.setBounds( BOUNDARY_WIDTH,
                                y,
                                width,
                                LABEL_HEIGHT ) ;
        mainPanel.add( perISSNField = new TextField( request.issn ) ) ;
        perISSNField.setBounds( BOUNDARY_WIDTH,
                                y + LABEL_HEIGHT,
                                width,
                                perISSNField.getPreferredSize( ).height ) ;
        
        // Volume
        mainPanel.add( perVolumeLabel = new Label( "Volume" ) ) ;
        perVolumeLabel.setBounds( x, y,
                                  width,
                                  LABEL_HEIGHT ) ;
        mainPanel.add( requestVolumeField = new TextField( request.volume ) ) ;
        requestVolumeField.setBounds( x, y + LABEL_HEIGHT,
                                      width,
                                      requestVolumeField.getPreferredSize( ).height ) ;
        
        // Issue
        x += width + BOUNDARY_WIDTH ;
        mainPanel.add( perIssueLabel = new Label( "Issue" ) ) ;
        perIssueLabel.setBounds( x, y,
                                 width,
                                 LABEL_HEIGHT ) ;
        mainPanel.add( perIssueField = new TextField( request.issue ) ) ;
        perIssueField.setBounds( x, y + LABEL_HEIGHT,
                                 width,
                                 perIssueField.getPreferredSize( ).height ) ;
        
        // Pages
        x += width + BOUNDARY_WIDTH ;
        mainPanel.add( perPaginationLabel = new Label( "Pages" ) ) ;
        perPaginationLabel.setFont( requiredFont ) ;
        perPaginationLabel.setBounds( x, y,
                                      width,
                                      LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( perPaginationField = new TextField( request.pagination ) ) ;
        perPaginationField.setBounds( x, y,
                                      width,
                                      perPaginationField.getPreferredSize( ).height ) ;
        
        // Library check verification
        y += CHECKBOX_HEIGHT + BOUNDARY_WIDTH ;
        x = width + 2 * BOUNDARY_WIDTH ;
        mainPanel.add( perVerifiedLabel = new Label( "Have you checked " + htmlParams.libraryName + " for this item?" ) ) ;
        perVerifiedLabel.setFont( requiredFont ) ;
        perVerifiedLabel.setBounds( BOUNDARY_WIDTH,
                                    y,
                                    APPLET_WIDTH - MENU_BAR_WIDTH - 2 * BOUNDARY_WIDTH,
                                    LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( requestVerifiedYes = new Checkbox( "Yes", requestVerified, false ) ) ;
        requestVerifiedYes.setBounds( BOUNDARY_WIDTH,
                                      y,
                                      width,
                                      CHECKBOX_HEIGHT ) ;
        mainPanel.add( requestVerifiedNo = new Checkbox( "No", requestVerified, false ) ) ;
        requestVerifiedNo.setBounds( x, y,
                                     width,
                                     CHECKBOX_HEIGHT ) ;
        
        // If the online catalog URL is available, provide a button link to it.
        if ( !isEmpty( htmlParams.periodicalHoldingsURL ) )
        {
            mainPanel.add( perHoldingsButton = new LinuxSafeButton( htmlParams.libraryName + " Periodical Holdings" ) ) ;
            perHoldingsButton.addActionListener( this ) ;
            perHoldingsButton.addMouseListener( this ) ;
            perHoldingsButton.setBounds( x + width + BOUNDARY_WIDTH,
                                         y,
                                         2 * width + BOUNDARY_WIDTH,
                                         BUTTON_HEIGHT ) ;
            y += BUTTON_HEIGHT + 2 * BOUNDARY_WIDTH ;
        }
        else
        {
            y += CHECKBOX_HEIGHT + BOUNDARY_WIDTH ;
        }
        
        // Need-before date
        width = ( APPLET_WIDTH - MENU_BAR_WIDTH - 3 * BOUNDARY_WIDTH ) / 2 ;
        x = width + 2 * BOUNDARY_WIDTH ;
        mainPanel.add( perNeedBeforeLabel = new Label( "Enter the date this item is needed by. The default date is pre-entered." ) ) ;
        perNeedBeforeLabel.setFont( requiredFont ) ;
        perNeedBeforeLabel.setBounds( BOUNDARY_WIDTH,
                                      y,
                                      APPLET_WIDTH - MENU_BAR_WIDTH - 2 * BOUNDARY_WIDTH,
                                      LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( requestNeedBeforeField = new TextField( ) ) ;
        requestNeedBeforeField.setText( getDefaultNeedBeforeString( request.need_before_date ) ) ;
        requestNeedBeforeField.setBounds( BOUNDARY_WIDTH,
                                          y,
                                          width,
                                          requestNeedBeforeField.getPreferredSize( ).height ) ;
        
        // Citation source
        y += requestNeedBeforeField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        mainPanel.add( perSourceOfCitationLabel = new Label( "Source of Citation" ) ) ;
        perSourceOfCitationLabel.setBounds( BOUNDARY_WIDTH,
                                            y,
                                            width,
                                            LABEL_HEIGHT ) ;
        mainPanel.add( requestSourceOfCitationChoice = new Choice( ) ) ;
        requestSourceOfCitationChoice.addItem( "" ) ;
        requestSourceOfCitationChoice.addItem( "Printed Source" ) ;
        requestSourceOfCitationChoice.addItem( "Online Source" ) ;
        requestSourceOfCitationChoice.select( request.source ) ;
        requestSourceOfCitationChoice.addItemListener( this ) ;
        requestSourceOfCitationChoice.setBounds( BOUNDARY_WIDTH,
                                                 y + LABEL_HEIGHT,
                                                 width,
                                                 requestSourceOfCitationChoice.getPreferredSize( ).height ) ;
        
        // Details of Citation
        mainPanel.add( requestDetailsOfCitationLabel = new Label( "Details of Citation" ) ) ;
        requestDetailsOfCitationLabel.setBounds( x, y,
                                                 width,
                                                 LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( requestDetailsOfCitationField = new TextField( request.source_details ) ) ;
        requestDetailsOfCitationField.setBounds( x, y,
                                                 width,
                                                 requestDetailsOfCitationField.getPreferredSize( ).height ) ;
        
        if ( isEmpty( request.source ) )
        {
            requestDetailsOfCitationLabel.setVisible( false ) ;
            requestDetailsOfCitationField.setVisible( false ) ;
        }
        
        // Patron notes
        y += requestDetailsOfCitationField.getPreferredSize( ).height + BOUNDARY_WIDTH ;
        width = APPLET_WIDTH - MENU_BAR_WIDTH - 2 * BOUNDARY_WIDTH ;
        mainPanel.add( perPatronNotesLabel = new Label( "Enter any additional comments helpful to ordering this item." ) ) ;
        perPatronNotesLabel.setBounds( BOUNDARY_WIDTH,
                                       y,
                                       width,
                                       LABEL_HEIGHT ) ;
        y += LABEL_HEIGHT ;
        mainPanel.add( requestPatronNotesTextArea = new TextArea( request.patron_notes, width / 10, 5, TextArea.SCROLLBARS_VERTICAL_ONLY ) ) ;
        requestPatronNotesTextArea.setBounds( BOUNDARY_WIDTH,
                                              y,
                                              width,
                                              5 * LABEL_HEIGHT ) ;
        
        // Copyright agreement
        y += 5 * LABEL_HEIGHT + BOUNDARY_WIDTH ;
        mainPanel.add( copyrightWarningLabel = new Label( "Warning Concerning Copyright Restrictions", Label.CENTER ) ) ;
        copyrightWarningLabel.setFont( requiredFont ) ;
        copyrightWarningLabel.setBounds( BOUNDARY_WIDTH, y, width, LABEL_HEIGHT ) ;
        
        y += LABEL_HEIGHT ;
        String copyrightAgreementString = new String( "The copyright law of the Unites States (Title 17, United States Code) governs the making of photocopies or other reproductions of copyrighted material. Under certain conditions specified in the law, libraries and archives are authorized to furnish a photocopy or other reproduction. One of these specified conditions is that the photocopy or other reproduction is not to be \"used for any purpose other than private study, scholarship, or research.\" If a user makes a request for, or later uses, a photocopy or reproduction for purposes in excess of \"fair use,\" that user may be liable for copyright infringement. This institution reserves the right to refuse to accept a copying order if, in its judgment, fulfillment of the order would involve violation of copyright.\n\n\n\n" ) ;
        mainPanel.add( copyrightAgreementText = new TextArea( copyrightAgreementString, width / 10, 5, TextArea.SCROLLBARS_VERTICAL_ONLY ) ) ;
        copyrightAgreementText.setEditable( false ) ;
        copyrightAgreementText.setBounds( BOUNDARY_WIDTH, y, width, 5 * LABEL_HEIGHT ) ;
        
        y += 5 * LABEL_HEIGHT ;
        mainPanel.add( copyrightAgreementLabel = new Label( "I agree to comply with these restrictions." ) ) ;
        copyrightAgreementLabel.setFont( requiredFont ) ;
        copyrightAgreementLabel.setBounds( BOUNDARY_WIDTH, y, width, LABEL_HEIGHT ) ;
        
        y += LABEL_HEIGHT ;
        mainPanel.add( perCopyAgreeYes = new Checkbox( "Yes", perCopyAgree, false ) ) ;
        perCopyAgreeYes.setBounds( BOUNDARY_WIDTH, y, width / 4, CHECKBOX_HEIGHT ) ;
        mainPanel.add( perCopyAgreeNo = new Checkbox( "No", perCopyAgree, false ) ) ;
        perCopyAgreeNo.setBounds( 2 * BOUNDARY_WIDTH + width / 4, y, width / 4, CHECKBOX_HEIGHT ) ;
        
        // Save Book Request Button
        y += CHECKBOX_HEIGHT + 2 * BOUNDARY_WIDTH ;
        mainPanel.add( perSaveRequestButton = new LinuxSafeButton( "Save Article Request" ) ) ;
        perSaveRequestButton.setFont( requiredFont ) ;
        perSaveRequestButton.setBounds( BOUNDARY_WIDTH,
                                        y,
                                        width,
                                        BUTTON_HEIGHT ) ;
        perSaveRequestButton.addActionListener( this ) ;
        perSaveRequestButton.addMouseListener( this ) ;
        
        //
        // Redraw the main panel.
        //
        repaint( ) ;
        
        //
        // Set the initial focus to the book author field.
        //
        requestAuthorField.requestFocus( ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  View Requests Panel
    //
    private void createViewRequestsPanel( )
    {
        //
        // Local variables.
        //
        Label viewTitleLabel ;
        int width = ( APPLET_WIDTH - MENU_BAR_WIDTH - 4 * BOUNDARY_WIDTH ) / 3 ;
    
        //
        // Remove all previous components from the panel.
        //
        mainPanel.removeAll( ) ;
        
        //
        // Create and add the about panel components to the main panel.
        //
        
        // Title
        mainPanel.add( viewTitleLabel = new Label( "View Requests Profile", Label.CENTER ) ) ;
        viewTitleLabel.setFont( new Font( "Serif", Font.BOLD, 24 ) ) ;
        viewTitleLabel.setBounds( 0, 0, 480, 28 ) ;
        
        // Delete All Button
        mainPanel.add( viewDeleteAllButton = new LinuxSafeButton( "Delete All Requests" ) ) ;
        viewDeleteAllButton.addActionListener( this ) ;
        viewDeleteAllButton.addMouseListener( this ) ;
        viewDeleteAllButton.setBounds( BOUNDARY_WIDTH, 28 + BOUNDARY_WIDTH, width, BUTTON_HEIGHT ) ;
        
        // Delete Button
        mainPanel.add( viewDeleteButton = new LinuxSafeButton( "Delete Request" ) ) ;
        viewDeleteButton.addActionListener( this ) ;
        viewDeleteButton.addMouseListener( this ) ;
        viewDeleteButton.setEnabled( false ) ;
        viewDeleteButton.setBounds( 2 * BOUNDARY_WIDTH + width, 28 + BOUNDARY_WIDTH,
                                    width, BUTTON_HEIGHT ) ;
        
        // Edit Button
        mainPanel.add( viewEditButton = new LinuxSafeButton( "View Details / Edit" ) ) ;
        viewEditButton.addActionListener( this ) ;
        viewEditButton.addMouseListener( this ) ;
        viewEditButton.setEnabled( false ) ;
        viewEditButton.setBounds( 3 * BOUNDARY_WIDTH + 2 * width, 28 + BOUNDARY_WIDTH,
                                  width, BUTTON_HEIGHT ) ;
        
        // View ListBox
        mainPanel.add( viewListBox = new List( 10, false ) ) ;
        viewListBox.addActionListener( this ) ;
        viewListBox.addItemListener( this ) ;
        viewListBox.setBounds( BOUNDARY_WIDTH, 28 + 2 * BOUNDARY_WIDTH + BUTTON_HEIGHT,
                               480 - 2 * BOUNDARY_WIDTH, 10 * LABEL_HEIGHT ) ;

        // Fill in the list box
        drawViewListBox( ) ;
        
        //
        // Redraw the applet with the about button pressed.
        //
        repaint( ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Submission Panel
    //
    private void createSubmissionPanel( )
    {
        //
        //  Local variables
        //
        Label submitTitleLabel ;
   
        //
        // Remove all previous components from the panel.
        //
        mainPanel.removeAll( ) ;
        
        // Main panel is updated because the previous components will not
        // disappear on removeAll( ).
        mainPanel.update( mainPanel.getGraphics( ) ) ;
        
        // Determine if the user is in fact ready to submit the requests.
        #if COMPILE_FOR_MICROSOFT
        int response = MessageBox.show(
            "Submitting the request(s) will terminate\n" + 
            "this session. You will need to restart the\n" +
            "program and reenter your user information\n" +
            "to submit additional requests.\nDo you want to do this?",
            "Submit Requests",
            MessageBox.ICONWARNING | MessageBox.YESNO | MessageBox.DEFBUTTON1
        ) ;
        
        if ( response == DialogResult.NO )
        {
            createInterimMessage( ) ;
            return ;
        }
        #endif
        
        //
        // Create and add the about panel components to the main panel.
        //
        
        // Title
        mainPanel.add( submitTitleLabel = new Label( "Request Submission", Label.CENTER ) ) ;
        submitTitleLabel.setFont( new Font( "Serif", Font.BOLD, 24 ) ) ;
        submitTitleLabel.setBounds( 0, 0, 464, 28 ) ;
        
        // Create a text area with the error/success message.
        mainPanel.add( submitResults = new TextArea( "Please wait while your request is being processed. This may take several seconds.", 5, 80, 
                                                     TextArea.SCROLLBARS_VERTICAL_ONLY ) ) ;
        submitResults.setEditable( false ) ;
        submitResults.setBounds( 80, 40, 360, 64 ) ;
            
        // Submission completed button.
        mainPanel.add( submitSubmissionComplete = new LinuxSafeButton( "Submission Complete � Exit Program" ) ) ;
        submitSubmissionComplete.setFont( new Font( "SansSerif", Font.BOLD, 12 ) ) ;
        submitSubmissionComplete.setEnabled( false ) ;
        submitSubmissionComplete.setBounds( 40, 112, 400, BUTTON_HEIGHT ) ;
        submitSubmissionComplete.addActionListener( this ) ;
        submitSubmissionComplete.addMouseListener( this ) ;
        
        userProfileButton.setEnabled( false ) ;
        bookRequestButton.setEnabled( false ) ;
        periodicalRequestButton.setEnabled( false ) ;
        viewRequestsButton.setEnabled( false ) ;
        submissionButton.setEnabled( false ) ;
        
        // Send the request and retrieve result
        RequestSender requestSender = new RequestSender( htmlParams,
                                                         userProfile, 
                                                         requestInformationList ) ;
        
        // Send the request and output the results of the submission.
        requestSender.send( ) ;
        submitResults.setText( requestSender.getMessage( ) ) ;
        int submissionStatus = requestSender.getStatus( ) ;
        
        // Enable the exit button.
        submitSubmissionComplete.setEnabled( true ) ;
        
        //
        // Redraw the applet.
        //
        Image stateImages[ ] = { getImage( getDocumentBase( ), "icon_information.gif" ),
                                 getImage( getDocumentBase( ), "icon_warning.gif" ),
                                 getImage( getDocumentBase( ), "icon_error.gif" ) } ;
        ImageCanvas ic = new ImageCanvas( stateImages[ submissionStatus ] ) ;
        mainPanel.add( ic ) ;
        ic.setBounds( 40, 40, 32, 32 ) ;
        
        // Display a contact if not receive by message. This may require some rework since
        // only the default date is provided and not the user defined date. 
        if ( submissionStatus != STATUS_ERROR )
        {
            Label notification1 = new Label( "If you do not receive the request by " + 
                                             getDefaultNeedBeforeString( null ) +
                                             "," ) ;
            Label notification2 = new Label( "call the Interlibrary Loan Department " +
                                             ( isEmpty( htmlParams.libraryPhone ) ? "" : 
                                             " at " + htmlParams.libraryPhone ) ) ;
            mainPanel.add( notification1 ) ;
            mainPanel.add( notification2 ) ;
            notification1.setBounds( 40, 150, 400, 14 ) ;
            notification2.setBounds( 40, 164, 400, 14 ) ;
        }
        
        repaint( ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  About Panel
    //  Literals are used to place the components on the about panel since the
    //  images must be drawn in the paint method and are drawn in exact
    //  locations.
    //
    private void createAboutPanel( )
    {
        // 
        // Local variables
        //
        Label versionLabel ;
        Label javaVersionLabel ;
        Label browserVersionLabel ;
        Label copyrightLabel ;
        Label addressLabel ;
        Label cityAndStateLabel ;
        Label licenseLabel ;
        Label libraryLabel ;
        Label institutionLabel ;
        Label creditsLabel ;
        String creditsString ;
        TextArea creditsTextArea ;
        Label testedLabel ;
        Label microsoftLabel ;
        Label netscapeLabel ;
        
        Toolkit toolkit = Toolkit.getDefaultToolkit( ) ;
        
        //
        // Remove all previous components from the panel.
        //
        mainPanel.removeAll( ) ;
        
        //
        // Create and add the about panel components to the main panel.
        //
        Image titleLogo = getImage( getDocumentBase( ), "illwizard.gif" ) ;
        ImageCanvas ic = new ImageCanvas( titleLogo ) ;
        mainPanel.add( ic ) ;
        ic.setBounds( 0, 0, 600, 101 ) ;
        
        // ILL Wizard Version
        mainPanel.add( versionLabel = new Label( "Version " + ILL_FORM_VERSION + " (OCLC Edition)" ) ) ;
        versionLabel.setBounds( 8, 106, 464, 14 ) ;
        
        // Developer Java Version
        mainPanel.add( javaVersionLabel = new Label( "Developed with the Microsoft SDK for Java 3.2 (Java 1.1 compliant)" ) ) ;
        javaVersionLabel.setBounds( 8, 120, 464, 14 ) ;
        
        // Browser Java Version
        mainPanel.add( browserVersionLabel = new Label( "Currently running in Java " + 
                                                        System.getProperty( "java.version" ) + 
                                                        " by " +  
                                                        System.getProperty( "java.vendor" ) ) ) ;
        browserVersionLabel.setBounds( 8, 134, 464, 14 ) ;
        
        // Creator
        mainPanel.add( copyrightLabel = new Label( "Copyright � 1999 by Bryan Wilhelm" ) ) ;
        copyrightLabel.setBounds( 8, 156, 464, 14 ) ;
        
        // Email
        mainPanel.add( aboutEmailLabel = new Label( "Email: " + DEVELOPERS_EMAIL ) ) ;
        int width = toolkit.getFontMetrics( aboutEmailLabel.getFont( ) ).stringWidth( "Email: " + DEVELOPERS_EMAIL ) + 4 ;
        aboutEmailLabel.setBounds( 8, 170, width, 14 ) ;
        aboutEmailLabel.setForeground( Color.blue ) ;
        aboutEmailLabel.setCursor( new Cursor( Cursor.HAND_CURSOR ) ) ;
        aboutEmailLabel.addMouseListener( this ) ;
        
        // Licensed to
        mainPanel.add( licenseLabel = new Label( "This product is licensed to" ) ) ;
        licenseLabel.setBounds( 8, 192, 464, 14 ) ;
        
        // Library
        mainPanel.add( libraryLabel = new Label( htmlParams.libraryName + " at" ) ) ;
        libraryLabel.setBounds( 8, 206, 464, 14 ) ;
        
        // Institution
        mainPanel.add( institutionLabel = new Label( htmlParams.institutionName ) ) ;
        institutionLabel.setBounds( 8, 220, 464, 14 ) ;
        
        HardRule hr = new HardRule( ) ;
        mainPanel.add( hr ) ;
        hr.setBounds( 8, 256, 464, 2 ) ;
        
        // Credits
        mainPanel.add( creditsLabel = new Label( "Credits" ) ) ;
        creditsLabel.setFont( new Font( "SansSerif", Font.BOLD, 14 ) ) ;
        creditsLabel.setBounds( 8, 270, 464, 17 ) ;
        
        creditsString = new String( "Microsoft SDK for Java 3.2:\n" +
                                    "Copyright � 1995-1999 Microsoft Corporation\n" +
                                    "One Microsoft Way, Redmond, Washington 98052-6399\n\n" ) ;
        creditsString += "Netscape Signing Tool 1.1:\n" +
                         "Copyright � 1999 Netscape Communications Corporation\n\n" ;
        creditsString += "BER/ASN.1 Java utilities:\n" +
                         "Copyright � 1996-1999 Online Computer Library Center (OCLC)\n" +
                         "6565 Frantz Road, Dublin, Ohio 43017.\n\n" ;
        creditsString += "Partially based on earlier work with ONU-ILL 3.2:\n" +
                         "Copyright � 1996-1999 Olivet Nazarene University\n" +
                         "240 Marsile Drive, Bourbonnais, Illinois 60914\n\n" ;
        
        mainPanel.add( creditsTextArea = new TextArea( creditsString, 5, 80, TextArea.SCROLLBARS_VERTICAL_ONLY ) ) ;
        creditsTextArea.setEditable( false ) ;
        creditsTextArea.setBounds( 8, 288, 464, 88 ) ;
        
        //
        // Redraw the applet with the about button pressed.
        //
        repaint( ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Interim Message Panel
    //
    private void createInterimMessage( ) 
    {
        // Local variables
        Label instructionLabel ;
        Label requestsMadeLabel ;
        Label requestsAvailableLabel ;
        Font basicFont = new Font( "SansSerif", Font.BOLD, 16 ) ;
        int yCoordinate = BOUNDARY_WIDTH ;
        int width = APPLET_WIDTH - MENU_BAR_WIDTH - 2 * BOUNDARY_WIDTH ;
        
        //
        // Remove all previous components from the panel.
        //
        mainPanel.removeAll( ) ;
        
        //
        // Determine the total number of requests made to this points.
        //
        numRequests = requestInformationList.size( ) ;
        
        //
        // Determine which message to post according to the number of
        // requests already made and the max number requests available.
        //
        
        // Create and add the basic instruction label.
        mainPanel.add( instructionLabel = new Label( "Select an option from the menu bar on the left." ) ) ;
        instructionLabel.setFont( basicFont ) ;
        instructionLabel.setBounds( BOUNDARY_WIDTH,
                                    yCoordinate,
                                    width,
                                    20 ) ;
        
        // Create and add the number of requests made label.
        yCoordinate += 32 ;
        mainPanel.add( requestsMadeLabel = new Label( "You have made " + numRequests + " request" + 
                     ( numRequests > 1 || numRequests == 0 ? "s" : "" ) + " so far. You may make" ) ) ;
        requestsMadeLabel.setFont( basicFont ) ;
        requestsMadeLabel.setBounds( BOUNDARY_WIDTH,
                                     yCoordinate,
                                     width,
                                     20 ) ;
        
        // Create and add the number of request available label.
        yCoordinate += 20 ;
        if ( htmlParams.maxRequests == Integer.MAX_VALUE )
        {
            mainPanel.add( requestsAvailableLabel = new Label( "as many requests as you need." ) ) ;
        }
        else
        {
            mainPanel.add( requestsAvailableLabel = new Label( "up to " + htmlParams.maxRequests + " request" +
                         ( htmlParams.maxRequests > 1 || htmlParams.maxRequests == 0 ? "s" : "" ) + "." ) ) ;
        }
        requestsAvailableLabel.setFont( basicFont ) ;
        requestsAvailableLabel.setBounds( BOUNDARY_WIDTH,
                                          yCoordinate,
                                          width,
                                          20 ) ;
        
        //
        // Enable or disable menu bar as needed.
        //
        
        // Enable book and periodical request button by default.
        bookRequestButton.setEnabled( true ) ;
        periodicalRequestButton.setEnabled( true ) ;
        
        // Enable or disable button based on number of requests.
        if ( numRequests == 0 )
        {
            viewRequestsButton.setEnabled( false ) ;
            submissionButton.setEnabled( false ) ;
        }
        else if ( numRequests < htmlParams.maxRequests )
        {
            viewRequestsButton.setEnabled( true ) ;
            submissionButton.setEnabled( true ) ;
        }
        else
        {
            bookRequestButton.setEnabled( false ) ;
            periodicalRequestButton.setEnabled( false ) ;
            viewRequestsButton.setEnabled( true ) ;
            submissionButton.setEnabled( true ) ;
        }
        
        //
        // Redraw the main panel.
        //
        repaint( ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  isEmpty( String s ) - A utility function that tests to see if a string
    //      is null or empty. The value true is returned if it is empty.
    //
    private boolean isEmpty( String s )
    { return ( s == null || s.equals( "" ) ) ; }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  translateColorString - A utility method that converts a
    //      string value into an appropriate color value. If the string cannot
    //      be properly converted, the color white is returned.
    //
    private Color translateColorString( String s, Color c )
    {
        Color color ;
        
        if ( isEmpty( s ) )
        {
            color = c ;
        }
        else if ( s.charAt( 0 ) == '#' && s.length( ) == 7 )
        {
            // Convert hex characters into decimal integer values. If the 
            // string is not in a correct numeric format, then the default
            // color is given in the parameter.
            try
            {
                int red = Integer.parseInt( s.substring( 1, 3 ), 16 ) ;
                int green = Integer.parseInt( s.substring( 3, 5 ), 16 ) ;
                int blue = Integer.parseInt( s.substring( 5 ), 16 ) ;
                color = new Color( red, green, blue ) ;
            }
            catch ( NumberFormatException formatException )
            {
                color = c ;
            }
        }
        // Look for color given by name. The default is the final option.
        else
        {
            if ( s.toUpperCase( ).equals( "BLACK" ) ) 
                color = Color.black ;
            else if ( s.toUpperCase( ).equals( "BLUE" ) ) 
                color = Color.blue ;
            else if ( s.toUpperCase( ).equals( "CYAN" ) ) 
                color = Color.blue ;
            else if ( s.toUpperCase( ).equals( "DARKGRAY" ) ) 
                color = Color.darkGray ;
            else if ( s.toUpperCase( ).equals( "GRAY" ) ) 
                color = Color.gray ;
            else if ( s.toUpperCase( ).equals( "GREEN" ) ) 
                color = Color.green ;
            else if ( s.toUpperCase( ).equals( "LIGHTGREY" ) ) 
                color = Color.lightGray ;
            else if ( s.toUpperCase( ).equals( "MAGENTA" ) ) 
                color = Color.magenta ;
            else if ( s.toUpperCase( ).equals( "ORANGE" ) ) 
                color = Color.orange ;
            else if ( s.toUpperCase( ).equals( "PINK" ) ) 
                color = Color.pink ;
            else if ( s.toUpperCase( ).equals( "RED" ) ) 
                color = Color.red ;
            else if ( s.toUpperCase( ).equals( "WHITE" ) ) 
                color = Color.white ;
            else if ( s.toUpperCase( ).equals( "YELLOW" ) ) 
                color = Color.yellow ;
            else if ( s.toUpperCase( ).equals( "ALICEBLUE" ) )
                color = new Color( 0xF0, 0xF8, 0xFF ) ;
            else if ( s.toUpperCase( ).equals( "ANTIQUEWHITE" ) )
                color = new Color( 0xFA, 0xEB, 0xD7 ) ;
            else if ( s.toUpperCase( ).equals( "AQUA" ) )
                color = new Color( 0x00, 0xFF, 0xFF ) ;
            else if ( s.toUpperCase( ).equals( "AQUAMARINE" ) )
                color = new Color( 0x7F, 0xFF, 0xD4 ) ;
            else if ( s.toUpperCase( ).equals( "AZURE" ) )
                color = new Color( 0xF0, 0xFF, 0xFF ) ;
            else if ( s.toUpperCase( ).equals( "BEIGE" ) )
                color = new Color( 0xF5, 0xF5, 0xDC ) ;
            else if ( s.toUpperCase( ).equals( "BISQUE" ) )
                color = new Color( 0xFF, 0xE4, 0xC4 ) ;
            else if ( s.toUpperCase( ).equals( "BLANCHEDALMOND" ) )
                color = new Color( 0xFF, 0xEB, 0xCD ) ;
            else if ( s.toUpperCase( ).equals( "BLUEVIOLET" ) )
                color = new Color( 0x8A, 0x2B, 0xE2 ) ;
            else if ( s.toUpperCase( ).equals( "BROWN" ) )
                color = new Color( 0xA5, 0x2A, 0x2A ) ;
            else if ( s.toUpperCase( ).equals( "BURLYWOOD" ) )
                color = new Color( 0xDE, 0xB8, 0x87 ) ;
            else if ( s.toUpperCase( ).equals( "CADETBLUE" ) )
                color = new Color( 0x5F, 0x9E, 0xA0 ) ;
            else if ( s.toUpperCase( ).equals( "CHARTREUSE" ) )
                color = new Color( 0x7F, 0xFF, 0x00 ) ;
            else if ( s.toUpperCase( ).equals( "CHOCOLATE" ) )
                color = new Color( 0xD2, 0x69, 0x1E ) ;
            else if ( s.toUpperCase( ).equals( "CORAL" ) )
                color = new Color( 0xFF, 0x7F, 0x50 ) ;
            else if ( s.toUpperCase( ).equals( "CORNFLOWER" ) )
                color = new Color( 0x64, 0x95, 0xED ) ;
            else if ( s.toUpperCase( ).equals( "CORNSILK" ) )
                color = new Color( 0xFF, 0xF8, 0xDC ) ;
            else if ( s.toUpperCase( ).equals( "CRIMSON" ) )
                color = new Color( 0xDC, 0x14, 0x3C ) ;
            else if ( s.toUpperCase( ).equals( "DARKBLUE" ) )
                color = new Color( 0x00, 0x00, 0x8B ) ;
            else if ( s.toUpperCase( ).equals( "DARKCYAN" ) )
                color = new Color( 0x00, 0x8B, 0x8B ) ;
            else if ( s.toUpperCase( ).equals( "DARKGOLDENROD" ) )
                color = new Color( 0xB8, 0x86, 0x0B ) ;
            else if ( s.toUpperCase( ).equals( "DARKGREEN" ) )
                color = new Color( 0x00, 0x64, 0x00 ) ;
            else if ( s.toUpperCase( ).equals( "DARKKHAKI" ) )
                color = new Color( 0xBD, 0xB7, 0x6B ) ;
            else if ( s.toUpperCase( ).equals( "DARKMAGENTA" ) )
                color = new Color( 0x8B, 0x00, 0x8B ) ;
            else if ( s.toUpperCase( ).equals( "DARKOLIVEGREEN" ) )
                color = new Color( 0x55, 0x6B, 0x2F ) ;
            else if ( s.toUpperCase( ).equals( "DARKORANGE" ) )
                color = new Color( 0xFF, 0x8C, 0x00 ) ;
            else if ( s.toUpperCase( ).equals( "DARKORCHID" ) )
                color = new Color( 0x99, 0x32, 0xCC ) ;
            else if ( s.toUpperCase( ).equals( "DARKRED" ) )
                color = new Color( 0x8B, 0x00, 0x00 ) ;
            else if ( s.toUpperCase( ).equals( "DARKSALMON" ) )
                color = new Color( 0xE9, 0x96, 0x7A ) ;
            else if ( s.toUpperCase( ).equals( "DARKSEAGREEN" ) )
                color = new Color( 0x8F, 0xBC, 0x8B ) ;
            else if ( s.toUpperCase( ).equals( "DARKSLATEBLUE" ) )
                color = new Color( 0x48, 0x3D, 0x8B ) ;
            else if ( s.toUpperCase( ).equals( "DARKSLATEGRAY" ) )
                color = new Color( 0x2F, 0x4F, 0x4F ) ;
            else if ( s.toUpperCase( ).equals( "DARKTURQUOISE" ) )
                color = new Color( 0x00, 0xCE, 0xD1 ) ;
            else if ( s.toUpperCase( ).equals( "DARKVIOLET" ) )
                color = new Color( 0x94, 0x00, 0xD3 ) ;
            else if ( s.toUpperCase( ).equals( "DEEPPINK" ) )
                color = new Color( 0xFF, 0x14, 0x93 ) ;
            else if ( s.toUpperCase( ).equals( "DEEPSKYBLUE" ) )
                color = new Color( 0x00, 0xBF, 0xFF ) ;
            else if ( s.toUpperCase( ).equals( "DIMGRAY" ) )
                color = new Color( 0x69, 0x69, 0x69 ) ;
            else if ( s.toUpperCase( ).equals( "DODGERBLUE" ) )
                color = new Color( 0x1E, 0x90, 0xFF ) ;
            else if ( s.toUpperCase( ).equals( "FIREBRICK" ) )
                color = new Color( 0xB2, 0x22, 0x22 ) ;
            else if ( s.toUpperCase( ).equals( "FLORALWHITE" ) )
                color = new Color( 0xFF, 0xFA, 0xF0 ) ;
            else if ( s.toUpperCase( ).equals( "FORESTGREEN" ) )
                color = new Color( 0x22, 0x8B, 0x22 ) ;
            else if ( s.toUpperCase( ).equals( "FUCHIA" ) )
                color = new Color( 0xFF, 0x00, 0xFF ) ;
            else if ( s.toUpperCase( ).equals( "GAINSBORO" ) )
                color = new Color( 0xDC, 0xDC, 0xDC ) ;
            else if ( s.toUpperCase( ).equals( "GHOSTWHITE" ) )
                color = new Color( 0xF8, 0xF8, 0xFF ) ;
            else if ( s.toUpperCase( ).equals( "GOLD" ) )
                color = new Color( 0xFF, 0xD7, 0x00 ) ;
            else if ( s.toUpperCase( ).equals( "GOLDENROD" ) )
                color = new Color( 0xDA, 0xA5, 0x20 ) ;
            else if ( s.toUpperCase( ).equals( "GREENYELLOW" ) )
                color = new Color( 0xAD, 0xFF, 0x2F ) ;
            else if ( s.toUpperCase( ).equals( "HONEYDEW" ) )
                color = new Color( 0xF0, 0xFF, 0xF0 ) ;
            else if ( s.toUpperCase( ).equals( "HOTPINK" ) )
                color = new Color( 0xFF, 0x69, 0xB4 ) ;
            else if ( s.toUpperCase( ).equals( "INDIANRED" ) )
                color = new Color( 0xCD, 0x5C, 0x5C ) ;
            else if ( s.toUpperCase( ).equals( "INDIGO" ) )
                color = new Color( 0x4B, 0x00, 0x82 ) ;
            else if ( s.toUpperCase( ).equals( "IVORY" ) )
                color = new Color( 0xFF, 0xFF, 0xF0 ) ;
            else if ( s.toUpperCase( ).equals( "KHAKI" ) )
                color = new Color( 0xF0, 0xE6, 0x8C ) ;
            else if ( s.toUpperCase( ).equals( "LAVENDER" ) )
                color = new Color( 0xE6, 0xE6, 0xFA ) ;
            else if ( s.toUpperCase( ).equals( "LAVENDERBLUSH" ) )
                color = new Color( 0xFF, 0xF0, 0xF5 ) ;
            else if ( s.toUpperCase( ).equals( "LAWNGREEN" ) )
                color = new Color( 0x7C, 0xFC, 0x00 ) ;
            else if ( s.toUpperCase( ).equals( "LEMONCHIFFON" ) )
                color = new Color( 0xFF, 0xFA, 0xCD ) ;
            else if ( s.toUpperCase( ).equals( "LIGHTBLUE" ) )
                color = new Color( 0xAD, 0xD8, 0xE6 ) ;
            else if ( s.toUpperCase( ).equals( "LIGHTCORAL" ) )
                color = new Color( 0xF0, 0x80, 0x80 ) ;
            else if ( s.toUpperCase( ).equals( "LIGHTCYAN" ) )
                color = new Color( 0xE0, 0xFF, 0xFF ) ;
            else if ( s.toUpperCase( ).equals( "LIGHTGOLDENRODYELLOW" ) )
                color = new Color( 0xFA, 0xFA, 0xD2 ) ;
            else if ( s.toUpperCase( ).equals( "LIGHTGREEN" ) )
                color = new Color( 0x90, 0xEE, 0x90 ) ;
            else if ( s.toUpperCase( ).equals( "LIGHTPINK" ) )
                color = new Color( 0xFF, 0xB6, 0xC1 ) ;
            else if ( s.toUpperCase( ).equals( "LIGHTSALMON" ) )
                color = new Color( 0xFF, 0xA0, 0x7A ) ;
            else if ( s.toUpperCase( ).equals( "LIGHTSEAGREEN" ) )
                color = new Color( 0x20, 0xB2, 0xAA ) ;
            else if ( s.toUpperCase( ).equals( "LIGHTSKYBLUE" ) )
                color = new Color( 0x87, 0xCE, 0xFA ) ;
            else if ( s.toUpperCase( ).equals( "LIGHTSLATEGRAY" ) )
                color = new Color( 0x77, 0x88, 0x99 ) ;
            else if ( s.toUpperCase( ).equals( "LIGHTSTEELBLUE" ) )
                color = new Color( 0xB0, 0xC4, 0xDE ) ;
            else if ( s.toUpperCase( ).equals( "LIGHTYELLOW" ) )
                color = new Color( 0xFF, 0xFF, 0xE0 ) ;
            else if ( s.toUpperCase( ).equals( "LIME" ) )
                color = new Color( 0x00, 0xFF, 0x00 ) ;
            else if ( s.toUpperCase( ).equals( "LIMEGREEN" ) )
                color = new Color( 0x32, 0xCD, 0x32 ) ;
            else if ( s.toUpperCase( ).equals( "LINEN" ) )
                color = new Color( 0xFA, 0xF0, 0xE6 ) ;
            else if ( s.toUpperCase( ).equals( "MAROON" ) )
                color = new Color( 0x80, 0x00, 0x00 ) ;
            else if ( s.toUpperCase( ).equals( "MEDIUMAQUAMARINE" ) )
                color = new Color( 0x66, 0xCD, 0xAA ) ;
            else if ( s.toUpperCase( ).equals( "MEDIUMBLUE" ) )
                color = new Color( 0x00, 0x00, 0xCD ) ;
            else if ( s.toUpperCase( ).equals( "MEDIUMORCHID" ) )
                color = new Color( 0xBA, 0x55, 0xD3 ) ;
            else if ( s.toUpperCase( ).equals( "MEDIUMPURPLE" ) )
                color = new Color( 0x93, 0x70, 0xDB ) ;
            else if ( s.toUpperCase( ).equals( "MEDIUMSEAGREEN" ) )
                color = new Color( 0x3C, 0xB3, 0x71 ) ;
            else if ( s.toUpperCase( ).equals( "MEDIUMSLATEBLUE" ) )
                color = new Color( 0x7B, 0x68, 0xEE ) ;
            else if ( s.toUpperCase( ).equals( "MEDIUMSPRINGGREEN" ) )
                color = new Color( 0x00, 0xFA, 0x9A ) ;
            else if ( s.toUpperCase( ).equals( "MEDIUMTURQUOISE" ) )
                color = new Color( 0x48, 0xD1, 0xCC ) ;
            else if ( s.toUpperCase( ).equals( "MEDIUMVIOLETRED" ) )
                color = new Color( 0xC7, 0x15, 0x85 ) ;
            else if ( s.toUpperCase( ).equals( "MIDNIGHTBLUE" ) )
                color = new Color( 0x19, 0x19, 0x70 ) ;
            else if ( s.toUpperCase( ).equals( "MINTCREAM" ) )
                color = new Color( 0xF5, 0xFF, 0xFA ) ;
            else if ( s.toUpperCase( ).equals( "MISTYROSE" ) )
                color = new Color( 0xFF, 0xE4, 0xE1 ) ;
            else if ( s.toUpperCase( ).equals( "MOCCASIN" ) )
                color = new Color( 0xFF, 0xE4, 0xB5 ) ;
            else if ( s.toUpperCase( ).equals( "NAVAJOWHITE" ) )
                color = new Color( 0xFF, 0xDE, 0xAD ) ;
            else if ( s.toUpperCase( ).equals( "NAVY" ) )
                color = new Color( 0x00, 0x00, 0x80 ) ;
            else if ( s.toUpperCase( ).equals( "OLDLACE" ) )
                color = new Color( 0xFD, 0xF5, 0xE6 ) ;
            else if ( s.toUpperCase( ).equals( "OLIVE" ) )
                color = new Color( 0x80, 0x80, 0x00 ) ;
            else if ( s.toUpperCase( ).equals( "OLIVEDRAB" ) )
                color = new Color( 0x6B, 0x8E, 0x23 ) ;
            else if ( s.toUpperCase( ).equals( "ORANGERED" ) )
                color = new Color( 0xFF, 0x45, 0x00 ) ;
            else if ( s.toUpperCase( ).equals( "ORCHID" ) )
                color = new Color( 0xDA, 0x70, 0xD6 ) ;
            else if ( s.toUpperCase( ).equals( "PALEGOLDENROD" ) )
                color = new Color( 0xEE, 0xE8, 0xAA ) ;
            else if ( s.toUpperCase( ).equals( "PALEGREEN" ) )
                color = new Color( 0x98, 0xFB, 0x98 ) ;
            else if ( s.toUpperCase( ).equals( "PALETURQUOISE" ) )
                color = new Color( 0xAF, 0xEE, 0xEE ) ;
            else if ( s.toUpperCase( ).equals( "PALEVIOLETRED" ) )
                color = new Color( 0xDB, 0x70, 0x93 ) ;
            else if ( s.toUpperCase( ).equals( "PAPAYAWHIP" ) )
                color = new Color( 0xFF, 0xEF, 0xD5 ) ;
            else if ( s.toUpperCase( ).equals( "PEACHPUFF" ) )
                color = new Color( 0xFF, 0xDA, 0xB9 ) ;
            else if ( s.toUpperCase( ).equals( "PERU" ) )
                color = new Color( 0xCD, 0x85, 0x3F ) ;
            else if ( s.toUpperCase( ).equals( "PLUM" ) )
                color = new Color( 0xDD, 0xA0, 0xDD ) ;
            else if ( s.toUpperCase( ).equals( "POWDERBLUE" ) )
                color = new Color( 0xB0, 0xE0, 0xE6 ) ;
            else if ( s.toUpperCase( ).equals( "PURPLE" ) )
                color = new Color( 0x80, 0x00, 0x80 ) ;
            else if ( s.toUpperCase( ).equals( "ROSYBROWN" ) )
                color = new Color( 0xBC, 0x8F, 0x8F ) ;
            else if ( s.toUpperCase( ).equals( "ROYALBLUE" ) )
                color = new Color( 0x41, 0x69, 0xE1 ) ;
            else if ( s.toUpperCase( ).equals( "SADDLEBROWN" ) )
                color = new Color( 0x8B, 0x45, 0x13 ) ;
            else if ( s.toUpperCase( ).equals( "SALMON" ) )
                color = new Color( 0xFA, 0x80, 0x72 ) ;
            else if ( s.toUpperCase( ).equals( "SANDYBROWN" ) )
                color = new Color( 0xF4, 0xA4, 0x60 ) ;
            else if ( s.toUpperCase( ).equals( "SEAGREEN" ) )
                color = new Color( 0x2E, 0x8B, 0x57 ) ;
            else if ( s.toUpperCase( ).equals( "SEASHELL" ) )
                color = new Color( 0xFF, 0xF5, 0xEE ) ;
            else if ( s.toUpperCase( ).equals( "SIENNA" ) )
                color = new Color( 0xA0, 0x52, 0x2D ) ;
            else if ( s.toUpperCase( ).equals( "SILVER" ) )
                color = new Color( 0xC0, 0xC0, 0xC0 ) ;
            else if ( s.toUpperCase( ).equals( "SKYBLUE" ) )
                color = new Color( 0x87, 0xCE, 0xEB ) ;
            else if ( s.toUpperCase( ).equals( "SLATEBLUE" ) )
                color = new Color( 0x6A, 0x5A, 0xCD ) ;
            else if ( s.toUpperCase( ).equals( "SLATEGRAY" ) )
                color = new Color( 0x70, 0x80, 0x90 ) ;
            else if ( s.toUpperCase( ).equals( "SNOW" ) )
                color = new Color( 0xFF, 0xFA, 0xFA ) ;
            else if ( s.toUpperCase( ).equals( "SPRINGGREEN" ) )
                color = new Color( 0x00, 0xFF, 0x7F ) ;
            else if ( s.toUpperCase( ).equals( "STEELBLUE" ) )
                color = new Color( 0x46, 0x82, 0xB4 ) ;
            else if ( s.toUpperCase( ).equals( "TAN" ) )
                color = new Color( 0xD2, 0xB4, 0x8C ) ;
            else if ( s.toUpperCase( ).equals( "TEAL" ) )
                color = new Color( 0x00, 0x80, 0x80 ) ;
            else if ( s.toUpperCase( ).equals( "THISTLE" ) )
                color = new Color( 0xD8, 0xBF, 0xD8 ) ;
            else if ( s.toUpperCase( ).equals( "TOMATO" ) )
                color = new Color( 0xFF, 0x63, 0x47 ) ;
            else if ( s.toUpperCase( ).equals( "TURQUOISE" ) )
                color = new Color( 0x40, 0xE0, 0xD0 ) ;
            else if ( s.toUpperCase( ).equals( "VIOLET" ) )
                color = new Color( 0xEE, 0x82, 0xEE ) ;
            else if ( s.toUpperCase( ).equals( "WHEAT" ) )
                color = new Color( 0xF5, 0xDE, 0xB3 ) ;
            else if ( s.toUpperCase( ).equals( "WHITESMOKE" ) )
                color = new Color( 0xF5, 0xF5, 0xF5 ) ;
            else if ( s.toUpperCase( ).equals( "YELLOWGREEN" ) )
                color = new Color( 0x9A, 0xCD, 0x32 ) ;
            else 
                color = c ;
        }
        
        return color ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  isValidSecurityMatrix( String matrix ) - confirms the validity of the
    //  access security matrix string.
    //
    private boolean isValidSecurityMatrix( String matrix )
    {
        int index ;
        StringTokenizer st = new StringTokenizer( matrix, "-" ) ;
        String check = st.nextToken( ) ;
        String authorization = st.nextToken( ) ;
        String password = st.nextToken( ) ;
        
        // Check for an extended matrix.
        if ( st.hasMoreTokens( ) )
        {
            return false ;
        }
        
        // Ensure that the check digit is only 2 character wide.
        if ( check.length( ) != 2 || isEmpty( authorization ) || isEmpty( password ) )
        {
            return false ;
        }
        
        // Get the check digit value.
        int checkSum = 0 ;
        
        for ( index = 0 ; index < authorization.length( ) ; index += 2 )
        {
            try 
            {
                checkSum += Integer.parseInt( authorization.substring( index, index + 2 ), 16 ) ;
            }
            catch ( NumberFormatException nfe1 )
            {
                return false ;
            }
        }
        
        for ( index = 0 ; index < password.length( ) ; index += 2 )
        {
            try
            {
                checkSum += Integer.parseInt( password.substring( index, index + 2 ), 16 ) ;
            }
            catch ( NumberFormatException nfe2 )
            {
                return false ;
            }
        }
        
        try
        {
            if ( ( checkSum % 251 ) != Integer.parseInt( check, 16 ) )
            {
                return false ;
            }
        }
        catch ( NumberFormatException nfe3 )
        {
            return false ;
        }
        
        return true ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  extractAuthorizationFromMatrix( String matrix )
    //
    private String extractAuthorizationFromMatrix( String matrix )
    {
        StringTokenizer st = new StringTokenizer( matrix, "-" ) ;
        String check = st.nextToken( ) ;
        String authorization = st.nextToken( ) ;
        String password = st.nextToken( ) ;

        byte array[ ] = new byte[ 32 ] ;
        int arrayLoc = 0 ;
        
        for ( int index = 0 ; index < authorization.length( ) ; /* increment inside loop */ )
        {
            try
            {
                array[ arrayLoc++ ] = ( byte ) ( Integer.parseInt( authorization.substring( index, index + 2 ), 16 ) / 2 + 32 ) ;
            }
            catch ( NumberFormatException nfe )
            {
                return null ;
            }
            
            index += 2 ;
            
            // Replace the hyphen in the authorization. This may not be necessary if other
            // vendors do not use this.
            if ( index % 6 == 0 && index < authorization.length( ) )
                 array[ arrayLoc++ ] = ( byte ) '-' ;
        }
        
        return new String( array ).trim( ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  extractPasswordFromMatrix( String matrix )
    //
    private String extractPasswordFromMatrix( String matrix )
    {
        StringTokenizer st = new StringTokenizer( matrix, "-" ) ;
        String check = st.nextToken( ) ;
        String authorization = st.nextToken( ) ;
        String password = st.nextToken( ) ;
        
        byte array[ ] = new byte[ 32 ] ;
        int arrayLoc = 0 ;
        
        for ( int index = 0 ; index < password.length( ) ; index += 2 )
        {
            try
            {
                array[ arrayLoc++ ] = ( byte ) ( Integer.parseInt( password.substring( index, index + 2 ), 16 ) / 2 + 32 ) ;
            }
            catch ( NumberFormatException nfe )
            {
                return null ;
            }
        }
        
        return new String( array ).trim( ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  getDefaultNeedBeforeString( String date ) - takes a properly formatted
    //  date string and a string with in a long formatted date, or returns a 
    //  long format date string with a predetermined number of days added to
    //  the current date.
    //
    private String getDefaultNeedBeforeString( String date )
    {
        // Local variables.
        Calendar calendar ;
        DateFormat dateFormat = DateFormat.getDateInstance( DateFormat.LONG ) ;
        
        if ( isEmpty( date ) )
        {
            // Initialize the calendar object to the default needbefore date.
            calendar = Calendar.getInstance( ) ;
            calendar.setTime( DEFAULT_NEEDBEFORE_DATE ) ;
        }
        else
        {
            // Convert the formatted date string to a calendar object.
            calendar = ILL_Date.getCalendarDate( date ) ;
        }
        
        // Convert the calendar into a long format string.
        return dateFormat.format( calendar.getTime( ) ) ;
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  drawViewListBox
    //
    private void drawViewListBox( )
    {
        // Local variables.
        String viewListItem ;
        RequestInformation request ;
        
        // Clear the list box of any previous contents.
        viewListBox.removeAll( ) ;
        
        // Cycle through all the requests made to this point.
        for ( int i = 0 ; i < numRequests ; i++ )
        {
            // Get the next request on the list
            request = ( RequestInformation ) requestInformationList.elementAt( i ) ;
            
            // Determine the type of the request and create the item string
            if ( request.request_type == BOOK_REQUEST )
            {
                viewListItem = new String( "BOOK:  " ) ;
                viewListItem += request.title + " (" + request.author + ")." ;
            }
            else
            {
                viewListItem = new String( "ARTICLE:  " ) ;
                viewListItem += "\"" + request.title_of_article + "\" in " + request.title ;
                if ( !isEmpty( request.author ) )
                {
                    viewListItem += " (" + request.author + ")." ;
                }
                else
                {
                    viewListItem += "." ;
                }
            }
            
            // Add the item to the list
            viewListBox.add( viewListItem ) ;
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////
    //
    //  Required implementations by MouseListener.
    //
    public void mousePressed( MouseEvent mousePressed ) {  }
    public void mouseReleased( MouseEvent mouseReleased ) {  }
}
