ONU_ILL
Version 3.2 (Java 2.1/Applet)

September 11, 1998


--------------------------------------------------------------------------
INTRODUCTION
--------------------------------------------------------------------------
The ONU_ILL Java applet is designed to automate the interlibrary loan
patron request process.  It provides a graphical user interface for entry
of the request data, and compiles the data into proper format (ISO 10161) 
for submission through OCLC's Direct Request program.


--------------------------------------------------------------------------
VERSION INFORMATION
--------------------------------------------------------------------------
ONU_ILL version 3.2 is the applet edition of the Java application (version 
3.1).  Version 3.2 can be mounted on any web server.

Version 3.0 was intended for use with OCLC's IPT request method but
was never released.  Previous versions (2.x and before) were CGI programs
written in C and intended for UNIX (System V) platforms.


--------------------------------------------------------------------------
DISTRIBUTION
--------------------------------------------------------------------------
This archive file (onu-ill-3.2.zip) contains the following:

ONU_ILL.html  -- The web page that calls the applet.
README        -- This document.

In addition there are four directories that contain additional necessary
programs and the source code to the applet.

linux         -- Contains utilities for Linux.
solaris       -- Contains utilities for Solaris.
winnt         -- Contains utilities for Windows NT.
source        -- Contains the 28 Java source files for the applet.


--------------------------------------------------------------------------
INSTALLATION
--------------------------------------------------------------------------
To install ONU_ILL 3.2 to a web server:

    1.  MODIFY THE HTML PAGE.
        The HTML page can be changed in any fashion without changing the 
        applet's ability to function properly.  After changing the look of
        the HTML page, the applet parameters will need to be changed to 
        fit your institution.  The parameters (also described in the HTML 
        file) are:

            Background-Color        The background color of the applet
                                    (possible values are listed in the
                                    HTML file).
            Institution-Name        The name of the sponsoring institution
                                    normally the name of the university
            Library-Name            The name of the borrowing library.
            Library-Symbol          The three letter symbol assigned by
                                    OCLC to the borrowing institution
            ILL-Service-Type        The Direct Request method that should
                                    be used to process the requests.
                                    Possible values are:
                                        "LENDER"
                                        "PROFILE"
                                        "REVIEW FILE"
            Lender-List             If "LENDER" is given as the service
                                    type, then a lender list must be
                                    given here.
            Max-Requests            The maximum number of requests that a
                                    patron may make in a session.  This
                                    must be an integer value.  If "0" is
                                    given then there is no limit.
            Delivery-Name
            Delivery-Extension
            Delivery-Street
            Delivery-POBox
            Delivery-City
            Delivery-State
            Delivery-Country
            Delivery-ZIP-Code
            Delivery-Service        Reciprocal agreements or affiliations.
            Electronic-Service      Electronic affiliations or services.
            Library-Fax             The fax number of the borrowing
                                    library or interlibrary loan 
                                    department.
            Library-Email           The email address of the borrowing
                                    library or interlibrary loan
                                    department.
            Max-Cost                The maximum cost allowed per request
                                    by the borrowing library.
            Book-Note               The borrowers note associated with
                                    book request's.
            Periodical-Note         The borrower's note associated with
                                    periodical requests.
            Return-Location         The web page that the applet should 
                                    send the patron to after completion of
                                    the request.  This must be a valid,
                                    absolute address.

    2.  MODIFY THE JAVA SOURCE AND RECOMPILE
        In the source directory, open the file ONU_ILL_CONST.java.  Below
        the comment that reads "THESE MUST BE MODIFIED" are two constant
        variables named "AUTHORIZATION" and "PASSWORD".  These must be
        changed to match your PRISM authorization and password.  Save the
        file and close it.

        Recompile all Java files with the Java Development Kit (JDK) 1.0.2
        from Sun Microsystems (available at http://java.sun.com).  The
        command will be "javac -O *.java".  This will generate the class
        files for the applet.  
        
        Finally, archive the class files with the JAR utility provided in 
        the directory that best fits your server type.  The command will 
        be "jar -cf ONU_ILL.jar *.class".
        
    3.  UPLOAD FILES.
        After the page and applet have been modified to meet your needs, 
        upload ONU_ILL.html and ONU_ILL.jar into the same web directory.

    4.  SET UP SERVER PORT REDIRECTION.
        The ONU_ILL distribution creates three directories containing
        different versions of the redir program according to server
        platform:  linux, solaris, and winnt.  Use the version that 
        corresponds to the platform type of the web server.

        View the redir README file for more information about this 
        program.  The setup instructions below will also be helpful.

        ------------------------------------------------------------------
        Linux Servers
        ------------------------------------------------------------------
        The linux directory contains the executable "redir".  It should be 
        copied to the server, preferrably in a location that is in the 
        PATH (possibly /usr/bin).  To start the redir program, at the shell 
        prompt type:

            redir target-addr target-port listen-port

        where "target-addr" is the target server to be redirected to,
        "target-port" is the port on the target server to go to, and
        "listen-port" is the port to be used on the local server.  The
        first time that it is used will be to test the ONU_ILL program,
        and set up Direct Request with OCLC.  The redir command will look
        like this:

            redir testenv.oclc.org 5771 5771 &

        This will send all incoming data from the applet to OCLC's test
        site on port 5771 from 5771 on your server.  The "&" will run the
        redir program in background so that other programs can run when it
        isn't.  This command can also be put in the ".profile" so that it 
        starts running whenever the server to rebooted.

        ------------------------------------------------------------------
        Solaris Servers
        ------------------------------------------------------------------
        The solaris directory contains the executable "redir".  It should 
        be copied to the server, preferrably in a location that is in the 
        PATH (possibly /usr/bin).  To start the redir program, at the 
        shell prompt type:

            redir target-addr target-port listen-port

        where "target-addr" is the target server to be redirected to,
        "target-port" is the port on the target server to go to, and
        "listen-port" is the port to be used on the local server.  The
        first time that it is used will be to test the ONU_ILL program,
        and set up Direct Request with OCLC.  The redir command will look
        like this:

            redir testenv.oclc.org 5771 5771 &

        This will send all incoming data from the applet to OCLC's test
        site on port 5771 from 5771 on your server.  The "&" will run the
        redir program in background so that other programs can run when it
        isn't.  This command can also be put in the ".profile" so that it 
        starts running whenever the server to rebooted.

        ------------------------------------------------------------------
        Windows NT Servers
        ------------------------------------------------------------------
        The winnt directory contains the executable "redir.exe".  It 
        should be copied to the server, preferrably in a location that is
        in the PATH (possibly /WINNT/SYSTEM).  To start the redir program, 
        at the command prompt type:

            redir target-addr target-port listen-port

        where "target-addr" is the target server to be redirected to,
        "target-port" is the port on the target server to go to, and
        "listen-port" is the port to be used on the local server.  The
        first time that it is used will be to test the ONU_ILL program,
        and set up Direct Request with OCLC.  The redir command will look
        like this:

            redir testenv.oclc.org 5771 5771

        This will send all incoming data from the applet to OCLC's test
        site on port 5771 from 5771 on your server.  This command can also 
        be put in the Startup Group so that it starts running whenever the 
        server is rebooted.

    ----------------------------------------------------------------------
    Once these steps are done, the applet will be ready to run.  After all
    the steps in OCLC's Direct Request planning guide have been completed,
    and testing is done, OCLC will provide you with more information so 
    that patrons can begin using the applet to request materials.
    
    
    **********************************************************************
    IMPORTANT NOTE
    **********************************************************************
    This applet will not function properly until the OCLC Direct Request 
    planning guide has been completed.  OCLC will supply the address and 
    port of their interlibrary loan production server.  At that time the
    redir program will need to be terminated and restarted with the new
    target location.

    The URL of the planning guide is:
    http://www.oclc.org/oclc/specs/dillspec.htm




