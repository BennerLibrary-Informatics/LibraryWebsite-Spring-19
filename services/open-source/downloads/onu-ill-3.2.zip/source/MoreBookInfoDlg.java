import java.awt.*;

public class MoreBookInfoDlg extends Dialog implements ILL_API, ONU_ILL_CONST
    {
        // Attributes
        // These properties are local to MoreInfoDlg and are not in the scope
        // of BookFormDlg.  However, the properties of BookFormDlg are in the
        // scope of MoreInfoDlg.
        private Button        btn_ok, 
                              btn_cancel;
        private Checkbox      cb_oclcNum,
                              cb_ericNum,
                              cb_dissertation,     // DISSERTATION_NOTE
                              cb_conference;       // +DISSERTATION_NOTE
        private TextField     tf_oclcNum,          // OCLC_NO
                              tf_ericNum;          // PATRON_NOTES
        private InfoTextField tf_whereFound;       // +PATRON_NOTES
        private TextArea      ta_comments;         // +PATRON_NOTES

        private Toolkit sys_metrics = Toolkit.getDefaultToolkit( );
        private Font    boldFont = new Font( "Sans Serif", Font.BOLD, 11 );

        ItemInfo request;

        // Constructor
        public MoreBookInfoDlg( Frame parent, ItemInfo r, int n )
        {
            // Call dialog superclass constructor
            super( parent, "Item " + n + ":  Additional Information", true );

            request = r;

            // Set window size, layout, and listeners
            setResizable( false );
            setLayout( null );
            setFont( new Font( "Sans Serif", Font.PLAIN, 11 ) );

            // Create dialog box components
            Label illTitle = new Label( "Interlibrary Loan" );
            Label formTitle = new Label( "Book Request Form" );
            illTitle.setFont( new Font( "Serif", Font.BOLD + Font.ITALIC, 24 ) );
            formTitle.setFont( new Font( "Serif", Font.BOLD + Font.ITALIC, 24 ) );

            cb_oclcNum = new Checkbox( "OCLC Number" );
            cb_ericNum = new Checkbox( "ERIC Document Number" );
            cb_dissertation = new Checkbox( "Dissertation/Thesis" );
            cb_conference = new Checkbox( "Conference Proceedings" );

            tf_whereFound = new InfoTextField( "Source of citation", 32 );
            Label commentsLabel = new Label( "Enter any comments helpful to order " +
                "this item" );
            ta_comments = new TextArea( 32, 10 );

            btn_ok = new Button( "OK" );
            btn_ok.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
            btn_cancel = new Button( "Cancel" );
            btn_cancel.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );

            // Add components to the dialog box.
            add( illTitle );
            add( formTitle );
            add( cb_oclcNum );
            add( tf_oclcNum = new TextField( ) );
            add( cb_ericNum );
            add( tf_ericNum = new TextField( ) );
            add( cb_dissertation );
            add( cb_conference );
            add( tf_whereFound );
            add( commentsLabel );
            add( ta_comments );
            add( btn_ok );
            add( btn_cancel );

            // Set the location and bounds of the dialog components.
            illTitle.reshape( 24, 24, 384, 27 );
            formTitle.reshape( 24, 51, 384, 27 );

            cb_oclcNum.reshape( 36, 86, 164, 15 );
            cb_ericNum.reshape( 36, 112, 164, 15 );
            cb_dissertation.reshape( 36, 138, 164, 15 );
            cb_conference.reshape( 36, 164, 164, 15 );
            tf_oclcNum.reshape( 240, 85, 180, 20 );
            tf_ericNum.reshape( 240, 111, 180, 20 );

            tf_whereFound.reshape( 36, 200,
                ( tf_whereFound.getSize( ) ).width,
                ( tf_whereFound.getSize( ) ).height );
            commentsLabel.reshape( 36, 246, 300, 14 );
            ta_comments.reshape( 36, 262, 384, 60 );

            btn_ok.reshape( 280, 346, 64, 24 );
            btn_cancel.reshape( 356, 346, 64, 24 );

            // Display dialog box in the center of the screen.
            int x = (int)( ( ( sys_metrics.getScreenSize( ) ).width - 456 ) / 2 );
            int y = (int)( ( ( sys_metrics.getScreenSize( ) ).height - 456 ) / 2 );
            reshape( x, y, 456, 406 );
            show( );

        } // end constructor

        public void paint( Graphics g )
        {
            // Draw 3D rectangle
            //g.draw3DRect( 18, 93, 420, 149, false );
            //g.draw3DRect( 18, 261, 420, 145, false );

            // Hide the two text fields.  All components are visible after the
            // constructor terminates.  This method is automatically called
            // after the constructor.
            tf_oclcNum.hide( );
            tf_ericNum.hide( );
        }


        public boolean action( Event e, Object o )
        {
            // If "OK" was pressed, process fields,
            if ( e.target == btn_ok ) {

                request.oclc_no = new String( tf_oclcNum.getText( ) );
                request.patron_notes = new String( tf_ericNum.getText( ) );
                request.dissertation = new String( cb_dissertation.getLabel( ) );

                if ( request.dissertation.equals( BLANK ) ) {
                    request.dissertation = 
                        cb_conference.getState( ) ? cb_conference.getLabel( ) : // box was checked
                                                    BLANK;                      // box was not checked
                } else {
                    request.dissertation +=
                        cb_conference.getState( ) ? cb_conference.getLabel( ) :  // box was checked
                                                    BLANK;                       // box was not checked
                }


                // If you don't understand this, then stay away from my code!!!
                if ( request.patron_notes.equals( BLANK ) ) {
                    if ( ( request.patron_notes = tf_whereFound.getText( ) ).equals( BLANK ) ) {
                        request.patron_notes = ta_comments.getText( );
                    } else {
                        request.patron_notes += ta_comments.getText( );
                    }
                } else {
                    if ( ( request.patron_notes += tf_whereFound.getText( ) ).equals( BLANK ) ) {
                        request.patron_notes = ta_comments.getText( );
                    } else {
                        request.patron_notes += ta_comments.getText( );
                    }
                }

            }

            else if ( e.target == cb_oclcNum || e.target == cb_ericNum ) {
                // Display the text fields based on the state of the check box.
                tf_oclcNum.show( cb_oclcNum.getState( ) );
                tf_ericNum.show( cb_ericNum.getState( ) );

                return true;
            }
            else if ( e.target == cb_conference || e.target == cb_dissertation ) {
                return true;
            }

            // else "Cancel" was pressed--don't do anything.

            // This is done when either button is pressed.
            hide( );
            dispose( );

            return true;
        }

    }
