import java.util.*;

public class IsoIllRequest implements ILL_ASN, ILL_API, ONU_ILL_CONST
{
    public String
        service_date,                       // request date
        transaction_qualifier,
        transaction_group_qualifier,
        user_pid,                           // for transaction id
        requester_id,                       // borrowing institution symbol
        authorization,
        password,
        delivery_name,                      // SHIP TO
        delivery_extension,                 // SHIP TO
        delivery_street_no,                 // SHIP TO
        delivery_po_box,                    // SHIP TO
        delivery_city,                      // SHIP TO
        delivery_region,                    // SHIP TO
        delivery_country,                   // SHIP TO
        delivery_postal_code,               // SHIP TO
        delivery_service,                   // SHIP VIA
        electronic_delivery_description,    // SHIP VIA
        fax_address,                        // FAX
        email_address,                      // EMAIL
        billing_name,                       // BILL TO
        billing_extension,                  // BILL TO
        billing_street_no,                  // BILL TO
        billing_po_box,                     // BILL TO
        billing_city,                       // BILL TO
        billing_region,                     // BILL TO
        billing_country,                    // BILL TO
        billing_postal_code,                // BILL TO
        need_before_date,                   // YYYYMMDD format
        client_name,                        // PATRON
        client_status,                      // PSTATUS
        client_identifier,                  // PATRON ID
        client_department,                  // PDEPT
        patron_id,                          // PATRON ID
        patron_full_name,                   // PATRON
        patron_first_name,                  // PATRON
        patron_last_name,                   // PATRON
        patron_initials,                    // PATRON
        patron_title,                       // PATRON
        patron_suffix,                      // PATRON
        patron_ssn,                         // PATRON ID
        p_home_extension,                   // PATRON ADDR
        p_home_street_no,                   // PATRON ADDR
        p_home_po_box,                      // PATRON ADDR
        p_home_city,                        // PATRON ADDR
        p_home_region,                      // PATRON ADDR
        p_home_country,                     // PATRON ADDR
        p_home_postal_code,                 // PATRON ADDR
        p_work_extension,                   // PATRON ADDR   
        p_work_street_no,                   // PATRON ADDR
        p_work_po_box,                      // PATRON ADDR
        p_work_city,                        // PATRON ADDR
        p_work_region,                      // PATRON ADDR 
        p_work_country,                     // PATRON ADDR
        p_work_postal_code,                 // PATRON ADDR
        patron_phone,                       // PATRON PHONE
        patron_email,                       // PATRON EMAIL
        patron_fax,                         // PATRON FAX
        patron_pager,                       // PATRON PHONE
        patron_status,                      // PSTATUS
        patron_department,                  // PDEPT
        patron_notes,                       // PATRON NOTES
        patron_monetary_value,              // PATRON MAXCOST
        held_medium_type,                   // TITLE
        call_number,                        // BORROWING NOTES
        author,                             // AUTHOR
        title,                              // TITLE
        sub_title,                          // TITLE
        sponsoring_body,                    // TITLE
        place_of_publication,               // IMPRINT
        publisher,                          // PUBLISHER
        series_title_number,                // SERIES NOTE
        volume,                             // VOLUME
        issue,                              // ISSUE
        affiliations,                       // DILL
        source,                             // DILL
        edition,                            // EDITION
        publication_date,                   // IMPRINT
        publication_date_of_component,      // DATE
        author_of_article,                  // ARTICLE
        title_of_article,                   // ARTICLE
        pagination,                         // PAGES
        isbn,                               // VERIFIED
        issn,                               // VERIFIED
        oclc_no,                            // OCLC
        verification_reference_source,      // VERIFIED
        uniform_title,                      // UNIFORM TITLE
        dissertation,                       // DISSERTATION
        account_number,                     // BILLING NOTES
        currency_code,                      // MAXCOST
        monetary_value,                     // MAXCOST
        payment_method,                     // MAXCOST
        copyright_compliance,               // COPYRIGHT COMPLIANCE
        send_to_list,                       // VERIFIED
        requester_note;                     // BORROWING NOTES

    public short
        oclc_ill_service_type,              // for ILL Direct Request
        ill_service_type,                   // 1=loan, 2=copy
        preference;                         // ORDERED or UNORDERED

    public boolean
        change_send_to,
        request_made;


    // constructor
    public IsoIllRequest()
    {
        service_date = new String( BLANK );
        transaction_qualifier = new String( BLANK );
        transaction_group_qualifier = new String( BLANK );
        user_pid = new String( BLANK );
        requester_id = new String( BLANK );
        authorization = new String( BLANK );
        password = new String( BLANK );
        delivery_name = new String( BLANK );
        delivery_extension = new String( BLANK );
        delivery_street_no = new String( BLANK );
        delivery_po_box = new String( BLANK );
        delivery_city = new String( BLANK );
        delivery_region = new String( BLANK );
        delivery_country = new String( BLANK );
        delivery_postal_code = new String( BLANK );
        delivery_service = new String( BLANK );
        electronic_delivery_description = new String( BLANK );
        fax_address = new String( BLANK );
        email_address = new String( BLANK );
        billing_name = new String( BLANK );
        billing_extension = new String( BLANK );
        billing_street_no = new String( BLANK );
        billing_po_box = new String( BLANK );
        billing_city = new String( BLANK );
        billing_region = new String( BLANK );
        billing_country = new String( BLANK );
        billing_postal_code = new String( BLANK );
        need_before_date = new String( BLANK );
        client_name = new String( BLANK );
        client_status = new String( BLANK );
        client_identifier = new String( BLANK );
        client_department = new String( BLANK );
        patron_id = new String( BLANK );
        patron_full_name = new String( BLANK );
        patron_first_name = new String( BLANK );
        patron_last_name = new String( BLANK );
        patron_initials = new String( BLANK );
        patron_title = new String( BLANK );
        patron_suffix = new String( BLANK );
        patron_ssn = new String( BLANK );
        p_home_extension = new String( BLANK );
        p_home_street_no = new String( BLANK );
        p_home_po_box = new String( BLANK );
        p_home_city = new String( BLANK );
        p_home_region = new String( BLANK );
        p_home_country = new String( BLANK );
        p_home_postal_code = new String( BLANK );
        p_work_extension = new String( BLANK );
        p_work_street_no = new String( BLANK );
        p_work_po_box = new String( BLANK );
        p_work_city = new String( BLANK );
        p_work_region = new String( BLANK );
        p_work_country = new String( BLANK );
        p_work_postal_code = new String( BLANK );
        patron_phone = new String( BLANK );
        patron_email = new String( BLANK );
        patron_fax = new String( BLANK );
        patron_pager = new String( BLANK );
        patron_status = new String( BLANK );
        patron_department = new String( BLANK );
        patron_notes = new String( BLANK );
        patron_monetary_value = new String( BLANK );
        held_medium_type = new String( BLANK );
        call_number = new String( BLANK );
        author = new String( BLANK );
        title = new String( BLANK );
        sub_title = new String( BLANK );
        sponsoring_body = new String( BLANK );
        place_of_publication = new String( BLANK );
        publisher = new String( BLANK );
        series_title_number = new String( BLANK );
        volume = new String( BLANK );
        issue = new String( BLANK );
        affiliations = new String( BLANK );
        source = new String( BLANK );
        edition = new String( BLANK );
        publication_date = new String( BLANK );
        publication_date_of_component = new String( BLANK );
        author_of_article = new String( BLANK );
        title_of_article = new String( BLANK );
        pagination = new String( BLANK );
        isbn = new String( BLANK );
        issn = new String( BLANK );
        oclc_no = new String( BLANK );
        verification_reference_source = new String( BLANK );
        uniform_title = new String( BLANK );
        dissertation = new String( BLANK );
        account_number = new String( BLANK );
        currency_code = new String( BLANK );
        monetary_value = new String( BLANK );
        payment_method = new String( BLANK );
        copyright_compliance = new String( BLANK );
        send_to_list = new String( BLANK );
        requester_note = new String( BLANK );
    }

    // This method builds an ISO ILL APDU request (in BER)
    // based on the values in the class attributes and 
    // returns a BER string.
    public BerString BuildIsoIllRequest()
    {
        DataDir dir;
        DataDir seqdir;
        DataDir subdir;
        DataDir extsdir = null;  /* for adding both extensions */
        DataDir thidir = null;   /* third party info */
        int protocol_version_num = 2;
        int transaction_type = 1;
        int num;

        dir = new DataDir( ILL_REQUEST_APDU, ASN1_APPLICATION );
        seqdir = dir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );

           /* 
           ** add protocol-version-num
           */

        seqdir.daddNum( PROTOCOL_VERSION_NUM, ASN1_CONTEXT, protocol_version_num );


           /* 
           ** add transaction-id
           */

        if ( !isEmpty( transaction_qualifier ) ||
	         !isEmpty( transaction_group_qualifier ) ||
	         !isEmpty( requester_id ) )
        {
	        DataDir tiddir = seqdir.daddTag( TRANSACTION_ID, ASN1_CONTEXT );

	        if ( !isEmpty( requester_id ) )
	        {
	            subdir = tiddir.daddTag( INITIAL_REQUESTER_ID, ASN1_CONTEXT );
	            subdir = subdir.daddTag( PERSON_OR_INSTITUTION_SYMBOL, ASN1_CONTEXT );
	            subdir = subdir.daddTag( INSTITUTION_SYMBOL, ASN1_CONTEXT);
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, requester_id );
	        }

	        if ( !isEmpty( transaction_group_qualifier ) )
	        {
	            subdir = tiddir.daddTag( TRANSACTION_GROUP_QUALIFIER, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, 
                    transaction_group_qualifier );
	        }

	        if ( !isEmpty( transaction_qualifier ) )
	        {
	            subdir = tiddir.daddTag( TRANSACTION_QUALIFIER, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL,
		             transaction_qualifier );
	        }

        }


           /* 
           ** add service-date-time
           */

        if ( !isEmpty( service_date ) )
        {
	        subdir = seqdir.daddTag( SERVICE_DATE_TIME, ASN1_CONTEXT );
	        subdir = subdir.daddTag( DATE_TIME_OF_THIS_SERVICE, ASN1_CONTEXT );
	        subdir.daddChar( DATE_OF_SERVICE, ASN1_CONTEXT, service_date );
        }
    

           /* 
           ** add transaction-type
           */

        seqdir.daddNum( TRANSACTION_TYPE, ASN1_CONTEXT, transaction_type );



           /* 
           ** add delivery-address
           */

        if ( !isEmpty( delivery_name ) ||
	         !isEmpty( delivery_extension ) ||
	         !isEmpty( delivery_street_no ) ||
	         !isEmpty( delivery_po_box ) ||
	         !isEmpty( delivery_city ) ||
	         !isEmpty( delivery_region ) ||
	         !isEmpty( delivery_country ) ||
	         !isEmpty( delivery_postal_code ) ||
	         !isEmpty( electronic_delivery_description ) ||
	         !isEmpty( fax_address ) )
        {
	        DataDir deldir = seqdir.daddTag( DELIVERY_ADDRESS, ASN1_CONTEXT );
	        fillInAddress( 
                DELIVERY_POSTAL_ADDRESS, 
                deldir,
                delivery_name,
                delivery_extension,
	            delivery_street_no,
	            delivery_po_box,
	            delivery_city,
	            delivery_region,
	            delivery_country,
	            delivery_postal_code,
	            fax_address,
                email_address
            );
        }

           /* 
           ** add delivery-service
           */

        if ( !isEmpty( delivery_service ) )
        {
	        subdir = seqdir.daddTag( DELIVERY_SERVICE, ASN1_CONTEXT );
	        subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, delivery_service );
        }



        if ( !isEmpty( email_address ) || 
             !isEmpty( fax_address ) )
        {
            DataDir eledir = seqdir.daddTag( ELECTRONIC_DELIVERY_SERVICE, ASN1_CONTEXT );

	        if ( !isEmpty( email_address ) )
	            addElectronicAddress( eledir, EMAIL_ID_STRING, email_address );

	        if ( !isEmpty( fax_address ) )
	            addElectronicAddress( eledir, FAX_ID_STRING, fax_address );
        }

           /* 
           ** add billing-address
           */

        if ( !isEmpty( billing_name ) ||
             !isEmpty( billing_extension ) ||
	         !isEmpty( billing_street_no ) ||
	         !isEmpty( billing_po_box ) ||
	         !isEmpty( billing_city ) ||
	         !isEmpty( billing_region ) ||
	         !isEmpty( billing_country ) ||
	         !isEmpty( billing_postal_code ) )
        {
            DataDir bildir = seqdir.daddTag( BILLING_ADDRESS, ASN1_CONTEXT );

	        fillInAddress(
                BILLING_POSTAL_ADDRESS,
                bildir,
                billing_name,
			    billing_extension,
			    billing_street_no,
			    billing_po_box,
			    billing_city,
			    billing_region,
			    billing_country,
			    billing_postal_code,
			    null, /* no electronic stuff done on billing */
			    null
            );
        }



           /* 
           ** add iLL-service-type
           */

        if ( ill_service_type > 0 )
        {
	        subdir = seqdir.daddTag( ILL_SERVICE_TYPE, ASN1_CONTEXT );
	        subdir.daddNum( ENUMERATED, ASN1_UNIVERSAL, ill_service_type );
        }


           /* 
           ** add responder-specific-service
           **
           ** z39.50 Access Control is used here to send the PRISM authorization
           ** number and password.  
           */

        if ( oclc_ill_service_type > 0 )
        {
	        DataDir resdir = seqdir.daddTag( RESPONDER_SPECIFIC_SERVICE, ASN1_CONTEXT );

	        subdir = resdir.daddTag( ASN1_EXTERNAL, ASN1_UNIVERSAL );
	        subdir.daddoid( OID, ASN1_UNIVERSAL, OID_OCLC_SPECIFIC_ILL_SERVICE );
	        subdir = subdir.daddTag( SINGLE_ASN1_TYPE, ASN1_CONTEXT );
	        subdir = subdir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	        subdir.daddNum( OCLC_ILL_SERVICE_TYPE, ASN1_CONTEXT, oclc_ill_service_type );
        }


           /* 
           ** add requester-optional-messages
           */

        subdir = seqdir.daddTag( REQUESTER_OPTIONAL_MESSAGES, ASN1_CONTEXT );

        num = 1;
        subdir.daddNum( CAN_SEND_RECEIVED, ASN1_CONTEXT, num );
        subdir.daddNum( CAN_SEND_RETURNED, ASN1_CONTEXT, num );
        subdir.daddNum( REQUESTER_SHIPPED, ASN1_CONTEXT, num );
        subdir.daddNum( REQUESTER_CHECKED_IN, ASN1_CONTEXT, num );


           /* 
           ** add search-type
           */

        if ( !isEmpty( need_before_date ) )
        {
	        DataDir seadir = seqdir.daddTag( SEARCH_TYPE, ASN1_CONTEXT );
            seadir.daddChar( NEED_BEFORE_DATE, ASN1_CONTEXT, need_before_date );
        }


           /* 
           ** add client-id
           */

        if ( !isEmpty( client_name ) ||
	         !isEmpty( client_status ) ||
	         !isEmpty( client_identifier ) )
        {
	        DataDir clidir = seqdir.daddTag( CLIENT_ID, ASN1_CONTEXT );

	        if ( !isEmpty( client_name ) ) {
	            subdir = clidir.daddTag( CLIENT_NAME, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, client_name );
	        }

	        if ( !isEmpty( client_status ) ) {
	            subdir = clidir.daddTag( CLIENT_STATUS, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, client_status );
	        }

	        if ( !isEmpty( client_identifier ) ) {
	            subdir = clidir.daddTag( CLIENT_IDENTIFIER, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, client_identifier );
	        }
        }

           /* 
           ** add item-id
           */

        if ( !isEmpty( held_medium_type ) ||
	         !isEmpty( call_number ) ||
	         !isEmpty( author ) ||
	         !isEmpty( title ) ||
	         !isEmpty( sub_title ) ||
	         !isEmpty( sponsoring_body ) ||
	         !isEmpty( place_of_publication ) ||
	         !isEmpty( publisher ) ||
	         !isEmpty( series_title_number ) ||
	         !isEmpty( edition ) ||
	         !isEmpty( publication_date ) ||
	         !isEmpty( publication_date_of_component ) ||
	         !isEmpty( author_of_article ) ||
	         !isEmpty( title_of_article ) ||
	         !isEmpty( pagination ) ||
	         !isEmpty( isbn ) ||
	         !isEmpty( issn ) ||
	         !isEmpty( oclc_no ) ||
	         !isEmpty( verification_reference_source ) )
        {
	        DataDir itedir= seqdir.daddTag( ITEM_ID, ASN1_CONTEXT );

	        if ( !isEmpty( held_medium_type ) ) {
                itedir.daddNum( II_HELD_MEDIUM_TYPE, ASN1_CONTEXT, 
                    Integer.parseInt( held_medium_type ) );
	        }

	        if ( !isEmpty( call_number ) ) {
	            subdir = itedir.daddTag( II_CALL_NUMBER, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, call_number );
	        }

	        if ( !isEmpty( author ) ) {
	            subdir = itedir.daddTag( II_AUTHOR, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, author );
	        }

	        if ( !isEmpty( title ) ) {
	            subdir = itedir.daddTag( II_TITLE, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, title );
	        }

	        if ( !isEmpty( sub_title ) ) {
	            subdir = itedir.daddTag( II_SUB_TITLE, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, sub_title );
	        }

	        if ( !isEmpty( sponsoring_body ) ) {
	            subdir = itedir.daddTag( II_SPONSORING_BODY, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, sponsoring_body );
	        }

	        if ( !isEmpty( place_of_publication ) ) {
	            subdir = itedir.daddTag( II_PLACE_OF_PUBLICATION, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, place_of_publication );
	        }

	        if ( !isEmpty( publisher ) ) {
	            subdir = itedir.daddTag( II_PUBLISHER, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, publisher );
	        }

	        if ( !isEmpty( series_title_number ) ) {
	            subdir = itedir.daddTag( II_SERIES_TITLE_NUMBER, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, series_title_number );
	        }

	        if ( !isEmpty( edition ) ) {
	            subdir = itedir.daddTag( II_EDITION, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, edition );
	        }

	        if ( !isEmpty( publication_date ) ) {
	            subdir = itedir.daddTag( II_PUBLICATION_DATE, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, publication_date );
	        }

	        if ( !isEmpty( publication_date_of_component ) ) {
	            subdir = itedir.daddTag( II_PUBLICATION_DATE_OF_COMPONENT, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, 
                    publication_date_of_component );
	        }

	        if ( !isEmpty( author_of_article ) ) {
	            subdir = itedir.daddTag( II_AUTHOR_OF_ARTICLE, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, author_of_article );
	        }

	        if ( !isEmpty( title_of_article ) ) {
	            subdir = itedir.daddTag( II_TITLE_OF_ARTICLE, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, title_of_article );
	        }

	        if ( !isEmpty( pagination ) ) {
	            subdir = itedir.daddTag( II_PAGINATION, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, pagination );
	        }

	        if ( !isEmpty( isbn ) ) {
	            subdir = itedir.daddTag( II_ISBN, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, isbn );
	        }

            if ( !isEmpty( issn ) ) {
	            subdir = itedir.daddTag( II_ISSN, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, issn );
	        }


                   /* 
                   ** add system-no
                   **
                   ** NLC System Number is used here to send the OCLC number.
                   */

	        if ( !isEmpty( oclc_no ) ) {
	            subdir = itedir.daddTag( II_SYSTEM_NO, ASN1_CONTEXT );
	            subdir = subdir.daddTag( ASN1_EXTERNAL, ASN1_UNIVERSAL );
	            subdir.daddoid( ASN1_OBJECTIDENTIFIER, ASN1_UNIVERSAL, OID_NLC_SYSTEM_NUMBER );
	            subdir = subdir.daddTag( SINGLE_ASN1_TYPE, ASN1_CONTEXT );
	            subdir = subdir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            subdir = subdir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            subdir.daddNum( ENUMERATED, ASN1_UNIVERSAL, OCLC_TYPE );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, oclc_no );
	        }

	        if ( !isEmpty( verification_reference_source ) ) {
	            subdir = itedir.daddTag( II_VERIFICATION_REFERENCE_SOURCE, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, 
                    verification_reference_source );
	        }
        }

           /* 
           ** add cost-info-type
           */

        if ( !isEmpty( account_number ) ||
	         !isEmpty( currency_code ) ||
	         !isEmpty( monetary_value ) )
        {
	        DataDir cosdir = seqdir.daddTag( COST_INFO_TYPE, ASN1_CONTEXT );

	        if ( !isEmpty( account_number ) )
	        {
	            subdir = cosdir.daddTag( ACCOUNT_NUMBER, ASN1_CONTEXT );
	            
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, account_number );
	        }
	        
	        if ( !isEmpty( currency_code ) ||
	             !isEmpty( monetary_value ) )
	        {
	            subdir = cosdir.daddTag( MAXIMUM_COST, ASN1_CONTEXT );
	            if ( !isEmpty( currency_code ) )
		            subdir.daddChar( CURRENCY_CODE, ASN1_CONTEXT, currency_code );
	            if ( !isEmpty( monetary_value ) )
		            subdir.daddChar( MONETARY_VALUE, ASN1_CONTEXT, monetary_value );
	        }
        }


           /* 
           ** add copyright-compliance
           */

        if ( !isEmpty( copyright_compliance ) )
        {
	        subdir = seqdir.daddTag( COPYRIGHT_COMPLIANCE, ASN1_CONTEXT );
	        subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, copyright_compliance );
        }

           /* 
           ** add third-party-info-type
           ** this always exists because we always
           ** add permission to change send to list
           */

        thidir = seqdir.daddTag( THIRD_PARTY_INFO_TYPE, ASN1_CONTEXT );

           /*
           ** add permission to change send to list
           **
           */
 
        thidir.daddNum( PERMISSION_TO_CHANGE_SEND_TO_LIST, ASN1_CONTEXT, 
            ( change_send_to ? 1 : 0 ) );  // if true then 1 else 0

           /*
           ** add preference
           */

        if ( preference > 0 )
        {
            subdir = thidir.daddTag( PREFERENCE, ASN1_CONTEXT );
            subdir.daddNum( ENUMERATED, ASN1_UNIVERSAL, preference );
        }
       
        if ( !isEmpty( send_to_list ) )
        {
	        StringTokenizer symbol = new StringTokenizer( send_to_list );
	        DataDir sendir;

	        sendir = thidir.daddTag( SEND_TO_LIST, ASN1_CONTEXT );

	        while ( symbol.hasMoreTokens() )
	        {
	            subdir = sendir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            subdir = subdir.daddTag( SYSTEM_ID, ASN1_CONTEXT );
	            subdir = subdir.daddTag( PERSON_OR_INSTITUTION_SYMBOL, ASN1_CONTEXT );
	            subdir = subdir.daddTag( INSTITUTION_SYMBOL, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, symbol.nextToken() );
	        }
        }


           /* 
           ** add requester-note
           */

        if ( !isEmpty( requester_note ) )
        {
	        subdir = seqdir.daddTag( REQUESTER_NOTE, ASN1_CONTEXT );
	        subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, requester_note );
        }


           /* 
           ** add iLL-request-extensions
           **
           ** ILL Request Extension is used here to send data supported by
           ** PRISM ILL.
           */

        if ( !isEmpty( uniform_title ) ||
	         !isEmpty( dissertation ) ||
	         !isEmpty( payment_method ) ||
	         !isEmpty( volume ) ||
	         !isEmpty( issue ) ||
	         !isEmpty( client_department ) ||
             !isEmpty( affiliations ) ||
             !isEmpty( source ) )
        {
            DataDir extdir;
	        DataDir exidir;
	        short extension_identifier = 1;
	        short extension_critical = 0;

	        extsdir = seqdir.daddTag( EXTENSIONS, ASN1_CONTEXT );
	        extdir = extsdir.daddTag( SEQUENCE, ASN1_UNIVERSAL );
	        extdir.daddNum( EXTENSION_IDENTIFIER, ASN1_CONTEXT, extension_identifier );
	        extdir.daddNum( EXTENSION_CRITICAL, ASN1_CONTEXT, extension_critical );

	        extdir = extdir.daddTag( EXTENSION_ITEM, ASN1_CONTEXT );
	        extdir = extdir.daddTag( EXTERNAL, ASN1_UNIVERSAL );
	        extdir.daddoid( ASN1_OBJECTIDENTIFIER, ASN1_UNIVERSAL, OID_ILL_REQUEST_EXTENSION );
	        extdir = extdir.daddTag( SINGLE_ASN1_TYPE, ASN1_CONTEXT );
	        exidir = extdir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	        
	        if ( !isEmpty( client_department ) )
	        {
	            subdir = exidir.daddTag( CLIENT_DEPARTMENT, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, client_department );
	        }


                   /* 
                   ** add payment-method.  This is where "ifm" should be specified
                   ** for PRISM ILL.
                   */

	        if ( !isEmpty( payment_method ) )
	        {
	            subdir = exidir.daddTag( COST_INFO_PAYMENT_METHOD, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, payment_method );
	        }

	        if ( !isEmpty( uniform_title ) )
	        {
	            subdir = exidir.daddTag( ITEM_ID_UNIFORM_TITLE, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, uniform_title );
	        }

	        if ( !isEmpty( dissertation ) )
	        {
	            subdir = exidir.daddTag( ITEM_ID_DISSERTATION, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, dissertation );
	        }
	        
	        if ( !isEmpty( issue ) )
	        {
	            subdir = exidir.daddTag( ITEM_ID_ISSUE, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, issue );
	        }

	        if ( !isEmpty( volume ) )
	        {
	            subdir = exidir.daddTag( ITEM_ID_VOLUME, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, volume );
            }

	        if ( !isEmpty( affiliations ) )
	        {
	            subdir = exidir.daddTag( ITEM_ID_AFFILIATIONS, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, affiliations );
	        }

	        if ( !isEmpty( source ) )
	        {
	            subdir = exidir.daddTag( ITEM_ID_SOURCE, ASN1_CONTEXT );
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, source );
	        }

        }  /* End of OCLC extension */


           /* 
           **
           ** z39.50 Access Control is used here to send the PRISM authorization
           ** number and password.  
           */

        if ( !isEmpty( authorization ) ||
	         !isEmpty( password ) )
        {

	        DataDir seq2dir;
            DataDir extdir;
            DataDir subdir2;
   
	        short extension_identifier = 1;
	        short extension_critical = 0;
     
            /* Add an EXTENSIONS node if it doesn't exist */
            if ( extsdir == null )
                extsdir = seqdir.daddTag( EXTENSIONS, ASN1_CONTEXT );

            extdir = extsdir.daddTag( SEQUENCE, ASN1_UNIVERSAL );
	        extdir.daddNum( EXTENSION_IDENTIFIER, ASN1_CONTEXT, extension_identifier );
	        extdir.daddNum( EXTENSION_CRITICAL, ASN1_CONTEXT, extension_critical );

	        extdir = extdir.daddTag( EXTENSION_ITEM, ASN1_CONTEXT );
	        extdir = extdir.daddTag( EXTERNAL, ASN1_UNIVERSAL );
	        extdir.daddoid( ASN1_OBJECTIDENTIFIER, ASN1_UNIVERSAL, OID_Z3950_ACCESS_CONTROL );
	        extdir = extdir.daddTag( SINGLE_ASN1_TYPE, ASN1_CONTEXT );
            seq2dir = extdir.daddTag( RESPONSE, ASN1_CONTEXT );
	        

	        if ( !isEmpty( authorization ) )
	        {
                short user_id = 1;
	            subdir = seq2dir.daddTag( SEQUENCE, ASN1_UNIVERSAL );
                subdir2 = subdir.daddTag( PROMPT_ID, ASN1_CONTEXT );
                subdir2 = subdir2.daddTag( ENUMMERATED_PROMPT, ASN1_CONTEXT );
	            subdir2.daddNum( ACCESS_TYPE, ASN1_CONTEXT, user_id );
	            subdir = subdir.daddTag( PROMPT_RESPONSE, ASN1_CONTEXT );
	            subdir.daddChar( STRING, ASN1_CONTEXT, authorization );
	        }

	        if ( !isEmpty( password ) )
	        {
                short pass = 2;
	            subdir = seq2dir.daddTag( SEQUENCE, ASN1_UNIVERSAL );
                subdir2 = subdir.daddTag( PROMPT_ID, ASN1_CONTEXT );
                subdir2 = subdir2.daddTag( ENUMMERATED_PROMPT, ASN1_CONTEXT );
	            subdir2.daddNum( ACCESS_TYPE, ASN1_CONTEXT, pass );
	            subdir = subdir.daddTag( PROMPT_RESPONSE, ASN1_CONTEXT );
	            subdir.daddChar( STRING, ASN1_CONTEXT, password );
	        }
        }

           /*
           ** add ILL supplemental client id
           ** this is the new patron extension
           ** it must be added after the above OCLC extension
           ** to avoid confusing REQLOAD
           */


        if ( !isEmpty( patron_id ) ||
             !isEmpty( patron_full_name ) ||
             !isEmpty( patron_first_name ) ||
             !isEmpty( patron_last_name ) ||
             !isEmpty( patron_initials ) ||
             !isEmpty( patron_title ) ||
             !isEmpty( patron_suffix ) ||
             !isEmpty( patron_ssn ) ||
             !isEmpty( p_home_extension ) ||
             !isEmpty( p_home_street_no ) ||
             !isEmpty( p_home_po_box ) ||
             !isEmpty( p_home_city ) ||
             !isEmpty( p_home_region ) ||
             !isEmpty( p_home_country ) ||
             !isEmpty( p_home_postal_code ) ||
             !isEmpty( p_work_extension ) ||
             !isEmpty( p_work_street_no ) ||
             !isEmpty( p_work_po_box ) ||
             !isEmpty( p_work_city ) ||
             !isEmpty( p_work_region ) ||
             !isEmpty( p_work_country ) ||
             !isEmpty( p_work_postal_code ) ||
             !isEmpty( patron_phone ) ||
             !isEmpty( patron_email ) ||
             !isEmpty( patron_fax ) ||
             !isEmpty( patron_pager ) ||
             !isEmpty( patron_status ) ||
             !isEmpty( patron_department ) ||
             !isEmpty( patron_notes ) ||
             !isEmpty( patron_monetary_value ) )

        {
            DataDir extdir;
	        DataDir sclidir;
            DataDir seqsdir;
            DataDir haddrdir;
            DataDir waddrdir;

	        short extension_identifier = 1;
	        short extension_critical = 0;
            short number;

            /* Add an EXTENSIONS node if it doesn't exist */
            if ( extsdir == null )
                extsdir = seqdir.daddTag( EXTENSIONS, ASN1_CONTEXT );
           
    	    extdir = extsdir.daddTag( SEQUENCE, ASN1_UNIVERSAL );
	        extdir.daddNum( EXTENSION_IDENTIFIER, ASN1_CONTEXT, extension_identifier );
	        extdir.daddNum( EXTENSION_CRITICAL, ASN1_CONTEXT, extension_critical );

	        extdir = extdir.daddTag( EXTENSION_ITEM, ASN1_CONTEXT );
	        extdir = extdir.daddTag( EXTERNAL, ASN1_UNIVERSAL );
	        extdir.daddoid( ASN1_OBJECTIDENTIFIER, ASN1_UNIVERSAL, OID_CLIENT_INFO_EXTENSION );
	        extdir = extdir.daddTag( SINGLE_ASN1_TYPE, ASN1_CONTEXT );
    	    sclidir = extdir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );


	        if ( !isEmpty( patron_id ) )
	        {
	            seqsdir = sclidir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_ID );
                subdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );
                subdir = subdir.daddTag( STRING_CONTENT, ASN1_CONTEXT );          
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, patron_id );
	        }

	        if ( !isEmpty( patron_full_name ) )
	        {
	            seqsdir = sclidir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_FULL_NAME );
                subdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );
                subdir = subdir.daddTag( STRING_CONTENT, ASN1_CONTEXT );          
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, patron_full_name );
	        }

	        if ( !isEmpty( patron_first_name ) )
	        {
	            seqsdir = sclidir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_FIRST_NAME );
                subdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );
                subdir = subdir.daddTag( STRING_CONTENT, ASN1_CONTEXT );          
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, patron_first_name );
	        }

	        if ( !isEmpty( patron_last_name ) )
	        {
	            seqsdir = sclidir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_LAST_NAME );
                subdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );
                subdir = subdir.daddTag( STRING_CONTENT, ASN1_CONTEXT );          
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, patron_last_name );
	        }

	        if ( !isEmpty( patron_initials ) )
	        {
	            seqsdir = sclidir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_INITIALS );
                subdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );
                subdir = subdir.daddTag( STRING_CONTENT, ASN1_CONTEXT );          
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, patron_initials );
	        }

	        if ( !isEmpty( patron_title ) )
	        {
	            seqsdir = sclidir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_TITLE );
                subdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );
                subdir = subdir.daddTag( STRING_CONTENT, ASN1_CONTEXT );          
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, patron_title );
	        }

	        if ( !isEmpty( patron_suffix ) )
	        {
	            seqsdir = sclidir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_SUFFIX );
                subdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );
                subdir = subdir.daddTag( STRING_CONTENT, ASN1_CONTEXT );          
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, patron_suffix );
	        }

	        if ( !isEmpty( patron_ssn ) )
	        {
	            seqsdir = sclidir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_SSN );
                subdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );
                subdir = subdir.daddTag( STRING_CONTENT, ASN1_CONTEXT );          
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, patron_ssn );
	        }

                /*
                ** add home address
                */
	        
	        if ( !isEmpty( p_home_extension ) ||
	             !isEmpty( p_home_street_no ) ||
	             !isEmpty( p_home_po_box ) ||
	             !isEmpty( p_home_city ) ||
	             !isEmpty( p_home_region ) ||
	             !isEmpty( p_home_country ) ||
	             !isEmpty( p_home_postal_code ) )
            {
                seqsdir = sclidir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );  
                seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_HOME_ADDRESS );
                haddrdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );

	            fillInAddress(
                    CLIENT_POSTAL_ADDRESS,
                    haddrdir,
                    patron_full_name,
                    p_home_extension,
                    p_home_street_no,
                    p_home_po_box,
                    p_home_city,
                    p_home_region,
                    p_home_country,
                    p_home_postal_code,
                    null,
                    null 
                );
            }

                /*
                ** add work address
                */

            if ( !isEmpty( p_work_extension ) ||
	             !isEmpty( p_work_street_no ) ||
	             !isEmpty( p_work_po_box ) ||
	             !isEmpty( p_work_city ) ||
	             !isEmpty( p_work_region ) ||
	             !isEmpty( p_work_country ) ||
	             !isEmpty( p_work_postal_code ) )
            {
                seqsdir = sclidir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );  
                seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_WORK_ADDRESS );
                waddrdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );

	            fillInAddress(
                    CLIENT_POSTAL_ADDRESS,
                    waddrdir,
                    patron_full_name,
                    p_work_extension,
                    p_work_street_no,
                    p_work_po_box,
                    p_work_city,
                    p_work_region,
                    p_work_country,
                    p_work_postal_code,
                    null,
                    null 
                );
            }

               /*
               ** add patron phone
               */

  	        if ( !isEmpty( patron_phone ) )
	        {
	            seqsdir = sclidir.daddTag(ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_PHONE );
                subdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );
                subdir = subdir.daddTag( STRING_CONTENT, ASN1_CONTEXT );          
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, patron_phone );
	        }

               /*
               ** add patron email
               */

  	        if ( !isEmpty( patron_email ) )
	        {
	            seqsdir = sclidir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_EMAIL );
                subdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );
                subdir = subdir.daddTag( STRING_CONTENT, ASN1_CONTEXT );          
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, patron_email );
	        }

               /*
               ** add patron fax
               */

  	        if ( !isEmpty( patron_fax ) )
	        {
	            seqsdir = sclidir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_FAX );
                subdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );
                subdir = subdir.daddTag( STRING_CONTENT, ASN1_CONTEXT );          
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, patron_fax );
	        }

               /*
               ** add patron pager
               */

  	        if ( !isEmpty( patron_pager ) )
	        {
	            seqsdir = sclidir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_PAGER );
                subdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );
                subdir = subdir.daddTag( STRING_CONTENT, ASN1_CONTEXT );          
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, patron_pager );
	        }

               /*
               ** add patron status
               */

  	        if ( !isEmpty( patron_status ) )
	        {
	            seqsdir = sclidir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_STATUS );
                subdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );
                subdir = subdir.daddTag( STRING_CONTENT, ASN1_CONTEXT );          
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, patron_status );
	        }
      
                /*
                ** add patron department
                */

            if ( !isEmpty( patron_department ) )
 	        {
	            seqsdir = sclidir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_DEPARTMENT );
                subdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );
                subdir = subdir.daddTag( STRING_CONTENT, ASN1_CONTEXT );          
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, patron_department );
	        }

               /*
                ** add patron notes
                */

            if ( !isEmpty( patron_notes ) )
 	        {
	            seqsdir = sclidir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_NOTES );
                subdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );
                subdir = subdir.daddTag( STRING_CONTENT, ASN1_CONTEXT );          
	            subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, patron_notes );
	        }

            if ( !isEmpty( patron_monetary_value ) )
            {
	            seqsdir = sclidir.daddTag( ASN1_SEQUENCE, ASN1_UNIVERSAL );
	            seqsdir.daddNum( STANDARD, ASN1_CONTEXT, PATRON_MAXCOST );
                subdir = seqsdir.daddTag( INFO_CONTENT, ASN1_CONTEXT );
                subdir = subdir.daddTag( PATRON_MAXCOST_AMOUNT, ASN1_CONTEXT );         
  	            if ( !isEmpty( currency_code ) )
		            subdir.daddChar( CURRENCY_CODE, ASN1_CONTEXT, currency_code );              
	            subdir.daddChar( MONETARY_VALUE, ASN1_CONTEXT, patron_monetary_value );
            }

        }

        return new BerString( dir );

    }  // end BuildIsoIllRequest


    ///////////////////////////////////////////////////////
    // private methods

    // This method puts the address information into the
    // data directory from the class attributes.
    private void fillInAddress( 
        int type, 
        DataDir dir,
        String name,
		String extension,
		String street_no,
		String po_box,
		String city,
		String region,
		String country,
		String postal_code,
		String fax_address,
		String email_address )
    {
        DataDir subdir;
	    DataDir posdir = dir.daddTag( type, ASN1_CONTEXT );

	    if ( !isEmpty( name ) )
	    {
	        subdir = posdir.daddTag( NAME_OF_PERSON_OR_INSTITUTION, ASN1_CONTEXT );
	        subdir = subdir.daddTag( NAME_OF_PERSON, ASN1_CONTEXT);
	        subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, name );
	    }

	    if ( !isEmpty( extension ) )
	    {
	        subdir = posdir.daddTag( EXTENDED_POSTAL_ADDRESS, ASN1_CONTEXT );
	        subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, extension );
	    }

	    if ( !isEmpty( street_no ) )
	    {
	        subdir = posdir.daddTag( STREET_AND_NUMBER, ASN1_CONTEXT );
	        subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, street_no );
	    }

	    if ( !isEmpty( po_box ) )
	    {
	        subdir = posdir.daddTag( POST_OFFICE_BOX, ASN1_CONTEXT );
	        subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, po_box );
	    }

	    if ( !isEmpty( city ) )
	    {
	        subdir = posdir.daddTag( CITY, ASN1_CONTEXT );
	        subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, city );
	    }

	    if ( !isEmpty( region ) )
	    {
	        subdir = posdir.daddTag( REGION, ASN1_CONTEXT );
	        subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, region );
	    }

	    if ( !isEmpty( country ) )
	    {
	        subdir = posdir.daddTag( COUNTRY, ASN1_CONTEXT );
	        subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, country );
	    }

	    if ( !isEmpty( postal_code ) )
	    {
	        subdir = posdir.daddTag( POSTAL_CODE, ASN1_CONTEXT );
	        subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, postal_code );
	    }

        if ( !isEmpty( email_address ) || 
             !isEmpty( fax_address ) )
        {
	        DataDir eledir = dir.daddTag( DELIVERY_ELECTRONIC_ADDRESS, ASN1_CONTEXT );

	        if ( !isEmpty( email_address ) )
            {
                /*
	            add_electronic_address(eledir, EMAIL_ID_STRING, email_address);
                */
                subdir = eledir.daddTag( TELECOM_SERVICE_IDENTIFIER, ASN1_CONTEXT );
                subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, EMAIL_ID_STRING );

                subdir = eledir.daddTag( TELECOM_SERVICE_ADDRESS, ASN1_CONTEXT );
                subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, email_address );
            }

	        if ( !isEmpty( fax_address ) )
            {
                /*
	            add_electronic_address(eledir, FAX_ID_STRING, fax_address);
                */
                subdir = eledir.daddTag( TELECOM_SERVICE_IDENTIFIER, ASN1_CONTEXT );
                subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, FAX_ID_STRING );

                subdir = eledir.daddTag( TELECOM_SERVICE_ADDRESS, ASN1_CONTEXT );
                subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, fax_address );
            }

        }

    }

    public void addElectronicAddress(
        DataDir eledir,
		String id,
        String address )
    {
        DataDir seqdir;
        DataDir subdir;
        DataDir detdir;
        DataDir seq2dir;
    
        seqdir = eledir.daddTag( SEQUENCE, ASN1_UNIVERSAL );
        subdir = seqdir.daddTag( DELIVERY_DESCRIPTION, ASN1_CONTEXT );
        subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, id );

        detdir = seqdir.daddTag( DELIVERY_DETAILS, ASN1_CONTEXT );
        seq2dir = detdir.daddTag( E_DELIVERY_ADDRESS, ASN1_CONTEXT );

        subdir = seq2dir.daddTag( TELECOM_SERVICE_IDENTIFIER, ASN1_CONTEXT );
        subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, id );

        subdir = seq2dir.daddTag( TELECOM_SERVICE_ADDRESS, ASN1_CONTEXT );
        subdir.daddChar( ASN1_GENERALSTRING, ASN1_UNIVERSAL, address );
    }

    private boolean isEmpty( String s )
    { return s == null || s.equals( "" ); }

}


///////////////////////////////////////////////////////////////////////////////
// (c)1998 Olivet Nazarene University, 240 East Marsile,
// Bourbonnais, IL 60914-0592.
//
// NOTICE TO USERS:  ONU-ILL ("Software") has been developed by
// Olivet Nazarene University.  Subject to the terms and conditions set
// forth below, Olivet grants to user a perpetual, non-exclusive, royalty-free
// license to use, reproduce, alter, modify, and create derivative works from
// Software, and to sublicense Software subject to the following terms and
// conditions:
//
// SOFTWARE IS PROVIDED AS IS.  OLIVET MAKES NO WARRANTIES, REPRESENTATIONS, OR
// GUARANTEES WHETHER EXPRESS OR IMPLIED REGARDING SOFTWARE, ITS FITNESS FOR ANY
// PARTICULAR PURPOSE, OR THE ACCURACY OF THE INFORMATION CONTAINED THEREIN.
//
// User agrees that Olivet shall have no liability to user arising therefrom,
// regardless of the basis of the action, including liability for special,
// consequential, exemplary, or incidental damages, including lost profits,
// even if it has been advised of the possibility thereof.
//
// User shall cause the copyright notice of Olivet to appear on all copies of
// Software, including derivative works made therefrom.
//
///////////////////////////////////////////////////////////////////////////////
// (c)1996 OCLC Online Computer Library Center, Inc., 6565 Frantz Road, Dublin,
// Ohio 43017-0702.  OCLC is a registered trademark of OCLC Online Computer
// Library Center, Inc.
//
// NOTICE TO USERS:  The BER Utilities ("Software") has been developed by OCLC
// Online Computer Library Center, Inc.  Subject to the terms and conditions set
// forth below, OCLC grants to user a perpetual, non-exclusive, royalty-free
// license to use, reproduce, alter, modify, and create derivative works from
// Software, and to sublicense Software subject to the following terms and
// conditions:
//
// SOFTWARE IS PROVIDED AS IS.  OCLC MAKES NO WARRANTIES, REPRESENTATIONS, OR
// GUARANTEES WHETHER EXPRESS OR IMPLIED REGARDING SOFTWARE, ITS FITNESS FOR ANY
// PARTICULAR PURPOSE, OR THE ACCURACY OF THE INFORMATION CONTAINED THEREIN.
//
// User agrees that OCLC shall have no liability to user arising therefrom,
// regardless of the basis of the action, including liability for special,
// consequential, exemplary, or incidental damages, including lost profits,
// even if it has been advised of the possibility thereof.
//
// User shall cause the copyright notice of OCLC to appear on all copies of
// Software, including derivative works made therefrom.