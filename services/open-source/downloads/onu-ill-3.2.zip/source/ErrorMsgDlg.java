import java.awt.*;

public class ErrorMsgDlg extends Dialog
{
    Button btn_ok;
    Toolkit sys_metrics = Toolkit.getDefaultToolkit( );

    public ErrorMsgDlg( Frame parent, String msg )
    {
        super( parent, "Error Message", true );

        setLayout( null );

        Label msg_label = new Label( msg, Label.CENTER );
        msg_label.setFont( new Font( "Sans Serif", Font.PLAIN, 11 ) );
        btn_ok = new Button( "OK" );
        btn_ok.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );

        Panel pnl_main = new Panel( );
        pnl_main.setLayout( null );
        pnl_main.add( msg_label );
        pnl_main.add( btn_ok );
        msg_label.reshape( 0, 0, 240, 14 );
        btn_ok.reshape( 96, 26, 48, 24 );
        add( pnl_main );
        pnl_main.reshape( 24, 32, 240, 50 );

        setResizable( false );
        int x = (int)( ( sys_metrics.getScreenSize( ).width - 264 ) / 2 );
        int y = (int)( ( sys_metrics.getScreenSize( ).height - 114 ) / 2 );
        reshape( x, y, 264, 114 );
        show( );

    }

    public boolean action( Event e, Object o )
    {
        hide( );
        dispose( );

        return true;
    }
}