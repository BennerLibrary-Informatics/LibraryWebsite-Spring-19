import java.awt.*;

public class InfoTextField extends Panel
{
    // properties
    private Label prompt;
    private TextField input;

    private int height = 40, width;

    // constructors
    public InfoTextField( String s )
    {
        // Set up the component
        setLayout( new GridLayout( 2, 1 ) );
        add( prompt = new Label( s ) );
        add( input = new TextField() );

        // Set the width dimension
        width = s.length() * 12;
    }

    public InfoTextField( String s, int w ) 
    {
        // Set up the component
        setLayout( new GridLayout( 2, 1 ) );
        add( prompt = new Label( s ) );
        add( input = new TextField( w ) );

        // Set the width dimension
        width = w * 12;
    }

    public InfoTextField( String s, int w, Font f ) 
    {
        // Set up the component
        setLayout( new GridLayout( 2, 1 ) );
        add( prompt = new Label( s ) );
        prompt.setFont( f );
        add( input = new TextField( w ) );

        // Set the width dimension
        width = w * 12;
    }


    // methods
    public String getText()
    { return new String( input.getText() ); }

    public void setText( String s )
    { input.setText( s ); }

    public Dimension getSize()
    { return new Dimension( width, height ); }

    public void password()
    { input.setEchoCharacter( '*' ); }

}
