import java.util.*;

public class ILLDate {

    public static String getFormattedDate( Date d )
    // Builds a string for the given Date in the proper format for ILL requests.
    {
        int year = d.getYear( ) + 1900;
        int month = d.getMonth( ) + 1;
        int day = d.getDate( );
        String s = new String( "" + year +
            ( month < 10 ? "0" : "" ) + month +
            ( day < 10 ? "0" : "" ) + day );

        return new String( s );

        /*
        ** JAVA 1.1 CODE
        **
        Calendar c = Calendar.getInstance();
        c.setTime( d );

        int year = c.get( Calendar.YEAR );
        int month = c.get( Calendar.MONTH ) + 1;
        int day = c.get( Calendar.DAY_OF_MONTH );

        String s = new String( "" + year +
            ( month < 10 ? "0" : "" ) + month +
            ( day < 10 ? "0" : "" ) + day );

        return new String( s );
        */
    }

}

/*
** (c)1998 Olivet Nazarene University, 240 East Marsile,
** Bourbonnais, IL 60914-0592.
**
** NOTICE TO USERS:  ONU-ILL ("Software") has been developed by
** Olivet Nazarene University.  Subject to the terms and conditions set
** forth below, Olivet grants to user a perpetual, non-exclusive, royalty-free
** license to use, reproduce, alter, modify, and create derivative works from
** Software, and to sublicense Software subject to the following terms and
** conditions:
**
** SOFTWARE IS PROVIDED AS IS.  OLIVET MAKES NO WARRANTIES, REPRESENTATIONS, OR
** GUARANTEES WHETHER EXPRESS OR IMPLIED REGARDING SOFTWARE, ITS FITNESS FOR ANY
** PARTICULAR PURPOSE, OR THE ACCURACY OF THE INFORMATION CONTAINED THEREIN.
**
** User agrees that Olivet shall have no liability to user arising therefrom,
** regardless of the basis of the action, including liability for special,
** consequential, exemplary, or incidental damages, including lost profits,
** even if it has been advised of the possibility thereof.
**
** User shall cause the copyright notice of Olivet to appear on all copies of
** Software, including derivative works made therefrom.
*/