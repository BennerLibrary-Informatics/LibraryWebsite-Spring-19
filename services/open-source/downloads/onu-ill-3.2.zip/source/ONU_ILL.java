/****************************************************************************
 *                                                                          *
 *    ONU ILL                                                               *
 *                                                                          *
 *    VERSION:  3.2 (Java/2.1)                                              *
 *    AUTHOR:   Bryan Wilhelm                                               *
 *              Olivet Nazarene University                                  *
 *                                                                          *
 *    DATE CREATED:  May 11, 1998                                           *
 *                                                                          *
 *    MODIFICATION HISTORY:                                                 *
 *    --------------------------------------------------------------------  *
 *    06/19/1998    Created the EDU.olivet.ill package to handle the more   *
 *                  technical details.  Changed the implementation of the   *
 *                  FieldInfo.  Eliminated the RequestRecord class.         *
 *    07/24/1998    Abandoned IPT in favor of ISO 10161 standard.           *
 *    08/10/1998    Created applet version for the Java 1.1 application.    *
 *    --------------------------------------------------------------------  *
 *                                                                          *
 ***************************************************************************/

import java.applet.*;
import java.awt.*;
import java.net.*;
import java.util.*;


public class ONU_ILL 
       extends Applet
       implements ONU_ILL_CONST
{
    // HTML parameter variables
    private int maxRequests = 10;
    private short illService = 3; // DIRECT-TO-LENDER  = 1
                                  // DIRECT-TO-PROFILE = 2
                                  // DIRECT-TO-REVIEW  = 3
    private String lenderList;
    private String gotoLocation;
    private String institutionName;
    private String libraryName;
    private String libSymbol;
    private String delName;
    private String delExtension;
    private String delStreet;
    private String delPOBox;
    private String delCity;
    private String delState;
    private String delCountry;
    private String delPostalCode;
    private String delService;
    private String delElectronic;
    private String delFax;
    private String delEmail;
    private String maxCost;
    private String bookNote;
    private String perNote;
    private Color bgcolor;

    // gui components
    private Button    btn_book,
                      btn_periodical,
                      btn_submit,
                      btn_delete,
                      btn_clear,
                      btn_cancel;
    private List      lst_display;

    // Patron information is stored separately until submission.
    // Both the patron information and the request record can be
    // accessed from outside the class.
    private PatronInfo patron_info;
    private Vector record;        // Vector of ItemInfo
    private int numRequests = 0;

    private Toolkit sys_metrics = Toolkit.getDefaultToolkit( );
    private int i;   // loop counter



    // Constructor
    public void init( )
    {
        // initialize default attributes
        getHTMLParameters( );
        record = new Vector( );

        setLayout( new BorderLayout( ) );

        // Create application components
        btn_book = new Button( "Book Form" );
        btn_periodical = new Button( "Periodical Form" );
        btn_submit = new Button( "Submit Request" );
        btn_submit.enable( false );
        btn_delete = new Button( "Delete" );
        btn_delete.enable( false );
        btn_clear = new Button( "Clear" );
        btn_clear.enable( false );
        btn_cancel = new Button( "Cancel" );

        lst_display = new List( maxRequests, true );
        lst_display.setMultipleSelections( false );

        Panel pnl_main = new Panel( );
        pnl_main.setLayout( null );
        pnl_main.setBackground( bgcolor );
        pnl_main.resize( ( sys_metrics.getScreenSize( ) ).width, 36 );
        pnl_main.add( btn_book );
        pnl_main.add( btn_periodical );
        pnl_main.add( btn_submit );
        pnl_main.add( btn_delete );
        pnl_main.add( btn_clear );
        pnl_main.add( btn_cancel );

        // Set button bounds.
        btn_book.reshape(         8,  0,  80,  24 );
        btn_periodical.reshape(  92,  0, 104,  24 );
        btn_submit.reshape(     204,  0, 104,  24 );
        btn_delete.reshape(     316,  0,  80,  24 );
        btn_clear.reshape(      400,  0,  80,  24 );
        btn_cancel.reshape(     484,  0,  80,  24 );

        // Add window components
        add( "North", pnl_main );
        add( "Center", lst_display );

        show( );

        new PatronInfoDlg( new Frame( ), patron_info = new PatronInfo( ), institutionName );

    } // end constructor


    // Abstract methods
    public boolean action( Event e, Object o )
    {
        if ( e.target == btn_book )
        {
            ItemInfo item = new ItemInfo( );

            // Display book form and return with request.
            new BookFormDlg( new Frame( ), item, numRequests + 1, libraryName );

            // Check if request was made, if so increment number of requests;
            // if not return to main program--do not change the status of the
            // main window.
            if ( item.request_made ) {

                // increment number of requests
                record.addElement( item );
                ++numRequests;

                // enable appropriate buttons and menu items
                btn_submit.enable( true );
                btn_delete.enable( true );
                btn_clear.enable( true );
                if ( numRequests == maxRequests ) {
                    btn_book.enable( false );
                    btn_periodical.enable ( false );
                }

                // add request item to list
                lst_display.addItem( 
                    new String( item.title + ", by " +
                                item.author ) 
                );

            }

        }

        else if ( e.target == btn_periodical )
        {
            ItemInfo item = new ItemInfo( );

            // Display periodical form and return with request.
            new PeriodicalFormDlg( new Frame( ), item, numRequests + 1, libraryName );

            // Check if request was made, if so increment number of requests;
            // if not return to main program--do not change the status of the
            // main window.
            if ( item.request_made ) {

                // increment number of requests
                record.addElement( item );
                ++numRequests;

                // enable appropriate buttons and menu items
                btn_submit.enable( true );
                btn_clear.enable( true );
                btn_delete.enable( true );
                if ( numRequests == maxRequests ) {
                    btn_book.enable( false );
                    btn_periodical.enable ( false );
                }

                // add request item to list
                lst_display.addItem( new String(
                    "\"" + item.title_of_article +
                    "\", in " + item.title + 
                    ( item.author.equals( "" ) ? "" : 
                    ", by " + item.author ) )
                );
            }

        }

        //
        // Request submission and program termination
        //

        else if ( e.target == btn_submit )
        {

            RequestFinalizerDlg rf = 
            new RequestFinalizerDlg( 
                new Frame( ), 
                getCodeBase( ).getHost( ),
                patron_info, 
                record, 
                numRequests, 
                illService,
                lenderList,
                institutionName,
                libSymbol,
                delName,
                delExtension,
                delStreet,
                delPOBox,
                delCity,
                delState,
                delCountry,
                delPostalCode,
                delService,
                delElectronic,
                delFax,
                delEmail,
                bookNote,
                perNote,
                maxCost
            );

            //hide( );

            new AppreciationDlg( new Frame( ), rf.error_flag, libraryName );

            //System.exit( 0 );

            try {
                URL location = new URL( gotoLocation );
                getAppletContext( ).showDocument( location );
                System.exit( 0 );
            } catch ( MalformedURLException murl ) {
                // trust the HTML editors
            }

        }

        else if ( e.target == btn_delete )
        {
            int sel;
            // get the current selection...
            if ( ( sel = lst_display.getSelectedIndex( ) ) == -1 ) {
                new ErrorMsgDlg( new Frame( ), "No item is selected." );
            }
            else {
                // ...and get rid of it
                lst_display.delItem( sel );
                record.removeElementAt( sel );

                // if there are no more requests then
                // disable some buttons
                if ( --numRequests == 0 ) {
                    btn_book.enable( true );
                    btn_periodical.enable( true );
                    btn_submit.enable( false );
                    btn_delete.enable( false );
                    btn_clear.enable( false );
                }
            }
        }

        else if ( e.target == btn_clear )
        {
            // Disable appropriate buttons and menu items
            btn_book.enable( true );
            btn_periodical.enable( true );
            btn_submit.enable( false );
            btn_delete.enable( false );
            btn_clear.enable( false );

            // Clear request records.
            record.removeAllElements( );

            // Set number of requests to zero.
            numRequests = 0;

            // Clear the list box.
            lst_display.clear( );


        } else if ( e.target == lst_display ) {
            // This event indicates that an event such as a double-click
            // or pressing ENTER occurred.

            // get the current selection -- if the event was on
            // the list box then one of the items will have the
            // focus, so getSelectedIndex will never return -1
            // here.
            int sel = lst_display.getSelectedIndex( );
            ItemInfo item = (ItemInfo) record.elementAt( sel );

            switch ( item.ill_service_type ) {
            case ( BOOK_REQUEST ):
                new BookFormDlg( new Frame( ), item, sel + 1, libraryName );
                lst_display.deselect( sel );
                lst_display.replaceItem( 
                    new String( item.title + ", by " +
                                item.author ),
                    sel
                );
                break;
            case ( PERIODICAL_REQUEST ):
                new PeriodicalFormDlg( new Frame( ), item, sel + 1, libraryName );
                lst_display.deselect( sel );
                lst_display.replaceItem( new String(
                    "\"" + item.title_of_article +
                    "\", in " + item.title + 
                    ( item.author.equals( "" ) ? "" : 
                    ", by " + item.author ) ),
                    sel
                );
            }

        } else {

            try {
                URL location = new URL( gotoLocation );
                getAppletContext( ).showDocument( location );
                System.exit( 0 );
            } catch ( MalformedURLException mue ) {
                // trust the HTML editors
            }

        }

        return true;

    } // end actionPerformed


    //=======================================================================
    // Methods
    private void getHTMLParameters( )
    {
        String param;

        param = getParameter( "ILL-Service-Type" );
        illService = (short)( param.toUpperCase( ).equals( "LENDER" ) ? 1 :
                     param.toUpperCase( ).equals( "PROFILE" ) ? 2 :
                     3 );

        if ( illService == 1 )
            lenderList = getParameter( "Lender-List" );
        else
            lenderList = new String( "" );

        param = getParameter( "Max-Requests" );
        maxRequests = ( param == null ? 10 :
                        Integer.parseInt( param ) );

        if ( maxRequests == 0 ) {
            maxRequests = Integer.MAX_VALUE;
        }

        gotoLocation = getParameter( "Return-Location" );
        institutionName = getParameter( "Institution-Name" );
        libraryName = getParameter( "Library-Name" );
        libSymbol = getParameter( "Library-Symbol" );

        delName = getParameter( "Delivery-Name" );
        param = getParameter( "Delivery-Extension" );
        delExtension = ( param == null ? new String( "" ) :
                         param );
        param = getParameter( "Delivery-Street" );
        delStreet = ( param == null ? new String( "" ) :
                      param );
        param = getParameter( "Delivery-POBox" );
        delPOBox = ( param == null ? new String( "" ) :
                     param );
        delCity = getParameter( "Delivery-City" );
        delState = getParameter( "Delivery-State" );
        param = getParameter( "Delivery-Country" );
        delCountry = ( param == null ? new String( "USA" ) :
                       param );
        delPostalCode = getParameter( "Delivery-ZIP-Code" );

        param = getParameter( "Delivery-Service" );
        delService = ( param == null ? new String( "" ) :
                       param );
        param = getParameter( "Electronic-Delivery-Service" );
        delElectronic = ( param == null ? new String( "" ) :
                          param );
        param = getParameter( "Library-Fax" );
        delFax = ( param == null ? new String( "" ) :
                   param );
        param = getParameter( "Library-Email" );
        delEmail = ( param == null ? new String( "" ) :
                     param );

        param = getParameter( "Max-Cost" );
        maxCost = ( param == null ? new String( "" ) :
                    param );

        param = getParameter( "Book-Note" );
        bookNote = ( param == null ? new String( "" ) :
                     param );

        param = getParameter( "Periodical-Note" );
        perNote = ( param == null ? new String( "" ) :
                     param );

        param = getParameter( "Background-Color" );
        if ( param.charAt( 0 ) == '#' ) {
            int red = Integer.parseInt( new String( "" + param.charAt( 1 ) + param.charAt( 2 ) ), 16 );
            int green = Integer.parseInt( new String( "" + param.charAt( 3 ) + param.charAt( 4 ) ), 16 );
            int blue = Integer.parseInt( new String( "" + param.charAt( 5 ) + param.charAt( 6 ) ), 16 );
            bgcolor = new Color( red, green, blue );
        } else {
            if ( param.toUpperCase( ).equals( "BLACK" ) ) bgcolor = Color.black;
            else if ( param.toUpperCase( ).equals( "BLUE" ) ) bgcolor = Color.blue;
            else if ( param.toUpperCase( ).equals( "CYAN" ) ) bgcolor = Color.blue;
            else if ( param.toUpperCase( ).equals( "DARKGRAY" ) ) bgcolor = Color.darkGray;
            else if ( param.toUpperCase( ).equals( "GRAY" ) ) bgcolor = Color.gray;
            else if ( param.toUpperCase( ).equals( "GREEN" ) ) bgcolor = Color.green;
            else if ( param.toUpperCase( ).equals( "LIGHTGRAY" ) ) bgcolor = Color.lightGray;
            else if ( param.toUpperCase( ).equals( "MAGENTA" ) ) bgcolor = Color.magenta;
            else if ( param.toUpperCase( ).equals( "ORANGE" ) ) bgcolor = Color.orange;
            else if ( param.toUpperCase( ).equals( "PINK" ) ) bgcolor = Color.pink;
            else if ( param.toUpperCase( ).equals( "RED" ) ) bgcolor = Color.red;
            else if ( param.toUpperCase( ).equals( "WHITE" ) ) bgcolor = Color.white;
            else if ( param.toUpperCase( ).equals( "YELLOW" ) ) bgcolor = Color.yellow;
            else bgcolor = Color.white;
        }
    }

} // end ONU_ILL



/****************************************************************************
 *                                                                          *
 * (c)1998 Olivet Nazarene University, 240 East Marsile,                    *
 * Bourbonnais, IL 60914-0592.                                              *
 *                                                                          *
 * NOTICE TO USERS:  ONU-ILL ("Software") has been developed by             *
 * Olivet Nazarene University.  Subject to the terms and conditions set     *
 * forth below, Olivet grants to user a perpetual, non-exclusive, royalty-  *
 * free license to use, reproduce, alter, modify, and create derivative     *
 * works from Software, and to sublicense Software subject to the following *
 * terms and conditions:                                                    *
 *                                                                          *
 * SOFTWARE IS PROVIDED AS IS.  OLIVET MAKES NO WARRANTIES, REPRESENTATIONS,*
 * OR GUARANTEES WHETHER EXPRESS OR IMPLIED REGARDING SOFTWARE, ITS FITNESS *
 * FOR ANY PARTICULAR PURPOSE, OR THE ACCURACY OF THE INFORMATION CONTAINED *
 * THEREIN.                                                                 *
 *                                                                          *
 * User agrees that Olivet shall have no liability to user arising          *
 * therefrom, regardless of the basis of the action, including liability for*
 * special, consequential, exemplary, or incidental damages, including lost *
 * profits, even if it has been advised of the possibility thereof.         *
 *                                                                          *
 * User shall cause the copyright notice of Olivet to appear on all copies  *
 * of Software, including derivative works made therefrom.                  *
 *                                                                          *
 ****************************************************************************
 *                                                                          *
 * (c)1996 OCLC Online Computer Library Center, Inc., 6565 Frantz Road,     *
 * Dublin, Ohio 43017-0702.  OCLC is a registered trademark of OCLC Online  *
 * Computer Library Center, Inc.                                            *
 *                                                                          *
 * NOTICE TO USERS:  The BER Utilities ("Software") has been developed by   *
 * OCLC Online Computer Library Center, Inc.  Subject to the terms and      *
 * conditions set forth below, OCLC grants to user a perpetual, non-        *
 * exclusive, royalty-free license to use, reproduce, alter, modify, and    *
 * create derivative works from Software, and to sublicense Software subject*
 * to the following terms and conditions:                                   *
 *                                                                          *
 * SOFTWARE IS PROVIDED AS IS.  OCLC MAKES NO WARRANTIES, REPRESENTATIONS,  *
 * OR GUARANTEES WHETHER EXPRESS OR IMPLIED REGARDING SOFTWARE, ITS FITNESS *
 * FOR ANY PARTICULAR PURPOSE, OR THE ACCURACY OF THE INFORMATION CONTAINED *
 * THEREIN.                                                                 *
 *                                                                          *
 * User agrees that OCLC shall have no liability to user arising therefrom, *
 * regardless of the basis of the action, including liability for special,  *
 * consequential, exemplary, or incidental damages, including lost profits, *
 * even if it has been advised of the possibility thereof.                  *
 *                                                                          *
 * User shall cause the copyright notice of OCLC to appear on all copies of *
 * Software, including derivative works made therefrom.                     *
 *                                                                          *
 ***************************************************************************/