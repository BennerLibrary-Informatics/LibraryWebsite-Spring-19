/****************************************************************************
 *                                                                          *
 *                              PatronInfoDlg                               *
 *                                                                          *
 ****************************************************************************
 *                                                                          *
 *  The PatronInfoDlg is the first visible window of the application.  It   *
 *  gets the necessary information about the patron in order to complete    *
 *  the request.  The information provided in this dialog is used for all   *
 *  requests in this application session.  The information is stored in the *
 *  PatronInfo class.                                                       *
 *                                                                          *
 ***************************************************************************/

import java.awt.*;

public class PatronInfoDlg extends Dialog
{
    // Attributes
    private Checkbox       cb_faculty, 
                           cb_staff, 
                           cb_undergrad, 
                           cb_grad, 
                           cb_other;
    private CheckboxGroup  grp_status;      // PSTATUS
    private InfoTextField  tf_name,         // PATRON
                           tf_po_box,       // PATRON_ADDR
                           tf_address,      // PATRON_ADDR
                           tf_city,         // PATRON_ADDR
                           tf_state,        // PATRON_ADDR
                           tf_zip,          // PATRON_ADDR
                           tf_id,           // PATRON_ID
                           tf_email,        // PATRON_EMAIL
                           tf_phone,        // PATRON_PHONE
                           tf_fax;          // PATRON_FAX
    private Button         btn_ok, 
                           btn_cancel;

    PatronInfo patron_info;

    private Toolkit sys_metrics = Toolkit.getDefaultToolkit( );
    private Font boldFont = new Font( "Sans Serif", Font.BOLD, 11 );


    // Constructor
    public PatronInfoDlg( Frame parent, PatronInfo info, String institution )
    {
        // Call dialog superclass constructor.
        super( parent, institution + " Interlibrary Loan Services", true );
        patron_info = info;

        // Set window size, layout, and listener.
        setResizable( false );
        setLayout( null );
        setFont( new Font( "Sans Serif", Font.PLAIN, 11 ) );
        
        // Add dialog box components.
        Label name = new Label( institution );
        name.setFont( new Font( "Serif", Font.BOLD + Font.ITALIC, 28 ) );

        Label ill = new Label( "Interlibrary Loan" );
        ill.setFont( new Font( "Serif", Font.BOLD + Font.ITALIC, 24 ) );

        Label dir1 = new Label( "DIRECTIONS: Enter the information in the " +
            "fields below and press OK." );
        Label dir2 = new Label( "Press Cancel to exit the program." );

        Label note = new Label( "NOTE:  " );
        Label bold = new Label( "BOLD" );
        bold.setFont( boldFont );
        Label endnote = new Label( " denotes a required field." );


        grp_status = new CheckboxGroup( );
        Panel pnl_status = new Panel( );
        pnl_status.setLayout( new FlowLayout( FlowLayout.LEFT ) );
        pnl_status.add( cb_faculty = new Checkbox( "Faculty", grp_status, false ) );
        pnl_status.add( cb_staff = new Checkbox( "Staff", grp_status, false ) );
        pnl_status.add( cb_undergrad = new Checkbox( "Undergrad", grp_status, true ) );
        pnl_status.add( cb_grad = new Checkbox( "Grad", grp_status, false ) );
        pnl_status.add( cb_other = new Checkbox( "Other", grp_status, false ) );

        // Add components to the dialog box.
        add( name );
        add( ill );
        add( dir1 );
        add( dir2 );
        add( note );
        add( bold );
        add( endnote );
        add( pnl_status );
        add( tf_name = new InfoTextField( "Your Name", 32, boldFont ) );
        add( tf_po_box = new InfoTextField( "Box No.      OR", 16, boldFont ) );
        add( tf_address = new InfoTextField( "Street Address", 16, boldFont ) );
        add( tf_city = new InfoTextField( "City", 15 ) );
        add( tf_state = new InfoTextField( "State", 2 ) );
        add( tf_zip = new InfoTextField( "Zip Code", 5 ) );
        add( tf_id = new InfoTextField( "Your Student ID or SSN", 15 ) );
        add( tf_email = new InfoTextField( "Your E-mail Address", 15, boldFont ) );
        add( tf_phone = new InfoTextField( "Your Phone Number", 15 ) );
        add( tf_fax = new InfoTextField( "Your Fax Number", 15 ) );

        btn_ok = new Button( "OK" );
        btn_ok.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        btn_cancel = new Button( "Cancel" );
        btn_cancel.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        add( btn_ok );
        add( btn_cancel );

        // Set the location and bounds of the dialog components.
        name.reshape( 24, 24, 408, 28 );
        ill.reshape( 24, 52, 408, 24 );
        dir1.reshape( 24, 108, 408, 12 );
        dir2.reshape( 24, 120, 408, 12 );
        note.reshape( 24, 132, 36, 12 );
        bold.reshape( 60, 132, 32, 12 );
        endnote.reshape( 92, 132, 128, 12 );

        pnl_status.reshape( 36, 153, 384, 24 );

        tf_name.reshape( 36, 179,
            ( tf_name.getSize( ) ).width,
            ( tf_name.getSize( ) ).height );
        tf_po_box.reshape( 36, 220, 84, 
            ( tf_po_box.getSize( ) ).height );
        tf_address.reshape( 128, 220, 292,
            ( tf_address.getSize( ) ).height );
        tf_city.reshape( 36, 261, 232,
            ( tf_city.getSize( ) ).height );
        tf_state.reshape( 280, 261, 36,
            ( tf_state.getSize( ) ).height );
        tf_zip.reshape( 324, 261, 96,
            ( tf_zip.getSize( ) ).height );
        tf_id.reshape( 36, 302,
            ( tf_id.getSize( ) ).width,
            ( tf_id.getSize( ) ).height );
        tf_email.reshape( 240, 302,
            ( tf_email.getSize( ) ).width,
            ( tf_email.getSize( ) ).height );
        tf_phone.reshape( 36, 343,
            ( tf_phone.getSize( ) ).width,
            ( tf_phone.getSize( ) ).height );
        tf_fax.reshape( 240, 343,
            ( tf_fax.getSize( ) ).width,
            ( tf_fax.getSize( ) ).height );

        btn_ok.reshape( 280, 396, 64, 24 );
        btn_cancel.reshape( 356, 396, 64, 24 );

        // Display dialog box.
        int x = (int)( ( ( sys_metrics.getScreenSize( ) ).width - 456 ) / 2 );
        int y = (int)( ( ( sys_metrics.getScreenSize( ) ).height - 456 ) / 2 );
        reshape( x, y, 456, 456 );
        show( );

    }

    public boolean action( Event e, Object o )
    {
        if ( e.target == btn_cancel ) {

            // Remove dialog box and exit program.
            hide( );
            dispose( );
            // TODO:  go to another page.

        } else if ( e.target == btn_ok ) {

            // Check request fields, if any are missing then warn user.
            if ( tf_name.getText( ).equals( "" ) ||
                 tf_email.getText( ).equals( "" ) ||
                 ( tf_po_box.getText( ).equals( "" ) &&
                   tf_address.getText( ).equals( "" ) ) )
            {
                new ErrorMsgDlg( new Frame( ), "A required field is missing." );

            // If none are missing then continue program.
            } else {

                // Put patron information into request records
                for ( int i = 0; i < 10; i++ ) {
                    patron_info.patron_status = grp_status.getCurrent( ).getLabel( );
                    patron_info.patron_full_name = tf_name.getText( );
                    patron_info.p_home_po_box = tf_po_box.getText( );
                    patron_info.p_home_street_no = tf_address.getText( );
                    patron_info.p_home_city = tf_city.getText( );
                    patron_info.p_home_region = tf_state.getText( );
                    patron_info.p_home_postal_code = tf_zip.getText( );
                    patron_info.patron_id = tf_id.getText( );
                    patron_info.patron_email = tf_email.getText( );
                    patron_info.patron_phone = tf_phone.getText( );
                    patron_info.patron_fax = tf_fax.getText( );

                }

                // Remove dialog box.
                hide( );
                dispose( );

            }

        }

        return true;

    }

}