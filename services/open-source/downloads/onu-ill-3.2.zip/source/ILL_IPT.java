public interface ILL_IPT
{
    // ILL Field Constants
    public static final int
        BORROW_LIB_SYMBOL     = 4,
        NEEDBEFORE_DATE       = 5,
        OCLC_NO               = 6,
        AUTHOR                = 12,
        TITLE                 = 13,
        EDITION               = 14,
        IMPRINT               = 15,
        ARTICLE               = 16,
        VOLUME                = 17,
        SERIAL_NO             = 18,
        DATE                  = 19,
        PAGES                 = 20,
        VERIFIED              = 21,
        PATRON                = 22,
        SHIP_TO               = 23,
        BILL_TO               = 24,
        SHIP_VIA              = 25,
        MAXCOST               = 26,
        BORROWING_NOTES       = 28,
        EPIC_ILL_REC          = 33,
        SOURCE                = 43,
        SEQUENCE_NUMBER       = 44,
        PROCESSING_DATE       = 45,
        EPIC_FS_AUTHOS_NUMBER = 46,
        UNIFORM_TITLE         = 47,
        SERIES_NOTE           = 48,
        DISSERTATION_NOTE     = 49,
        PATRON_ID             = 55,
        PATRON_DEPT           = 56,
        PATRON_STATUS         = 57,
        PATRON_ADDR           = 58,
        PATRON_PHONE          = 59,
        PATRON_EMAIL          = 60,
        PATRON_FAX            = 61,
        PATRON_NOTES          = 62,
        LOCATION              = 63,
        ORIGIN                = 65,
        AFLN                  = 66;

    public static final short
        LEN_BORROW_LIB_SYMBOL     = 3,
        LEN_NEEDBEFORE_DATE       = 8,
        LEN_AUTHOR                = 500,
        LEN_TITLE                 = 500,
        LEN_EDITION               = 500,
        LEN_IMPRINT               = 500,
        LEN_ARTICLE               = 500,
        LEN_VOLUME                = 71,
        LEN_SERIAL_NO             = 72,
        LEN_DATE                  = 70,
        LEN_PAGES                 = 67,
        LEN_VERIFIED              = 500,
        LEN_PATRON                = 500,
        LEN_PATRON_ID             = 63,
        LEN_PATRON_DEPT           = 67,
        LEN_PATRON_STATUS         = 65,
        LEN_PATRON_ADDR           = 500,
        LEN_PATRON_PHONE          = 60,
        LEN_PATRON_EMAIL          = 59,
        LEN_PATRON_FAX            = 62,
        LEN_PATRON_NOTES          = 500,
        LEN_SHIP_TO               = 500,
        LEN_BILL_TO               = 500,
        LEN_SHIP_VIA              = 66,
        LEN_MAXCOST               = 67,
        LEN_BORROWING_NOTES       = 500,
        LEN_SOURCE                = 1,
        LEN_SEQUENCE_NUMBER       = 10,
        LEN_PROCESSING_DATE       = 8,
        LEN_EPIC_FS_AUTHOS_NUMBER = 10,
        LEN_UNIFORM_TITLE         = 500,
        LEN_SERIES_NOTE           = 500,
        LEN_DISSERTATION_NOTE     = 500,
        LEN_ORIGIN                = 8,
        LEN_AFLN                  = 500,
        LEN_OCLC_NO               = 10;

}


///////////////////////////////////////////////////////////////////////////////
// (c)1996 OCLC Online Computer Library Center, Inc., 6565 Frantz Road, Dublin,
// Ohio 43017-0702.  OCLC is a registered trademark of OCLC Online Computer
// Library Center, Inc.
//
// NOTICE TO USERS:  The BER Utilities ("Software") has been developed by OCLC
// Online Computer Library Center, Inc.  Subject to the terms and conditions set
// forth below, OCLC grants to user a perpetual, non-exclusive, royalty-free
// license to use, reproduce, alter, modify, and create derivative works from
// Software, and to sublicense Software subject to the following terms and
// conditions:
//
// SOFTWARE IS PROVIDED AS IS.  OCLC MAKES NO WARRANTIES, REPRESENTATIONS, OR
// GUARANTEES WHETHER EXPRESS OR IMPLIED REGARDING SOFTWARE, ITS FITNESS FOR ANY
// PARTICULAR PURPOSE, OR THE ACCURACY OF THE INFORMATION CONTAINED THEREIN.
//
// User agrees that OCLC shall have no liability to user arising therefrom,
// regardless of the basis of the action, including liability for special,
// consequential, exemplary, or incidental damages, including lost profits,
// even if it has been advised of the possibility thereof.
//
// User shall cause the copyright notice of OCLC to appear on all copies of
// Software, including derivative works made therefrom.