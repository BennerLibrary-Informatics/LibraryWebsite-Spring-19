/*
BookFormDlg.java

by Bryan Wilhelm
Created August 4, 1998

MODIFICATIONS:
12-17-98:  Moved ISBN field from the Additional Information Dialog.
*/

import java.awt.*;
import java.io.*;
import java.util.*;


public class BookFormDlg 
       extends Dialog 
       implements ILL_API, 
                  ONU_ILL_CONST
{
    // Attributes
    private Button        btn_ok, 
                          btn_cancel, 
                          btn_more;
    private InfoTextField tf_author,       // AUTHOR
                          tf_title,        // TITLE
                          tf_edition,      // EDITION
                          tf_isbn,         // ISBN
                          tf_publisher,    // IMPRINT
                          tf_pubyear,      // IMPRINT
                          tf_volume;       // VOLUME
    private TextField     tf_needbefore;   // NEEDBEFORE_DATE
    private CheckboxGroup grp_verified;    // VERIFIED
    private Checkbox      cb_yesVerified, 
                          cb_noVerified;

    public  ItemInfo request;
    private int      numRequests;

    private Toolkit sys_metrics = Toolkit.getDefaultToolkit( );
    private Font    boldFont = new Font( "Sans Serif", Font.BOLD, 11 );


    // Constructor
    public BookFormDlg( Frame parent, ItemInfo r, int n, String lib )
    {
        // Call dialog superclass constructor
        super( parent, "Item " + n + ":  Book Request Form", true );
        request = r;
        numRequests = n;

        // Set window size, layout, and listeners
        setResizable( false );
        setLayout( null );
        setFont( new Font( "Sans Serif", Font.PLAIN, 11 ) );

        // Create dialog box components
        Label illTitle = new Label( "Interlibrary Loan" );
        Label formTitle = new Label( "Book Request Form" );
        illTitle.setFont( new Font( "Serif", Font.BOLD + Font.ITALIC, 24 ) );
        formTitle.setFont( new Font( "Serif", Font.BOLD + Font.ITALIC, 24 ) );

        Label verifiedLabel = new Label( "Have you checked " + lib + " for this item?" );
        verifiedLabel.setFont( boldFont );
        grp_verified = new CheckboxGroup( );
        cb_yesVerified = new Checkbox( "Yes", grp_verified, false );
        cb_noVerified = new Checkbox( "No", grp_verified, true );

        Label nbdLabel = new Label( "Enter the date this item is needed by. " +
            "The default date is pre-entered." );
        nbdLabel.setFont( boldFont );


        int month = DEFAULT_NEEDBEFORE_DATE.getMonth( ) + 1;
        int day = DEFAULT_NEEDBEFORE_DATE.getDate( );
        int year = DEFAULT_NEEDBEFORE_DATE.getYear( ) + 1900;

        String dateString = new String(
            ( month == 1 ? "January " :
            month == 2 ? "February " :
            month == 3 ? "March " :
            month == 4 ? "April " :
            month == 5 ? "May " :
            month == 6 ? "June " :
            month == 7 ? "July " :
            month == 8 ? "August " :
            month == 9 ? "September " :
            month == 10 ? "October " :
            month == 11 ? "November " :
            "December " ) +
            day + ", " + year );

        tf_needbefore = new TextField( 10 );
        tf_needbefore.setText( dateString );

        btn_more = new Button( "More" );
        btn_more.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        btn_ok = new Button( "OK" );
        btn_ok.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        btn_cancel = new Button( "Cancel" );
        btn_cancel.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );

        // Add components to the dialog box.
        add( illTitle );
        add( formTitle );
        add( tf_author = new InfoTextField( "Author (Last, First)", 32, boldFont ) );
        tf_author.setText( new String( request.author ) );
        add( tf_title = new InfoTextField( "Book Title", 32, boldFont ) );
        tf_title.setText( new String( request.title ) );
        add( tf_edition = new InfoTextField( "Edition", 15 ) );
        tf_edition.setText( request.edition == "" ? "ANY" : new String( request.edition ) );
        add( tf_volume = new InfoTextField( "Volume", 15 ) );
        tf_volume.setText( new String( request.volume ) );
        add( tf_isbn = new InfoTextField( "ISBN (if available)", 15 ) );
        tf_isbn.setText( new String( request.isbn ) );
        add( tf_publisher = new InfoTextField( "Publisher", 15 ) );
        tf_publisher.setText( new String( request.publisher ) );
        add( tf_pubyear = new InfoTextField( "Year Published", 15 ) );
        tf_pubyear.setText( new String( request.publication_date ) );
        add( verifiedLabel );
        add( cb_yesVerified );
        add( cb_noVerified );
        add( nbdLabel );
        add( tf_needbefore );
        add( btn_more );
        add( btn_ok );
        add( btn_cancel );

        // Set the location and bounds of the dialog components.
        illTitle.reshape( 24, 24, 384, 27 );
        formTitle.reshape( 24, 51, 384, 27 );

        tf_author.reshape( 36, 86,
            ( tf_author.getSize( ) ).width,
            ( tf_author.getSize( ) ).height );
        tf_title.reshape( 36, 130,
            ( tf_title.getSize( ) ).width,
            ( tf_title.getSize( ) ).height );
        
        tf_isbn.reshape( 36, 174, 120,
            ( tf_isbn.getSize( ) ).height );
        tf_edition.reshape( 168, 174, 120,
            //( tf_edition.getSize( ) ).width,
            ( tf_edition.getSize( ) ).height );
        tf_volume.reshape( 300, 174, 120,
            //( tf_volume.getSize( ) ).width,
            ( tf_volume.getSize( ) ).height );
        
        tf_publisher.reshape( 36, 218, 252,
            //( tf_publisher.getSize( ) ).width,
            ( tf_publisher.getSize( ) ).height );
        tf_pubyear.reshape( 300, 218, 120,
            //( tf_pubyear.getSize( ) ).width,
            ( tf_pubyear.getSize( ) ).height );
        
        verifiedLabel.reshape( 36, 270, 384, 14 );
        cb_yesVerified.reshape( 36, 286, 50, 20 );
        cb_noVerified.reshape( 86, 286, 50, 20 );

        nbdLabel.reshape( 36, 317, 384, 16 );
        tf_needbefore.reshape( 36, 335, 144, 20 );

        btn_more.reshape( 36, 370, 64, 24 );
        btn_ok.reshape( 280, 370, 64, 24 );
        btn_cancel.reshape( 356, 370, 64, 24 );

        // Display dialog box in the center of the screen.
        int x = (int)( ( ( sys_metrics.getScreenSize( ) ).width - 456 ) / 2 );
        int y = (int)( ( ( sys_metrics.getScreenSize( ) ).height - 430 ) / 2 );
        reshape( x, y, 456, 430 );
        show( );
    }

    public boolean action( Event e, Object o )
    {
        if ( e.target == btn_ok ) {

            // If there is data missing warn the user,
            if ( tf_author.getText( ).equals( "" ) ||
                 tf_title.getText( ).equals( "" ) ||
                 tf_needbefore.getText( ).equals( "" ) ||
                 grp_verified.getCurrent( ).getLabel( ).equals( "No" ) )
            {
                new ErrorMsgDlg( new Frame( ), "A required field is missing." );

            // else get the information from the user.
            } else {

                // Get the date entered by the user.
                request.need_before_date = new String( ILLDate.getFormattedDate( new Date( Date.parse( tf_needbefore.getText( ) ) ) ) );
                request.author = new String( tf_author.getText( ) );
                request.title = new String( tf_title.getText( ) );
                request.edition = new String( tf_edition.getText( ) );
                request.isbn = new String( tf_isbn.getText( ) );
                request.publisher = new String( tf_publisher.getText( ) );
                request.publication_date = new String( tf_pubyear.getText( ) );
                request.volume = new String( tf_volume.getText( ) );

                request.ill_service_type = BOOK_REQUEST;
                request.request_made = true;

                hide( );
                dispose( );
            }
        }

        else if ( e.target == btn_more ) {
            new MoreBookInfoDlg( new Frame( ), request, numRequests );
        }

        else if ( e.target == btn_cancel ) {
            request.request_made = false;
            hide( );
            dispose( );
        }

        return true;

    }


}