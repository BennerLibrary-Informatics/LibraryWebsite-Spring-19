import java.awt.*;

public class AppreciationDlg extends Dialog
{
    Button button;
    Label  message;
    Toolkit sys_metrics = Toolkit.getDefaultToolkit( );

    public AppreciationDlg( Frame parent, boolean flag, String lib )
    {
        super( parent, flag ? "  Failed Request  " : "  Successful Request  ", true );

        setResizable( false );
        setLayout( null );
        setFont( new Font( "Sans Serif", Font.PLAIN, 11 ) );

        Panel msgPanel = new Panel( );
        msgPanel.setLayout( new FlowLayout( FlowLayout.CENTER ) );
        msgPanel.resize( 330, 25 );

        message = new Label( flag ? "Your request was not successful--contact " + lib + "." :
                             "Thank you for using " + lib + " Interlibrary Loan." );
        msgPanel.add( message);

        button = new Button( "OK" );
        button.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );

        add( msgPanel );
        add( button );

        msgPanel.reshape( 15, 20, 330, 25 );
        button.reshape( 148, 60, 64, 24 );

        int x = (int) ( ( sys_metrics.getScreenSize( ).width - 300 ) / 2.0 );
        int y = (int) ( ( sys_metrics.getScreenSize( ).height - 150 ) / 2.0 );
        reshape( x, y, 360, 130 );
        show( );
    }

    public boolean action( Event e, Object o )
    {
        hide( );
        dispose( );

        return true;
    }
}