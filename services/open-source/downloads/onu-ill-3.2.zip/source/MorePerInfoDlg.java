import java.awt.*;

public class MorePerInfoDlg extends Dialog implements ILL_API, ONU_ILL_CONST
    {
        // Attributes
        private Button        btn_ok, 
                              btn_cancel;
        private InfoTextField tf_whereFound;    // +PATRON_NOTES
        private TextArea      ta_comments;      // +PATRON_NOTES

        ItemInfo request;

        private Toolkit sys_metrics = Toolkit.getDefaultToolkit( );
        private Font    boldFont = new Font( "Sans Serif", Font.BOLD, 11 );
        private Font bigFont = new Font( "Serif", Font.BOLD + Font.ITALIC, 24 );



        // Constructor
        public MorePerInfoDlg( Frame parent, ItemInfo r, int n )
        {
            // Call dialog superclass constructor.
            super( parent, "Item " + n + ":  Additional Information", true );

            request = r;

            // set window size, layout, and listeners
            setResizable( false );
            setLayout( null );
            setFont( new Font( "Sans Serif", Font.PLAIN, 11 ) );

            // Create dialog box components.
            Label illTitle = new Label( "Interlibrary Loan" );
            Label perTitle = new Label( "Periodical Request Form" );
            Label commentLabel = new Label( "Enter any comments helpful to order" +
                " this item" );
            illTitle.setFont( bigFont );
            perTitle.setFont( bigFont );

            tf_whereFound = new InfoTextField( "Where did you find this citation", 32 );
            ta_comments = new TextArea( 32, 10 );

            btn_ok = new Button( "OK" );
            btn_cancel = new Button( "Cancel" );

            // Add components to the dialog box.
            add( illTitle );
            add( perTitle );
            add( tf_whereFound );
            add( commentLabel );
            add( ta_comments );
            add( btn_ok );
            add( btn_cancel );

            // Set the location and bounds of the dialog components.
            illTitle.reshape( 24, 24, 384, 27 );
            perTitle.reshape( 24, 51, 384, 27 );

            tf_whereFound.reshape( 36, 102,
                ( tf_whereFound.getSize( ) ).width,
                ( tf_whereFound.getSize( ) ).height );
            commentLabel.reshape( 36, 150, 384, 14 );
            ta_comments.reshape( 36, 166, 384, 218 );

            btn_ok.reshape( 298, 416, 64, 24 );
            btn_cancel.reshape( 374, 416, 64, 24 );

            // Display dialog box.
            int x = (int)( ( ( sys_metrics.getScreenSize( ) ).width - 456 ) / 2 );
            int y = (int)( ( ( sys_metrics.getScreenSize( ) ).height - 456 ) / 2 );
            reshape( x, y, 456, 456 );
            show( );

        } // end constructor

        public boolean action( Event e, Object o )
        {
            // if "OK" pressed, process fields
            if ( e.target == btn_ok ) {

                // PATRON_NOTES
                // If whereFound is empty then do not worry about the other
                // two fields.
                if ( !tf_whereFound.getText( ).equals( "" ) ) {
                    request.patron_notes = tf_whereFound.getText( );
                }

                // Comments also go in PATRON_NOTES
                if ( request.patron_notes.equals( "" ) ) {
                    request.patron_notes = ta_comments.getText( );
                } else if ( !ta_comments.getText( ).equals( "" ) ) {
                    request.patron_notes += "; " + ta_comments.getText( );
                }

            }

            // else "Cancel" was pressed.

            // This is done when either button is pressed.
            hide( );
            dispose( );

            return true;
        }

    }
