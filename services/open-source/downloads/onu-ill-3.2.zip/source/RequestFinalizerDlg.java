/****************************************************************************
 *                                                                          *
 *                          RequestFinalizer                                *
 *                                                                          *
 ****************************************************************************
 *                                                                          *
 *  This is the complicated part.  The RequestFinalizer needed to put the   *
 *  IsoIllRequest together from the separate pieces gathered during the     *
 *  program, construct the ASN.1/BER record, send it to OCLC and get their  *
 *  response.                                                               *
 *                                                                          *
 *  Parameters:  (1) PatronInfo                                             *
 *               (2) Vector (of ItemInfo)                                   *
 *               (3) numRequests                                            *
 *  For the number of requests (numRequests), RequestFinalizer will combine *
 *  each ItemInfo with the PatronInfo and other system supplied variables   *
 *  into a single IsoIllRequest, encrypt the request and submit it to OCLC. *
 *                                                                          *
 ***************************************************************************/

import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class RequestFinalizerDlg    // this
       extends Dialog               // super
       implements Runnable,         // thread handling
                  ILL_ASN,          // constant data
                  ILL_API,          // constant data
                  ONU_ILL_CONST     // constant data

{
    // Attributes
    Toolkit sys_metrics = Toolkit.getDefaultToolkit( );
    Label   the_action;
    Button  btn_ok;

    Thread finalizerThread;

    PatronInfo patron_info;
    Vector     record = new Vector( );  
               // A Vector of ItemInfo
    int        numRequests;

    Vector            requests;
                      // A Vector of IsoIllRequest
    IsoIllApdu        apdu;
    BerString         berRec, 
                      berResponse;
    String            connectLocation;
    Socket            connection;
    DataOutputStream  output;
    DataInputStream   input;

    boolean error_flag = false;

    // variables to store data with defaults
    short  service_code;
    String lenderList;
    String institutionName;
    String libSymbol;
    String delName;
    String delExtension;
    String delStreet;
    String delPOBox;
    String delCity;
    String delState;
    String delCountry;
    String delPostalCode;
    String delService;
    String delElectronic;
    String delFax;
    String delEmail;
    String bookNote;
    String perNote;
    String maxCost;

    // Constructor
    public RequestFinalizerDlg( 
        Frame parent,
        String host,
        PatronInfo patron,
        Vector items,
        int n,
        short code,
        String list,
        String instName,
        String libSym,
        String name,
        String ext,
        String street,
        String box,
        String city,
        String state,
        String country,
        String zipcode,
        String service,
        String electronic,
        String fax,
        String email,
        String bNote,
        String pNote,
        String mCost )
    {
        // superclass call and initial setup
        super( parent, "Submit Request", true );
        setResizable( false );
        setLayout( null );
        setFont( new Font( "Sans Serif", Font.PLAIN, 11 ) );

        // initialize variables
        patron_info = patron;
        record = items;
        numRequests = n;
        service_code = code;
        requests = new Vector( numRequests );

        connectLocation = host;

        lenderList = list;
        institutionName = instName;
        libSymbol = libSym;
        delName = name;
        delExtension = ext;
        delStreet = street;
        delPOBox = box;
        delCity = city;
        delState = state;
        delCountry = country;
        delPostalCode = zipcode;
        delService = service;
        delElectronic = electronic;
        delFax = fax;
        delEmail = email;
        bookNote = bNote;
        perNote = pNote;
        maxCost = mCost;

        // create and add components but don't show them
        Panel msgPanel = new Panel( );
        msgPanel.resize( 330, 25 );
        msgPanel.setLayout( new FlowLayout( FlowLayout.CENTER ) );

        the_action = new Label( "                        Initializing the request record...                        " );
                            // big spaces so that the label won't collapse 
                            // and smother the other labels to follow.
        msgPanel.add( the_action );
        the_action.setAlignment( Label.CENTER );
        the_action.reshape( 0, 0, 330, 25 );

        btn_ok = new Button( "OK" );
        btn_ok.setFont( new Font( "Sans Serif", Font.BOLD, 12 ) );
        btn_ok.enable( false );

        add( msgPanel );
        add( btn_ok );

        msgPanel.reshape( 15, 20, 330, 25 );
        btn_ok.reshape( 148, 60, 64, 24 );

        finalizerThread = new Thread( this, "Finalizer" );
        finalizerThread.start( );

        // display the dialog
        int x = (int) ( ( sys_metrics.getScreenSize( ).width - 300 ) / 2.0 );
        int y = (int) ( ( sys_metrics.getScreenSize( ).height - 150 ) / 2.0 );
        reshape( x, y, 360, 130 );
        show( );

    }


    // Mandatory Methods
    public boolean action( Event e, Object o )
    {
        hide( );
        dispose( );

        return true;
    }

    public void run( )
    {
        int x;

        // initialize request record variables
        for ( x = 0; x < numRequests; x++ ) {
            IsoIllRequest r = new IsoIllRequest( );
            r.service_date = ILLDate.getFormattedDate( new Date( ) );
            r.transaction_qualifier =
                new String( libSymbol + ( new Date( ) ).getTime( ) );
            r.transaction_group_qualifier = 
                new String( libSymbol + "-ILL-APPLET" );
            r.user_pid = new String( "AppletUser" );
            r.requester_id = new String( libSymbol );
            r.authorization = new String( AUTHORIZATION );
            r.password = new String( PASSWORD );
            r.delivery_name = new String( institutionName );
            r.delivery_extension = new String( delExtension );
            r.delivery_po_box = new String( delPOBox );
            r.delivery_city = new String( delCity );
            r.delivery_region = new String( delState );
            r.delivery_country = new String( delCountry );
            r.delivery_postal_code = new String( delPostalCode );
            r.delivery_service = new String( delService );
            r.fax_address = new String( delFax );
            r.email_address = new String( delEmail );
            r.need_before_date = ( (ItemInfo) record.elementAt( x ) ).need_before_date;
            r.patron_id = patron_info.patron_id;
            r.patron_full_name = patron_info.patron_full_name;
            r.p_home_street_no = patron_info.p_home_street_no;
            r.p_home_po_box = patron_info.p_home_po_box;
            r.p_home_city = patron_info.p_home_city;
            r.p_home_region = patron_info.p_home_region;
            r.p_home_country = patron_info.p_home_country;
            r.p_home_postal_code = patron_info.p_home_postal_code;
            r.patron_phone = patron_info.patron_phone;
            r.patron_email = patron_info.patron_email;
            r.patron_fax = patron_info.patron_fax;
            r.patron_status = patron_info.patron_status;
            r.patron_notes = ( (ItemInfo) record.elementAt( x ) ).patron_notes;
            r.held_medium_type = ( (ItemInfo) record.elementAt( x ) ).held_medium_type;
            r.author = 
                ( ( (ItemInfo) record.elementAt( x ) ).ill_service_type == BOOK_REQUEST ?
                ( (ItemInfo) record.elementAt( x ) ).author : "" );
            r.title = ( (ItemInfo) record.elementAt( x ) ).title;
            r.publisher = ( (ItemInfo) record.elementAt( x ) ).publisher;
            r.volume = ( (ItemInfo) record.elementAt( x ) ).volume;
            r.issue = ( (ItemInfo) record.elementAt( x ) ).issue;
            r.edition = ( (ItemInfo) record.elementAt( x ) ).edition;
            r.publication_date = 
                ( ( (ItemInfo) record.elementAt( x ) ).ill_service_type == BOOK_REQUEST ?
                ( (ItemInfo) record.elementAt( x ) ).publication_date : "" );
            r.publication_date_of_component = 
                ( ( (ItemInfo) record.elementAt( x ) ).ill_service_type == PERIODICAL_REQUEST ?
                ( (ItemInfo) record.elementAt( x ) ).publication_date : "" );
            r.author_of_article =
                ( ( (ItemInfo) record.elementAt( x ) ).ill_service_type == PERIODICAL_REQUEST ?
                ( (ItemInfo) record.elementAt( x ) ).author : "" );
            r.title_of_article = ( (ItemInfo) record.elementAt( x ) ).title_of_article;
            r.pagination = ( (ItemInfo) record.elementAt( x ) ).pagination;
            r.isbn = ( (ItemInfo) record.elementAt( x ) ).isbn;
            r.issn = ( (ItemInfo) record.elementAt( x ) ).issn;
            r.oclc_no = ( (ItemInfo) record.elementAt( x ) ).oclc_no;
            r.verification_reference_source = ( (ItemInfo) record.elementAt( x ) ).verification_reference_source;
            r.dissertation = ( (ItemInfo) record.elementAt( x ) ).dissertation;
            r.copyright_compliance = new String( "ccg" );
                //copyright compliance is either "ccg" or "ccl"
            r.send_to_list = new String( lenderList );
                // send to list can be used to send a profile to search
                // for this specific item.
            r.requester_note = 
                ( ( (ItemInfo) record.elementAt( x ) ).ill_service_type == BOOK_REQUEST ?
                bookNote : perNote );
            r.currency_code = new String( "U.S." );
            r.monetary_value = new String( maxCost );
            r.oclc_ill_service_type = service_code;
            r.ill_service_type = ( (ItemInfo) record.elementAt( x ) ).ill_service_type;
            r.preference = UNORDERED;
            r.change_send_to = false;

            requests.addElement( r );
        } // end for loop

        try {
            the_action.setText( "Establishing connection to OCLC..." );

            connection = new Socket( connectLocation, 499 );

            the_action.setText( "Establishing I/O streams..." );
            output = new DataOutputStream( connection.getOutputStream( ) );
            input = new DataInputStream( connection.getInputStream( ) );

            for ( x = 0; x < numRequests; x++ ) {
                // Build the ASN.1/BER record
                the_action.setText( "Building request record..." );
                berRec = ( (IsoIllRequest) requests.elementAt( x ) ).BuildIsoIllRequest( );

                // Send the record to OCLC
                the_action.setText( "Sending request record..." );
                berRec.writeBerString( output );

                // Get their response
                byte response[] = new byte[ 256 ];
                the_action.setText( "Receiving response from OCLC..." );
                if ( input.read( response ) <= 0 )
                    throw new IOException( "No Response received." );
                else
                    berResponse = new BerString( response );

                // Process response
                the_action.setText( "Processing request response..." );
                apdu = new IsoIllApdu( berResponse );

                switch ( apdu.type ) {
                case ( STATUS_OR_ERROR_REPORT_APDU ):
                    the_action.setText( "Request failed, contact Benner Library." );
                    error_flag = true;
                case ( ILL_ANSWER_APDU ):
                    the_action.setText( "Request was successful!" );
                default:
                    the_action.setText( "Indeterminant response type." );
                }
            } // end for loop

            // close connections
            the_action.setText( "Closing connection and I/O streams..." );
            input.close( );
            output.close( );
            connection.close( );

            the_action.setText( "Request transaction is complete." );

        }
        catch ( Exception all ) {
            error_flag = true;
            the_action.setText( "Request failed, contact Benner Library." );
        }
        finally {
            btn_ok.enable( true );
        }

    } // end run method

}