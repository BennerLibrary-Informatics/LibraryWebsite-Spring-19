public class ItemInfo
{
    // attributes
    public String 
        need_before_date,
        held_medium_type, // PRINTED_HMT (This field could be used to 
                          // indicated other media such as audio/video, 
                          // microfilm, etc.).  It is included here for
                          // future use.
        author,           // Books go in author, while
                          // periodicals go in author_of_article.
        title,
        publisher,
        volume,
        issue,
        edition,
        publication_date,  // Books go in publication_date, while
                           // periodicals go in publication_date_of_component.
        title_of_article,
        pagination,
        isbn,
        issn,
        oclc_no,
        dissertation,
        verification_reference_source,
        patron_notes;

    public short
        ill_service_type;  // BOOK_REQUEST (1) or PER_REQUEST (2)

    public boolean
        request_made;

    // constructor
    public ItemInfo( )
    {
        need_before_date = new String( );
        held_medium_type = new String( "" + 1 );  // PRINTED_HMT = 1
            // This is the same for all materials at this time.  Later
            // versions may include support for multimedia, audio-visual,
            // etc.
        author = new String( );
        title = new String( );
        publisher = new String( );
        volume = new String( );
        issue = new String( );
        edition = new String( );
        publication_date = new String( );
        title_of_article = new String( );
        pagination = new String( );
        isbn = new String( );
        issn = new String( );
        oclc_no = new String( );
        dissertation = new String( );
        verification_reference_source = new String( );
        ill_service_type = 0;
        request_made = false;
    }
}