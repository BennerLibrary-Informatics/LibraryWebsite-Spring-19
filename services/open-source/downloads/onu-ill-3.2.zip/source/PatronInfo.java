public class PatronInfo
{
    // Attributes
    public String
        patron_id,                          // PATRON ID
        patron_full_name,                   // PATRON
        patron_ssn,                         // PATRON ID
        p_home_street_no,                   // PATRON ADDR
        p_home_po_box,                      // PATRON ADDR
        p_home_city,                        // PATRON ADDR
        p_home_region,                      // PATRON ADDR
        p_home_country,                     // PATRON ADDR
        p_home_postal_code,                 // PATRON ADDR
        patron_phone,                       // PATRON PHONE
        patron_email,                       // PATRON EMAIL
        patron_fax,                         // PATRON FAX
        patron_status;                      // PSTATUS


    // Constructor
    public PatronInfo( )
    {
        patron_id = new String( );
        patron_full_name = new String( );
        patron_ssn = new String( );
        p_home_street_no = new String( );
        p_home_po_box = new String( );
        p_home_city = new String( );
        p_home_region = new String( );
        p_home_country = new String( "USA" );
        p_home_postal_code = new String( );
        patron_phone = new String( );
        patron_email = new String( );
        patron_fax = new String( );
        patron_status = new String( );
    }
}