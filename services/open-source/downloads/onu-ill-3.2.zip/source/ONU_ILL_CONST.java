/*
** EDU.olivet.ill.ONU_ILL_CONST.java
**
** VERSION: 1.2
** AUTHOR:  Bryan Wilhelm
**          Olivet Nazarene University
** DATE:    August 5, 1998
**
** Contains data specifically for the ONU-ILL application and to Benner
** Library
*/


import java.util.*;

public interface ONU_ILL_CONST {

    // CONSTANTS
    public static final int
        DEFAULT_NEEDBEFORE_DAYS = 25;   // default of 25 days

    public static final Date
        TODAY                   = new Date(),
        DEFAULT_NEEDBEFORE_DATE = new Date( System.currentTimeMillis() + 
                                  (long)(DEFAULT_NEEDBEFORE_DAYS * 8.64e7) );

    public static final String  // These constants may need to be changed.
        BLANK            = new String( "" ),

        /*
        ** THESE MUST BE MODIFIED
        */
        AUTHORIZATION    = new String( "nnn-nnn-nnn" ),  // PRISM AUTHORIZATION
        PASSWORD         = new String( "Password" ),  // PRISM PASSWORD

        DEFAULT_NEEDBEFORE_STRING = 
                     new String( ILLDate.getFormattedDate( DEFAULT_NEEDBEFORE_DATE ) );

    public static final short
        BOOK_REQUEST = 1,
        PERIODICAL_REQUEST = 2;

}
